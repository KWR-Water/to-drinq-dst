"""Programmatic API for running pyStimela optimization workflows.

This module provides parser-free entry points for use from other Python
applications while preserving existing CLI behavior in
``pystimela_optim.scripts``.
"""

from __future__ import annotations

import json
from importlib import import_module
from pathlib import Path
from typing import Any, Callable, Dict, Mapping

ConfigLike = str | Path | Mapping[str, Any]


def _load_config(config: ConfigLike) -> Dict[str, Any]:
    if isinstance(config, Mapping):
        return dict(config)

    config_path = Path(config)
    with config_path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _resolve_algo_value(
    algo: Mapping[str, Any],
    key: str,
    override: int | float | None,
    default: int | float,
) -> int | float:
    if override is not None:
        return override
    return algo.get(key, default)


def _build_backwash_events(
    module: Any,
    timestamps: list[float],
    bw_freq_h: float,
) -> list[bool]:
    if bw_freq_h > 0:
        return module.generate_backwash_events(timestamps, freq_h=bw_freq_h)
    return [False] * len(timestamps)


def optimize_coag_floc(
    config: ConfigLike,
    *,
    seed: int | None = None,
    maxiter: int | None = None,
    popsize: int | None = None,
    tol: float | None = None,
) -> Dict[str, Any]:
    module = import_module("pystimela_optim.scripts.coag_floc_optim")
    cfg = _load_config(config)
    algo = cfg.get("algorithm", {})

    inputs = module.QualityInputs.from_json(cfg["inputs"])
    params = module.Params(**cfg["params"])
    limits = module.Limits(**cfg["limits"])
    weights = module.Weights(**cfg["weights"])
    initials = module.InitialStates(**cfg["initials"])

    return module.solve(
        inputs,
        params,
        limits,
        weights,
        initials,
        seed=int(_resolve_algo_value(algo, "seed", seed, 42)),
        maxiter=int(_resolve_algo_value(algo, "maxiter", maxiter, 60)),
        popsize=int(_resolve_algo_value(algo, "popsize", popsize, 15)),
        tol=float(_resolve_algo_value(algo, "tol", tol, 1e-3)),
    )


def optimize_chlorination(
    config: ConfigLike,
    *,
    seed: int | None = None,
    maxiter: int | None = None,
    popsize: int | None = None,
    tol: float | None = None,
) -> Dict[str, Any]:
    module = import_module("pystimela_optim.scripts.chlorination_optim")
    cfg = _load_config(config)
    algo = cfg.get("algorithm", {})

    inputs = module.QualityInputs.from_json(cfg["inputs"])
    params = module.Params(**cfg["params"])
    limits = module.Limits(**cfg["limits"])
    weights = module.Weights(**cfg["weights"])
    initials = module.InitialStates(**cfg["initials"])

    return module.solve(
        inputs,
        params,
        limits,
        weights,
        initials,
        seed=int(_resolve_algo_value(algo, "seed", seed, 42)),
        maxiter=int(_resolve_algo_value(algo, "maxiter", maxiter, 300)),
        popsize=int(_resolve_algo_value(algo, "popsize", popsize, 20)),
        tol=float(_resolve_algo_value(algo, "tol", tol, 1e-3)),
    )


def optimize_filtration(
    config: ConfigLike,
    *,
    seed: int | None = None,
    maxiter: int | None = None,
    popsize: int | None = None,
    tol: float | None = None,
    workers: int | None = None,
    bw_freq_h: float | None = None,
) -> Dict[str, Any]:
    module = import_module("pystimela_optim.scripts.filtration_optim")
    cfg = _load_config(config)
    algo = cfg.get("algorithm", {})

    inputs = module.QualityInputs.from_json(cfg["inputs"])
    params = module.Params(**cfg["params"])
    limits = module.Limits(**cfg["limits"])
    weights = module.Weights(**cfg["weights"])
    initials = module.InitialStates(**cfg["initials"])

    resolved_bw_freq_h = float(cfg.get("backwash_freq_h", 0.0))
    if bw_freq_h is not None:
        resolved_bw_freq_h = float(bw_freq_h)

    backwash_events = _build_backwash_events(
        module,
        inputs.timestamps,
        resolved_bw_freq_h,
    )

    return module.solve(
        inputs,
        params,
        limits,
        weights,
        initials,
        backwash_events,
        seed=int(_resolve_algo_value(algo, "seed", seed, 42)),
        maxiter=int(_resolve_algo_value(algo, "maxiter", maxiter, 300)),
        popsize=int(_resolve_algo_value(algo, "popsize", popsize, 30)),
        tol=float(_resolve_algo_value(algo, "tol", tol, 1e-3)),
        workers=int(_resolve_algo_value(algo, "workers", workers, 1)),
    )


def optimize_dual_filtration(
    config: ConfigLike,
    *,
    seed: int | None = None,
    maxiter: int | None = None,
    popsize: int | None = None,
    tol: float | None = None,
    workers: int | None = None,
    bw_freq_h: float | None = None,
) -> Dict[str, Any]:
    module = import_module("pystimela_optim.scripts.dual_filtration_optim")
    cfg = _load_config(config)
    algo = cfg.get("algorithm", {})

    inputs = module.QualityInputs.from_json(cfg["inputs"])
    params = module.Params(**cfg["params"])
    limits = module.Limits(**cfg["limits"])
    weights = module.Weights(**cfg["weights"])
    initials = module.InitialStates(**cfg["initials"])

    resolved_bw_freq_h = float(cfg.get("backwash_freq_h", 0.0))
    if bw_freq_h is not None:
        resolved_bw_freq_h = float(bw_freq_h)

    backwash_events = _build_backwash_events(
        module,
        inputs.timestamps,
        resolved_bw_freq_h,
    )

    return module.solve(
        inputs,
        params,
        limits,
        weights,
        initials,
        backwash_events,
        seed=int(_resolve_algo_value(algo, "seed", seed, 42)),
        maxiter=int(_resolve_algo_value(algo, "maxiter", maxiter, 300)),
        popsize=int(_resolve_algo_value(algo, "popsize", popsize, 30)),
        tol=float(_resolve_algo_value(algo, "tol", tol, 1e-3)),
        workers=int(_resolve_algo_value(algo, "workers", workers, 1)),
    )


def optimize_gac(
    config: ConfigLike,
    *,
    seed: int | None = None,
    maxiter: int | None = None,
    popsize: int | None = None,
    tol: float | None = None,
    workers: int | None = None,
    bw_freq_h: float | None = None,
) -> Dict[str, Any]:
    module = import_module("pystimela_optim.scripts.gac_optim")
    cfg = _load_config(config)
    algo = cfg.get("algorithm", {})

    inputs = module.QualityInputs.from_json(cfg["inputs"])
    params = module.Params(**cfg["params"])
    limits = module.Limits(**cfg["limits"])
    weights = module.Weights(**cfg["weights"])
    initials = module.InitialStates(**cfg["initials"])

    resolved_bw_freq_h = float(cfg.get("backwash_freq_h", 0.0))
    if bw_freq_h is not None:
        resolved_bw_freq_h = float(bw_freq_h)

    backwash_events = _build_backwash_events(
        module,
        inputs.timestamps,
        resolved_bw_freq_h,
    )

    return module.solve(
        inputs,
        params,
        limits,
        weights,
        initials,
        backwash_events,
        seed=int(_resolve_algo_value(algo, "seed", seed, 42)),
        maxiter=int(_resolve_algo_value(algo, "maxiter", maxiter, 100)),
        popsize=int(_resolve_algo_value(algo, "popsize", popsize, 20)),
        tol=float(_resolve_algo_value(algo, "tol", tol, 1e-3)),
        workers=int(_resolve_algo_value(algo, "workers", workers, 1)),
    )


def optimize_ozonation(
    config: ConfigLike,
    *,
    seed: int | None = None,
    maxiter: int | None = None,
    popsize: int | None = None,
    tol: float | None = None,
    workers: int | None = None,
) -> Dict[str, Any]:
    module = import_module("pystimela_optim.scripts.ozonation_optim")
    cfg = _load_config(config)
    algo = cfg.get("algorithm", {})

    inputs = module.QualityInputs.from_json(cfg["inputs"])
    params = module.Params(**cfg["params"])
    limits = module.Limits(**cfg["limits"])
    weights = module.Weights(**cfg["weights"])
    initials = module.InitialStates(**cfg["initials"])

    return module.solve(
        inputs,
        params,
        limits,
        weights,
        initials,
        seed=int(_resolve_algo_value(algo, "seed", seed, 42)),
        maxiter=int(_resolve_algo_value(algo, "maxiter", maxiter, 300)),
        popsize=int(_resolve_algo_value(algo, "popsize", popsize, 30)),
        tol=float(_resolve_algo_value(algo, "tol", tol, 1e-3)),
        workers=int(_resolve_algo_value(algo, "workers", workers, 1)),
    )


_OPTIMIZER_MAP: dict[str, Callable[..., Dict[str, Any]]] = {
    "coagulation-flocculation": optimize_coag_floc,
    "chlorination": optimize_chlorination,
    "filtration_single": optimize_filtration,
    "filtration_dual": optimize_dual_filtration,
    "gac": optimize_gac,
    "ozonation": optimize_ozonation,
}


def optimize_process(
    process: str,
    config: ConfigLike,
    **overrides: Any,
) -> Dict[str, Any]:
    """Run a single process optimizer by process key.

    Supported process keys:
    - coagulation-flocculation
    - chlorination
    - filtration_single
    - filtration_dual
    - gac
    - ozonation
    """
    try:
        runner = _OPTIMIZER_MAP[process]
    except KeyError as exc:
        valid = ", ".join(sorted(_OPTIMIZER_MAP))
        raise ValueError(
            f"Unknown process '{process}'. Valid values: {valid}"
        ) from exc

    return runner(config, **overrides)


__all__ = [
    "optimize_coag_floc",
    "optimize_chlorination",
    "optimize_filtration",
    "optimize_dual_filtration",
    "optimize_gac",
    "optimize_ozonation",
    "optimize_process",
]
