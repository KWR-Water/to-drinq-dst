"""
Configuration Preparation Tool for Ozonation Optimization

This module builds the optimization configuration from a CSV file. It:
- Reads baseline design from django_outputs.json
- Automatically generates process bounds with configurable scaling
- Allows manual override of all parameters
- Validates inputs and generates final JSON configuration

The generated configuration is consumed by ozonation_optim.py.
"""

import json
import os
import sys
from typing import Dict, Any
import csv

# ============================================================================
# Constants and Defaults
# ============================================================================

# Fixed scaling factor for bounds: Â±10Ã— baseline values
BOUNDS_SCALE = 10.0

# Default penalty weights for constraint violations
DEFAULT_WEIGHTS = {
    "lam_BrO3": 1e5,
    "lam_AOC": 1e5,
    "lam_Ecoli": 1e6,
    "lam_theta": 1e6,
    "lam_aspect": 1e5,
}

# Default differential evolution algorithm parameters
DEFAULT_ALGO = {
    "seed": 42,
    "maxiter": 60,
    "popsize": 10,
    "tol": 0.01,
    "workers": 1,
}

# Default process model parameters
DEFAULT_PARAMS = {
    # Ozonation kinetic parameters
    "kuv_sel": True,
    "kuv": 0.5,
    "y_factor": 0.01,
    "kafbo3_sel": True,
    "kafbo3": 0.27164,
    "factor_klo3": 0.04,
    "db0": 3.0,
    "ceuva254_sel": True,
    "ceuva254": 3.0,
    "f_bro3init": 2.5,
    "kct_bro3_sel": True,
    "ktc_bro3": 3.0,
    "f_aoc_sel": True,
    "f_aoc": 50.0,
    "kec_sel": True,
    "kec": 300.0,
    "ct_lagec": 0.01,
    "numcel": 1,
    # Energy parameters
    "sec_kwh_per_kg_o3": 15.0,
    "elec_eur_per_kwh": 0.14,
    "hours_per_year": 8765,
    # Financial parameters
    "n_years": 40,
    "r_nom": 0.05,
    "infl": 0.031,
    # Flow configuration
    "meetee": True,
}

# Fixed file paths
DJANGO_JSON_PATH = "configs/django_outputs.json"
OUT_JSON_PATH = "configs/ozonation_config.json"
WQ_JSON_PATH = "configs/in_wq_params.json"

TIMESTAMPS_CSV_PATH = "inputs/timestamps/ozonation.csv"
PLANT_DESIGN_CSV_PATH = "inputs/django_plant_design.csv"


def read_plant_design(path: str) -> Dict[str, Any]:
    """Read plant-wide economic parameters (n_years, r_nom, infl) from CSV."""
    values = {}
    with open(path, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter=";"):
            values[row["parameters"].strip()] = row["value"].strip()
    return {
        "n_years": int(values["n_years"]),
        "r_nom": float(values["r_nom"]),
        "infl": float(values["infl"]),
    }


# ============================================================================
# Load configurations from csv
# ============================================================================

def load_config_from_csv(csv_path: str):
    config = {'decision_variables': {}, 'constraints': {}, 'model_parameters': {},
              'penalties': {}, 'optimization': {}, 'initials': {}, 'simulation': {}}
    with open(csv_path, 'r') as f:
        # Read a sample of the file to detect the delimiter automatically
        sample = f.read(2048)
        f.seek(0)

        # Try to guess the delimiter (usually ',' or ';' or '\t')
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample)
        except csv.Error:
            # fallback if detection fails (e.g., single-line CSV)
            dialect = csv.get_dialect('excel')
            dialect.delimiter = ','
        reader = csv.DictReader(f, dialect=dialect)
        reader.fieldnames = [name.strip().lstrip('\ufeff') for name in reader.fieldnames]
        for row in reader:
            section = row['section'].lower().replace('-', '_')
            param, value = row['parameter'], row['value']
            if value.lower() == 'auto': converted_value = 'auto'
            elif value.lower() in ('true', 'false'): converted_value = value.lower() == 'true'
            else:
                try: converted_value = float(value) if '.' in value else int(value)
                except ValueError: converted_value = value
            if section in config: config[section][param] = converted_value
    return config

# ============================================================================
# JSON I/O Utilities
# ============================================================================

def load_json(path: str) -> Dict[str, Any]:
    """Load JSON file and return as dictionary."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: Dict[str, Any]) -> None:
    """Write dictionary to JSON file with automatic directory creation."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def read_timestamps(path: str) -> list:
    """Read timestamps CSV (single column 'time_s') and return list of floats."""
    with open(path, "r") as f:
        lines = [l.strip() for l in f if l.strip()]
    # skip header if it starts with a letter
    return [float(l) for l in lines if not l[0].isalpha()]


# ============================================================================
# Configuration Builders
# ============================================================================

def build_limits_from_django(
        django_json_path: str,
        scale: float,
        bromate_max: float,
        aoc_max: float,
        theta_min: float = 5.0,   # new
        theta_max: float = 60.0,   # new
        aspect_ratio_min: float = 1.0,
        aspect_ratio_max: float = 15.0
) -> Dict[str, float]:
    """
    Generate optimization bounds from baseline design values.

    Reads baseline design parameters from django_outputs.json and expands
    them into min/max bounds using the specified scale factor.

    Args:
        django_json_path: Path to django outputs JSON
        scale: Scaling factor for bounds (±scale — baseline)
        bromate_max: Maximum bromate [µg/L]
        aoc_max: Maximum AOC [µg/L]

    Returns:
        Dictionary of process limits

    Raises:
        KeyError: If expected fields are missing from django JSON
    """
    data = load_json(django_json_path)

    # Django outputs are nested under "Process_outputs"
    base = data.get("Process_outputs", data)


    try:
        # Extract ozonation parameters
        areact_base = float(base["ozonation_area"]["value"])
        hreact_base = float(base["ozonation_height"]["value"])
        ozon_dose = float(base["ozonation_chemical_dose"]["value"])
    except Exception as e:
        raise KeyError(f"Missing expected fields in {django_json_path}: {e}")

    return {
        # Ozone dose bounds [mg/L]
        "ozone_dosed_min": ozon_dose / scale,
        "ozone_dosed_max": ozon_dose * scale,
        # Reactor height bounds [m]
        "hreact_min": hreact_base / scale,
        "hreact_max": hreact_base * scale,
        # Reactor area bounds [m²]
        "areact_min": areact_base / scale,
        "areact_max": areact_base * scale,
        # Residence time constraints [min]
        "theta_min": theta_min,
        "theta_max": theta_max,
        # Reactor shape plausibility (height/diameter)
        "aspect_ratio_min": aspect_ratio_min,
        "aspect_ratio_max": aspect_ratio_max,
        # Effluent quality constraints
        "bromate_max": bromate_max,
        "aoc_max": aoc_max,

    }


def read_wq_params(json_path: str) -> Dict[str, Any]:
    """
    Read inlet water quality parameters from JSON.

    Extracts and remaps WQ parameters for downstream processing.
    Converts keys to lowercase/snake_case for consistency.

    Args:
        json_path: Path to water quality parameters JSON

    Returns:
        Dictionary with remapped WQ parameter keys
    """
    data = load_json(json_path)
    wp = data["WQ_parameters"]

    return {
        "flow": wp["flow"],
        "temperature": wp["temperature"],
        "doc": wp["DOC"],  # DOC
        "ozone": {"units": "mg/L", "value": 0.0},
        "ph": wp["pH"],  # pH  p
        "uv254": wp["uv254"],
        "bromide": wp["bromide"],
        "bromate": wp["bromate"],
        "ozone_dosed": {"units": "mg/L", "value": 0.0},
        "ecoli": wp["ecoli"],
        "aoc": wp.get("AOC", {"units": "ug/L", "value": 30.0}),
        "gas_flow": {"units": "m3/h", "value": 0.0},
        "cgo_o3": {"units": "mg/L", "value": 0.0},
    }


def assemble_config(
        meetee: bool,
        limits: Dict[str, Any],
        initials: Dict[str, Any],
        params: Dict[str, Any],
        wq_params: Dict[str, Any],
        timestamps: list = None,
) -> Dict[str, Any]:
    """
    Assemble final configuration JSON structure.

    Combines all configuration components into the structure expected
    by ozonation_optim.py.

    Args:
        meetee: Co-current (True) or counter-current (False) flow
        limits: Process limits dictionary
        initials: Initial states dictionary
        params: Process parameters dictionary
        wq_params: Water quality parameters dictionary

    Returns:
        Complete configuration dictionary ready for JSON export
    """
    # Add meetee to params
    params = dict(params)
    params["meetee"] = meetee

    # Build bounds list for documentation
    bounds_list = [
        {
            "name": "ozone_dosed_mgL",
            "min": limits["ozone_dosed_min"],
            "max": limits["ozone_dosed_max"],
            "units": "mg/L"
        },
        {
            "name": "hreact_m",
            "min": limits["hreact_min"],
            "max": limits["hreact_max"],
            "units": "m"
        },
        {
            "name": "areact_m2",
            "min": limits["areact_min"],
            "max": limits["areact_max"],
            "units": "m2"
        },
    ]

    return {
        "process": "ozonation",
        "inputs": {
            "timestamps": timestamps if timestamps is not None else [1, 3600],
            "wq_parameters": wq_params,
        },
        "meetee": meetee,
        "limits": limits,
        "initials": initials,
        "weights": DEFAULT_WEIGHTS,
        "params": params,
        "algorithm": DEFAULT_ALGO,
        "bounds": bounds_list,
        "notes": {
            "source": "auto-generated from django_outputs.json",
            "wq_csv_format": (
                "semicolon-delimited; headers: "
                "timestamp;flow;temperature;doc;ozone;ph;uv254;bromide;bromate;"
                "ozone_dosed;ecoli;aoc;gas_flow;cgo_o3"
            ),
            "scaling": (
                f"bounds derived using ±{BOUNDS_SCALE}— from django base values"
            )
        }
    }


def generate_config_from_csv(csv_path: str, wq_json_path: str):
    """Generate ozonation config JSON from CSV configuration file."""
    csv_config = load_config_from_csv(csv_path)
    wq_params = read_wq_params(wq_json_path)
    use_auto = csv_config['decision_variables'].get('use_auto_bounds', True)

    # Build limits from django or use CSV values
    auto_limits = build_limits_from_django(
        DJANGO_JSON_PATH, 
        BOUNDS_SCALE,
        csv_config['constraints'].get('bromate_max', 10.0),
        csv_config['constraints'].get('aoc_max', 100.0),
        csv_config['constraints'].get('theta_min', 5.0),
        csv_config['constraints'].get('theta_max', 60.0),
        csv_config['constraints'].get('aspect_ratio_min', 1.0),
        csv_config['constraints'].get('aspect_ratio_max', 15.0)


    )

    final_limits = auto_limits if use_auto else dict(auto_limits)
    if not use_auto:
        dv = csv_config['decision_variables']
        for key in ['ozone_dosed_min', 'ozone_dosed_max', 'hreact_min', 'hreact_max', 'areact_min', 'areact_max']:
            if key in dv and dv[key] != 'auto': 
                final_limits[key] = dv[key]
    # ADD:
    final_limits['theta_min'] = csv_config['constraints'].get('theta_min', 5.0)
    final_limits['theta_max'] = csv_config['constraints'].get('theta_max', 60.0)
    final_limits['aspect_ratio_min'] = csv_config['constraints'].get('aspect_ratio_min', 1.0)
    final_limits['aspect_ratio_max'] = csv_config['constraints'].get('aspect_ratio_max', 15.0)

    # Build params from CSV (including meetee)
    params = dict(DEFAULT_PARAMS)
    for key, val in csv_config.get('model_parameters', {}).items():
        # Accept all parameters from CSV, including meetee
        params[key] = val

    # Override plant-wide economic parameters from the shared plant-design file
    if os.path.exists(PLANT_DESIGN_CSV_PATH):
        plant = read_plant_design(PLANT_DESIGN_CSV_PATH)
        params["n_years"] = plant["n_years"]
        params["r_nom"] = plant["r_nom"]
        params["infl"] = plant["infl"]

    # Build initials from CSV
    initials = {
        "o3_liquid_initial": 0.0,
        "o3_gas_initial": 0.0,
        "uv254_initial": 0.0,
        "bromate_initial": 0.0,
        "ecoli_initial": 0.0,
        "ct_ecoli_initial": 0.0,
    }
    for key, val in csv_config.get('initials', {}).items():
        if key in initials:
            initials[key] = float(val)

    # Build weights from CSV
    weights = dict(DEFAULT_WEIGHTS)
    for key, val in csv_config.get('penalties', {}).items():
        if key in weights: 
            weights[key] = val

    # Build algorithm from CSV
    algo = dict(DEFAULT_ALGO)
    for key, val in csv_config.get('optimization', {}).items():
        if key in algo: 
            algo[key] = val

    timestamps = read_timestamps(TIMESTAMPS_CSV_PATH)

    # Extract meetee value for top-level field (it will also be in params)
    meetee = params.get('meetee', True)

    # Build bounds array for the JSON structure
    bounds = [
        {
            "name": "ozone_dosed_mgL",
            "min": final_limits["ozone_dosed_min"],
            "max": final_limits["ozone_dosed_max"],
            "units": "mg/L"
        },
        {
            "name": "hreact_m",
            "min": final_limits["hreact_min"],
            "max": final_limits["hreact_max"],
            "units": "m"
        },
        {
            "name": "areact_m2",
            "min": final_limits["areact_min"],
            "max": final_limits["areact_max"],
            "units": "m2"
        }
    ]

    # Assemble final configuration matching target JSON structure
    config = {
        "process": "ozonation",
        "inputs": {
            "timestamps": timestamps,
            "wq_parameters": wq_params
        },
        "meetee": meetee,
        "limits": final_limits,
        "initials": initials,
        "weights": weights,
        "params": params,
        "algorithm": algo,
        "bounds": bounds,
        "notes": {
            "source": "auto-generated from CSV configuration",
            "wq_csv_format": "semicolon-delimited; headers: timestamp;flow;temperature;doc;ozone;ph;uv254;bromide;bromate;ozone_dosed;ecoli;aoc;gas_flow;cgo_o3",
            "scaling": f"bounds derived using ±{BOUNDS_SCALE}× from django base values"
        }
    }

    write_json(OUT_JSON_PATH, config)
    print(f"Configuration saved to: {OUT_JSON_PATH}")
    print(f"   Process: {config['process']}")
    print(f"   MEETEE: {meetee}")
    print(f"   Decision variables: {len(bounds)}")
    print(f"   Constraints: bromate_max={final_limits['bromate_max']}, aoc_max={final_limits['aoc_max']}")
    print(f"   Theta: min={final_limits['theta_min']}, max={final_limits['theta_max']}")  # ✅ ADD THIS


# ============================================================================
# Entry Point
# ============================================================================

def main(argv=None) -> None:
    """CLI entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="Prepare ozonation optimization configuration.")
    parser.add_argument("--in_wq_params", required=True)
    parser.add_argument("--csv_config", default="inputs/config_ozonation.csv")
    args = parser.parse_args(argv)

    WQ_JSON_PATH = args.in_wq_params
    if not os.path.exists(WQ_JSON_PATH):
        sys.exit(f"Error: WQ parameters file not found at {WQ_JSON_PATH}")
    if not os.path.exists(args.csv_config):
        sys.exit(f"Error: CSV config file not found at {args.csv_config}")

    print(f"Loaded WQ parameters from: {WQ_JSON_PATH}")
    generate_config_from_csv(args.csv_config, WQ_JSON_PATH)


if __name__ == "__main__":
    main()
