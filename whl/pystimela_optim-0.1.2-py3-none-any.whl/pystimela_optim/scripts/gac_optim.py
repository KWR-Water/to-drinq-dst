from __future__ import annotations

"""
GAC Filtration Process Optimization

This module optimizes water treatment GAC (Granular Activated Carbon) filtration
processes using differential evolution. It minimizes total annual costs (construction,
maintenance, materials, carbon replacement) subject to water quality constraints
(DOC removal).

Key Components:
- Process simulation via PyStimela
- Multi-objective scalarization with penalty functions
- Economic evaluation (CAPEX/OPEX)
- Differential evolution optimization
- Backwash schedule management
"""

import json
import argparse
from importlib import import_module
from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
from scipy.optimize import differential_evolution

datatypes = None
dwtmodels = None


def _require_pystimela() -> None:
    """Load pystimela lazily and raise a clear runtime dependency error."""
    global datatypes, dwtmodels
    if datatypes is not None and dwtmodels is not None:
        return

    try:
        datatypes = import_module("pystimela.datatypes")
        dwtmodels = import_module("pystimela.dwtmodels")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "The 'pystimela' package is required to run optimization. "
            "Install pystimela to execute this command."
        ) from exc


# ============================================================================
# Configuration Dataclasses
# ============================================================================

@dataclass
class Limits:
    """
    Process limits for regulatory/operational bounds.

    Control variable bounds define the search space for optimization.
    Constraint bounds define feasibility requirements for the solution.
    """
    # Control variable bounds
    surf_min_m2: float = 1.0  # [m²] minimum filter surface area
    surf_max_m2: float = 100.0  # [m²] maximum filter surface area
    lbed_min_m: float = 0.1  # [m] minimum bed height (media depth)
    lbed_max_m: float = 20.0  # [m] maximum bed height (media depth)

    # NEW: Residence time constraints
    theta_min: float = 5.0
    theta_max: float = 60.0

    # Constraint bounds (effluent quality requirements)
    doc_out_max: float = 0.5  # [mg/L] maximum effluent DOC


@dataclass
class Weights:
    """
    Penalty weights for constraint violations in scalarized objective.

    These multipliers convert constraint violations into cost penalties,
    implementing a soft-constraint approach (big-M method).
    """
    lam_DOC: float = 1e6  # penalty weight for DOC violations

    lam_theta: float = 1e6  # penalty weight for residence time violations


@dataclass
class InitialStates:
    """
    Initial conditions for GAC filtration unit process.

    These values represent the starting state of the filter,
    particularly the DOC concentration and accumulated adsorbed DOC.
    """
    doc_initial: float = 0.0  # [mg/L] initial DOC concentration
    accum_initial: float = 0.0  # [mg/kg] initial accumulated adsorbed DOC


@dataclass
class Params:
    """
    Process model parameters for GAC filtration.

    Includes:
    - Physical parameters (porosity, particle diameter, GAC density)
    - Kinetic parameters (Freundlich adsorption parameters, mass transfer)
    - Economic parameters (costs, financial factors)
    - Reactor configuration (number of cells)
    """
    # Physical parameters
    diam: float = 2.0  # [mm] GAC particle diameter
    filporo: float = 50.0  # [%] filter porosity
    rho_k: float = 500.0  # [kg/m³] GAC density

    # Kinetic parameters (Freundlich adsorption)
    freund_n: float = 0.5  # [-] Freundlich exponent
    freund_k: float = 20.0  # [(g/kg)(m³/g)^n] Freundlich adsorption coefficient
    mass_tr_coef_k2: float = 0.006  # [1/h] mass transfer coefficient
    numcel: int = 5  # number of completely mixed reactor cells

    # Financial parameters for CAPEX annualization
    n_years: int = 40  # project lifetime [years]
    r_nom: float = 0.05  # nominal interest rate (Netherlands: 5%, Greece: 7%)
    infl: float = 0.031  # inflation rate (Netherlands: 3.1%, Greece: 3.6%)
    gac_replacement_cost: float = 5000.0  # [€/t] cost per ton of GAC

# ============================================================================
# Water Quality Input Handling
# ============================================================================

class QualityInputs:
    """
    Time-series water quality parameters for GAC filtration simulation.

    Constructs time-series arrays from CSV file or JSON configuration,
    representing inlet water characteristics over the simulation period.
    """

    COLUMNS = [
        "timestamp", "flow", "temperature", "doc"
    ]

    def __init__(self, timestamps: List[float], **attrs):
        """
        Initialize with timestamps and water quality attributes.

        Args:
            timestamps: List of time points [s]
            **attrs: Water quality parameters as numpy arrays
        """
        self.timestamps = timestamps
        self.__dict__.update(attrs)

    @classmethod
    def from_json(cls, inputs_dict: Dict) -> "QualityInputs":
        """
        Build QualityInputs from JSON-style configuration dictionary.

        Args:
            inputs_dict: Configuration with timeframe, timestep, and wq_parameters

        Returns:
            QualityInputs instance with constant time-series
        """
        timestamps = inputs_dict["timestamps"]
        n_steps = len(timestamps)

        wq_params = inputs_dict["wq_parameters"]

        def get_val(key: str) -> float:
            """Extract value from wq_parameters dict, return NaN if missing."""
            return float(wq_params[key]["value"]) if key in wq_params else np.nan

        # Create constant time-series arrays for each parameter
        return cls(
            timestamps=timestamps,
            flow=np.full(n_steps, get_val("flow")),
            temperature=np.full(n_steps, get_val("temperature")),
            doc=np.full(n_steps, get_val("doc"))
        )

    def to_wq_list(self) -> List[datatypes.WaterQualityParams]:
        """
        Convert to PyStimela WaterQualityParams list.

        Returns:
            List of WaterQualityParams objects for each timestep
        """
        _require_pystimela()
        fields = [c for c in self.COLUMNS if c != "timestamp"]
        n = len(self.timestamps)
        wq_list = []

        for i in range(n):
            kwargs = {name: float(getattr(self, name)[i]) for name in fields}
            wq = datatypes.WaterQualityParams(timestamp=self.timestamps[i], **kwargs)
            wq_list.append(wq)

        return wq_list


# ============================================================================
# Backwash Schedule Generation
# ============================================================================

def generate_backwash_events(timestamps: List[float], freq_h: float) -> List[bool]:
    """
    Generate backwash event schedule based on fixed time frequency.

    Args:
        timestamps: List of simulation time points [s]
        freq_h: Backwash frequency [hours] (0 = no backwash)

    Returns:
        List of boolean flags indicating backwash events at each timestep
    """
    events = [False] * len(timestamps)

    if freq_h > 0:
        # Convert timestamps from seconds to hours
        times_h = np.array(timestamps) / 3600.0
        last_bw = 0.0

        for i, t in enumerate(times_h):
            if t - last_bw >= freq_h:
                events[i] = True
                last_bw = t

    return events


# ============================================================================
# Process Simulation
# ============================================================================

def stimela_simulate(
        inputs: QualityInputs,
        params: Params,
        initials: InitialStates,
        surf_m2: float,
        lbed_m: float,
        backwash_events: List[bool],
) -> Dict[str, float]:
    """
    Simulate GAC filtration process using PyStimela.

    This wrapper orchestrates the GAC filtration simulation with backwash events.

    Args:
        inputs: Time-series water quality parameters
        params: Process model parameters
        initials: Initial state conditions
        surf_m2: Filter surface area [m²]
        lbed_m: Bed height (media depth) [m]
        backwash_events: Boolean list indicating backwash at each timestep

    Returns:
        Dictionary with GAC filtration performance metrics:
        - DOC_out_mgL: effluent dissolved organic carbon [mg/L]
    """
    _require_pystimela()
    timestamps = inputs.timestamps

    # ---- GAC Filtration Parameters ----
    gac_params = datatypes.GACFiltrationParams(
        f_area=surf_m2,
        lbed=lbed_m,
        diam=params.diam,
        filporo=params.filporo,
        freund_n=params.freund_n,
        freund_k=params.freund_k,
        rho_k=params.rho_k,
        mass_tr_coef_k2=params.mass_tr_coef_k2,
        numcel=params.numcel
    )

    # Prepare input water quality
    in_wq_list = inputs.to_wq_list()
    in_wq_params = datatypes.ListWaterQualityParams(
        timestamps=timestamps,
        wqparams=in_wq_list
    )

    # Initialize GAC state in all compartments
    numcel = gac_params.numcel
    doc_initial = [initials.doc_initial] * numcel
    accum_initial = [initials.accum_initial] * numcel

    gac_init_state = datatypes.GACFiltrationState(
        doc=doc_initial,
        init_accumulation=accum_initial
    )

    # Prepare backwash schedule
    backwash_schedule = datatypes.BackWashData(
        timestamps=timestamps,
        events=backwash_events
    )

    # Run GAC filtration simulation
    gac_process = dwtmodels.GACFiltration(params=gac_params)
    gac_results = gac_process.simulate(
        t_eval=timestamps,
        init_state=gac_init_state.to_numpy(),
        wq_params=in_wq_params,
        bw=backwash_schedule
    )

    # Extract effluent DOC (final timestep)
    doc_out = gac_results['out_wqparams'][-1].doc

    # Calculate residence time [minutes]
    volume_m3 = surf_m2 * lbed_m
    avg_flow = float(np.mean(inputs.flow))  # m³/h
    theta = (volume_m3 / avg_flow) * 60.0  # convert hours to minutes

    return {
        "DOC_out_mgL": float(doc_out),
        "theta_min": theta
    }


# ============================================================================
# Economic Calculations
# ============================================================================

def capital_recovery_factor(r_real: float, n: int) -> float:
    """
    Calculate Capital Recovery Factor for CAPEX annualization.

    CRF converts a present value to equivalent annual cost over n years
    at real interest rate r_real.

    Args:
        r_real: Real interest rate (adjusted for inflation)
        n: Project lifetime [years]

    Returns:
        Capital recovery factor [-]
    """
    return (r_real * (1 + r_real) ** n) / ((1 + r_real) ** n - 1)


def compute_construction_cost(total_volume_m3: float, crf: float) -> float:
    """
    Calculate annualized construction cost using empirical equation.

    Args:
        total_volume_m3: Total filter volume (surface × depth) [m³]
        crf: Capital recovery factor

    Returns:
        Annualized construction cost [€/year]
    """
    return crf * (8921.74 * total_volume_m3 + 1_342_431.26)


def compute_maintenance_cost(total_volume_m3: float) -> float:
    """
    Calculate annual maintenance cost using empirical equation.

    Args:
        total_volume_m3: Total filter volume [m³]

    Returns:
        Annual maintenance cost [€/year]
    """
    return 179.327 * total_volume_m3 + 30582.8684


def compute_materials_cost(total_volume_m3: float) -> float:
    """
    Calculate annual materials cost using empirical equation.

    Args:
        total_volume_m3: Total filter volume [m³]

    Returns:
        Annual materials cost [€/year]
    """
    return 1152.3569 * total_volume_m3

def compute_constraint_penalties(
        DOC_out: float,
        theta: float,
        limits: Limits,
        weights: Weights
) -> float:
    """
    Calculate soft-constraint penalty for violations.

    Implements big-M penalty method for constraint violations:
    - DOC exceeding doc_out_max

    Args:
        DOC_out: Effluent DOC [mg/L]
        limits: Constraint limits
        weights: Penalty weights

    Returns:
        Total penalty value (unitless, added to objective)
    """
    penalty = 0.0

    # DOC constraint (upper bound, normalized)
    v_doc = max(0.0, (DOC_out - limits.doc_out_max) / max(limits.doc_out_max, 1e-6))
    penalty += weights.lam_DOC * v_doc

    # Residence time constraint (minimum)
    if theta < limits.theta_min:
        v_theta_min = (limits.theta_min - theta) / max(limits.theta_min, 1e-6)
        penalty += weights.lam_theta * v_theta_min

    # Residence time constraint (maximum)
    if theta > limits.theta_max:
        v_theta_max = (theta - limits.theta_max) / max(limits.theta_max, 1e-6)
        penalty += weights.lam_theta * v_theta_max

    return penalty


# ============================================================================
# Optimization Objective Function
# ============================================================================

def objective_scalar(
        x: np.ndarray,
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        backwash_events: List[bool]
) -> Tuple[float, Dict[str, float]]:
    """
    Scalarized objective function: minimize total annual cost + penalties.

    This is the function minimized by differential evolution. It:
    1. Unpacks decision variables
    2. Simulates the GAC filtration process
    3. Computes base costs (construction, maintenance, materials, GAC replacement)
    4. Adds constraint violation penalties

    Args:
        x: Decision vector [surf_m2, lbed_m]
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        backwash_events: Backwash schedule

    Returns:
        Tuple of (objective_value, cost_breakdown_dict)
    """
    # Unpack decision variables
    surf_m2 = float(x[0])
    lbed_m = float(x[1])

    # Total volume
    total_volume_m3 = surf_m2 * lbed_m

    # Simulate process
    sim = stimela_simulate(
        inputs, params, initials,
        surf_m2, lbed_m,
        backwash_events
    )

    DOC_out = sim["DOC_out_mgL"]
    theta_out = sim["theta_min"]

    # ---- Cost Components ----

    # Calculate real interest rate and CRFs
    r_real = (1 + params.r_nom) / (1 + params.infl) - 1
    crf = capital_recovery_factor(r_real, params.n_years)
    crf_10 = capital_recovery_factor(r_real, 10)  # For 10-year GAC replacement

    # Construction cost [€/year]
    const_cost = compute_construction_cost(total_volume_m3, crf)

    # Maintenance cost [€/year]
    maint_cost = compute_maintenance_cost(total_volume_m3)

    # Materials cost [€/year]
    materials_cost = compute_materials_cost(total_volume_m3)

    # Base objective (total annual cost)
    base = const_cost + maint_cost + materials_cost

    # ---- Constraint Penalties ----
    penalty = compute_constraint_penalties(DOC_out, theta_out, limits, weights)

    # Total objective
    objective_value = base + penalty

    # Detailed cost breakdown
    cost_breakdown = {
        "r_nom": round(params.r_nom,3),
        "infl": round(params.infl,3),
        "r_real": round(r_real,3),
        "CRF_n": round(crf,3),
        "CRF_10": round(crf_10,3),
        "construction_cost_eur_per_year": round(const_cost,3),
        "maintenance_cost_eur_per_year": round(maint_cost,3),
        "materials_cost_eur_per_year": round(materials_cost,3),
        "DOC_out_mgL": round(DOC_out,5),
        "penalty": round(penalty,3),
        "theta_min": round(theta_out,2)
    }

    return objective_value, cost_breakdown


# ============================================================================
# Optimization Solver
# ============================================================================

def solve(
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        backwash_events: List[bool],
        seed: int = 42,
        maxiter: int = 60,
        popsize: int = 15,
        tol: float = 1e-3,
        workers: int = 1
) -> Dict:
    """
    Solve optimization problem using differential evolution.

    Minimizes total annual cost subject to water quality constraints
    by optimizing filter surface area and bed height.

    Args:
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        backwash_events: Backwash schedule
        seed: Random seed for reproducibility
        maxiter: Maximum number of DE iterations
        popsize: Population size for DE
        tol: Convergence tolerance
        workers: Number of parallel workers (1 = serial)

    Returns:
        Dictionary with optimization results, including:
        - success: optimization success flag
        - message: solver message
        - fun: optimal objective value
        - x_opt: optimal decision variables
        - outputs: effluent water quality
        - economics: detailed cost analysis
    """
    # Define decision variable bounds
    bounds = [
        (limits.surf_min_m2, limits.surf_max_m2),  # surface [m²]
        (limits.lbed_min_m, limits.lbed_max_m),  # bed height [m]
    ]

    # Wrapper for objective function (DE expects single return value)
    def objective_wrapper(x: np.ndarray) -> float:
        obj_val, _ = objective_scalar(
            x, inputs, params, limits, weights, initials, backwash_events
        )
        return obj_val

    # Run differential evolution
    result = differential_evolution(
        objective_wrapper,
        bounds=bounds,
        strategy="best1bin",
        maxiter=maxiter,
        popsize=popsize,
        tol=tol,
        mutation=(0.5, 1.0),
        recombination=0.7,
        seed=seed,
        polish=True,
        disp=True,
        workers=workers
    )

    # Unpack optimal solution
    x_opt = result.x
    surf_m2 = float(x_opt[0])
    lbed_m = float(x_opt[1])

    # Derived volume
    V_filter_m3 = surf_m2 * lbed_m

    # Re-evaluate objective to get detailed cost breakdown
    obj_val, costs = objective_scalar(
        x_opt, inputs, params, limits, weights, initials, backwash_events
    )

    # Separate simulation outputs from economics
    simulation_outputs = {
        "DOC_out_mgL": costs["DOC_out_mgL"],
        "theta_min": costs["theta_min"],
    }

    economics = {
        "r_nom": costs["r_nom"],
        "infl": costs["infl"],
        "r_real": costs["r_real"],
        "CRF_n": costs["CRF_n"],
        "CRF_10": costs["CRF_10"],
        "construction_cost_eur_per_year": round(costs["construction_cost_eur_per_year"], 1),
        "maintenance_cost_eur_per_year": round(costs["maintenance_cost_eur_per_year"], 1),
        "materials_cost_eur_per_year": round(costs["materials_cost_eur_per_year"], 1),
        "penalty_added_unitless": costs["penalty"],
        "obj_fun_value": round(obj_val, 1),
    }

    # Compile comprehensive results report
    report = {
        "success": bool(result.success),
        "message": str(result.message),
        "fun": round(float(result.fun), 2),
        "x_opt": {
            "gac_surface": round(surf_m2,1),
            "gac_depth": round(lbed_m,1)
        },
        "derived": {
            "V_filter_m3": round(V_filter_m3,2),
        },
        "inputs": {
            "flow_mean_m3h": float(np.mean(inputs.flow)),
            "DOC_in_mgL": float(np.mean(inputs.doc)),
        },
        "outputs": simulation_outputs,

        "constraints": {
            "doc_out_max_mgL": limits.doc_out_max,
            "lbed_range_m": (limits.lbed_min_m, limits.lbed_max_m),
            "surf_range_m2": (limits.surf_min_m2, limits.surf_max_m2),
            "theta_min": (limits.theta_min, limits.theta_max)
        },
        "economics": economics,
        "optimal variables": {
            "surf_m2": round(surf_m2,2),
            "lbed_m": round(lbed_m,2),
            "V_filter_m3": round(V_filter_m3,2)
        }
    }

    return report


# ============================================================================
# Command-Line Interface
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Run GAC filtration optimization from JSON config or CSV"
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to configuration JSON file"
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility"
    )
    parser.add_argument(
        "--maxiter",
        type=int,
        default=100,
        help="Maximum DE iterations"
    )
    parser.add_argument(
        "--popsize",
        type=int,
        default=20,
        help="DE population size"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of parallel workers"
    )
    parser.add_argument(
        "--out_json",
        type=str,
        default="outputs/gac_results.json",
        help="Path to output results JSON file"
    )
    parser.add_argument(
        "--bw_freq_h",
        type=float,
        default=0.0,
        help="Backwash frequency in hours (0 = no backwash)"
    )
    parser.add_argument(
        "--tol",
        type=float,
        default=1e-3,
        help="Convergence tolerance"
    )
    return parser


def parse_cli_args(argv=None) -> argparse.Namespace:
    """Parse CLI args for GAC optimization."""
    return build_parser().parse_args(argv)


def run_cli(args: argparse.Namespace) -> Dict:
    """Run optimization from parsed CLI args and write output JSON."""

    from pystimela_optim import api as optim_api

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    algo = cfg.get("algorithm", {})
    # Keep historical behavior: config algorithm/backwash values take precedence.
    seed = algo.get("seed", args.seed)
    maxiter = algo.get("maxiter", args.maxiter)
    popsize = algo.get("popsize", args.popsize)
    workers = algo.get("workers", args.workers)
    tol = algo.get("tol", 1e-3)
    bw_freq_h = cfg.get("backwash_freq_h", 0.0)

    report = optim_api.optimize_gac(
        cfg,
        seed=seed,
        maxiter=maxiter,
        popsize=popsize,
        workers=workers,
        tol=tol,
        bw_freq_h=bw_freq_h,
    )

    # Save results
    import os
    os.makedirs(os.path.dirname(args.out_json) or ".", exist_ok=True)
    with open(args.out_json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\nResults saved to {args.out_json}")
    return report


def main(argv=None):
    """CLI entry point."""
    args = parse_cli_args(argv)
    run_cli(args)


if __name__ == "__main__":
    main()
