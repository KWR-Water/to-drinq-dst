import pandas as pd
import json
import argparse
import os
import sys


def prepare_django_outputs(in_csv: str, out_json: str):
    """
    Reads a CSV with exact columns:
    [parameters, units, value]
    and writes a JSON file in nested format.

    Example output:
    {
        "Process_outputs": {
            "coagulation_volume": {"units": "m3", "value": 5},
            "coagulation_chemical_dose": {"units": "mmol/L", "value": 0.01},
            ...
        }
    }
    """

    # --- Read CSV ---
    df = pd.read_csv(in_csv, sep=None,engine='python')
    df.columns = df.columns.str.strip()

    expected_cols = ["parameters", "units", "value"]
    if list(df.columns) != expected_cols:
        print(f"❌ Error: Expected columns {expected_cols}, but found {list(df.columns)}")
        sys.exit(1)

    # --- Build dictionary ---
    data_dict = {
        "Process_outputs": {
            str(row["parameters"]).strip(): {
                "units": str(row["units"]).strip(),
                "value": float(row["value"])
            }
            for _, row in df.iterrows()
        }
    }

    # --- Ensure output directory exists ---
    os.makedirs(os.path.dirname(out_json) or ".", exist_ok=True)

    # --- Write JSON ---
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(data_dict, f, indent=2, ensure_ascii=False)

    print(f"✅ Django outputs JSON saved to: {out_json}")


def main(argv=None) -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="Prepare JSON config from django_outputs.csv")
    parser.add_argument("--in_csv", type=str, default="django_outputs.csv",
                        help="Path to input CSV file")
    parser.add_argument("--out_json", type=str, default="configs/django_outputs.json",
                        help="Path to output JSON file")

    args = parser.parse_args(argv)
    prepare_django_outputs(args.in_csv, args.out_json)


if __name__ == "__main__":
    main()
