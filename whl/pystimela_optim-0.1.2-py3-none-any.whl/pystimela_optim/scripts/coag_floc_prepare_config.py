"""
Configuration Preparation Tool for Coagulation-Flocculation Optimization

This module builds the optimization configuration from a CSV file. It:
- Reads baseline design from django_outputs.json
- Automatically generates process bounds with configurable scaling
- Allows manual override of all parameters
- Validates inputs and generates final JSON configuration

The generated configuration is consumed by coag_floc_optim.py.
"""

import json
import os
import sys
from typing import Dict, Any
import csv

# ============================================================================
# Constants and Defaults
# ============================================================================

# Fixed scaling factor for bounds: ±10× baseline values
BOUNDS_SCALE = 10.0

# Default penalty weights for constraint violations
DEFAULT_WEIGHTS = {
    "lam_pH": 1e5,
    "lam_DOC": 1e5,
    "lam_TSS": 1e5,
    "lam_G": 1e4,
    "lam_theta_coag": 1e5,  # ADD
    "lam_theta_floc": 1e5,  # ADD
    "lam_split": 1e5,  # coagulation under-removing its share of TSS
}

# Default differential evolution algorithm parameters
DEFAULT_ALGO = {
    "seed": 42,
    "maxiter": 100,
    "popsize": 15,
    "tol": 1e-3,
}

# Default process model parameters
DEFAULT_PARAMS = {
    # Coagulation kinetics
    "a1": 284.0,
    "a2": 74.2,
    "a3": 4.91,
    # Argaman-Kaufman floc kinetics (low-end literature values), temperature-scaled:
    # ka = ka20 * 1.05^(T-20), kb = kb20_* * 1.03^(20-T)
    "ka20": 3.68e-5,  # floc aggregation constant at 20°C (both stages)
    "kb20_coag": 7e-9,  # floc breakup at 20°C, rapid-mix basin
    "kb20_floc": 1.83e-7,  # floc breakup at 20°C, flocculation reactor
    "b": 0.147,
    "k1": -0.075,
    "k2": 0.56,
    # Flocculation kinetics
    "numcel": 3,
    # FeCl₃ cost parameters
    "fecl3_mmol_to_mgL": 162.2,
    "fecl3_dilution_frac": 0.40,
    "fecl3_chem_cost_per_kg": 0.535,
    # Al₂(SO₄)₃ cost parameters
    "al2so43_mmol_to_mgL": 342.18,
    "al2so43_dilution_frac": 0.48,
    "al2so43_chem_cost_per_kg": 0.35,
    # Financial parameters
    "n_years": 40,
    "r_nom": 0.05,
    "infl": 0.031,
    # Energy parameters
    "mu": 0.001,
    "n_eff": 0.8,
    "elec_price": 0.14,
}

# Fixed file paths
DJANGO_JSON_PATH = "configs/django_outputs.json"
OUT_JSON_PATH = "configs/coagulation-flocculation_config.json"
WQ_JSON_PATH = "configs/in_wq_params.json"
TIMESTAMPS_CSV_PATH = "inputs/timestamps/coagulation_flocculation.csv"
PLANT_DESIGN_CSV_PATH = "inputs/django_plant_design.csv"


def read_plant_design(path: str) -> Dict[str, Any]:
    """Read plant-wide economic parameters (n_years, r_nom, infl) from CSV."""
    values = {}
    with open(path, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter=";"):
            values[row["parameters"].strip()] = row["value"].strip()
    return {
        "n_years": int(values["n_years"]),
        "r_nom": float(values["r_nom"]),
        "infl": float(values["infl"]),
    }

# ============================================================================
# Load configurations from csv
# ============================================================================

def load_config_from_csv(csv_path: str) -> Dict[str, Any]:
    """Load configuration from CSV with sections."""
    config = {
        'decision_variables': {},
        'constraints': {},
        'initial_conditions': {},
        'model_parameters': {},
        'process_specific': {},
        'penalties': {},
        'optimization': {},
        'simulation': {}
    }

    with open(csv_path, 'r', encoding='utf-8') as f:
        # Read a sample of the file to detect the delimiter automatically
        sample = f.read(2048)
        f.seek(0)

        # Try to guess the delimiter (usually ',' or ';' or '\t')
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample)
        except csv.Error:
            # fallback if detection fails (e.g., single-line CSV)
            dialect = csv.get_dialect('excel')
            dialect.delimiter = ','
        reader = csv.DictReader(f, dialect=dialect)

        for row in reader:
            section = row['section'].lower().replace('-', '_')
            param = row['parameter']
            value = row['value']

            # Type conversion
            if value.lower() == 'auto':
                converted_value = 'auto'
            elif value.lower() in ('true', 'false'):
                converted_value = value.lower() == 'true'
            else:
                try:
                    if '.' in value or 'e' in value.lower():
                        converted_value = float(value)
                    else:
                        converted_value = int(value)
                except ValueError:
                    converted_value = value

            if section in config:
                config[section][param] = converted_value

    return config


# ============================================================================
# JSON I/O Utilities
# ============================================================================

def load_json(path: str) -> Dict[str, Any]:
    """Load JSON file and return as dictionary."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: Dict[str, Any]) -> None:
    """Write dictionary to JSON file with automatic directory creation."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def read_timestamps(path: str) -> list:
    """Read timestamps CSV (single column 'time_s') and return list of floats."""
    with open(path, "r") as f:
        lines = [l.strip() for l in f if l.strip()]
    # skip header if it starts with a letter
    return [float(l) for l in lines if not l[0].isalpha()]


# ============================================================================
# Configuration Builders
# ============================================================================

def build_limits_from_django(
        django_json_path: str,
        scale: float,
        pH_min: float,
        pH_max: float,
        doc_out_max: float,
        tss_out_max: float,
        theta_coag_min: float = 1.0,      # ADD
        theta_coag_max: float = 30.0,     # ADD
        theta_floc_min: float = 10.0,     # ADD
        theta_floc_max: float = 60.0,     # ADD
        coag_removal_split: float = 0.30,  # ADD
) -> Dict[str, float]:
    """
    Generate optimization bounds from baseline design values.

    Reads baseline design parameters from django_outputs.json and expands
    them into min/max bounds using the specified scale factor.

    Args:
        django_json_path: Path to django outputs JSON
        scale: Scaling factor for bounds (±scale × baseline)
        pH_min: Minimum effluent pH constraint
        pH_max: Maximum effluent pH constraint
        doc_out_max: Maximum effluent DOC [mg/L]
        tss_out_max: Maximum effluent TSS [mg/L]

    Returns:
        Dictionary of process limits

    Raises:
        KeyError: If expected fields are missing from django JSON
    """
    data = load_json(django_json_path)

    # Django outputs are nested under "Process_outputs"
    base = data.get("Process_outputs", data)

    try:
        # Extract coagulation parameters
        coag_vol = float(base["coagulation_volume"]["value"])
        coag_dose = float(base["coagulation_chemical_dose"]["value"])

        # Extract flocculation parameters
        floc_surface = float(base["flocculation_surface"]["value"])
        floc_length = float(base["flocculation_length"]["value"])
    except Exception as e:
        raise KeyError(f"Missing expected fields in {django_json_path}: {e}")

    return {
        # Coagulant dose bounds [mmol/L]
        "dose_min_mmol": coag_dose / scale,
        "dose_max_mmol": coag_dose * scale,
        # Coagulation velocity gradient bounds [1/s]
        "g10_coag_min": 10.0,
        "g10_coag_max": 1000.0,
        # Flocculation velocity gradient bounds [1/s]
        "g10_floc_min": 10.0,
        "g10_floc_max": 80.0,
        # Coagulation volume bounds [m³]
        "V_coag_min": coag_vol / scale,
        "V_coag_max": coag_vol * scale,
        # Flocculation length bounds [m]
        "length_floc_min_m": floc_length / scale,
        "length_floc_max_m": floc_length * scale,
        # Flocculation surface bounds [m²]
        "surf_min_m2": floc_surface / scale,
        "surf_max_m2": floc_surface * scale,
        # Effluent quality constraints
        "pH_min": pH_min,
        "pH_max": pH_max,
        "doc_out_max": doc_out_max,
        "tss_out_max": tss_out_max,
        # Residence time constraints [min]  # ADD
        "theta_coag_min": theta_coag_min,
        "theta_coag_max": theta_coag_max,
        "theta_floc_min": theta_floc_min,
        "theta_floc_max": theta_floc_max,
        # Per-stage TSS removal split  # ADD
        "coag_removal_split": coag_removal_split,
    }


def read_wq_params(json_path: str) -> Dict[str, Any]:
    """
    Read inlet water quality parameters from JSON.

    Extracts and remaps WQ parameters for downstream processing.
    Converts keys to lowercase/snake_case for consistency.

    Args:
        json_path: Path to water quality parameters JSON

    Returns:
        Dictionary with remapped WQ parameter keys
    """
    data = load_json(json_path)
    wp = data["WQ_parameters"]

    return {
        "flow": wp["flow"],
        "temperature": wp["temperature"],
        "suspended_solids": wp["suspended_solids"],
        "doc": wp["DOC"],  # DOC → doc
        "conductivity": wp["conductivity"],
        "ph": wp["pH"],  # pH → ph
        "mnumber": wp["m-number"],  # m-number → mnumber
        "uv254": wp["uv254"],
    }


def assemble_config(
        coagulant: str,
        limits: Dict[str, Any],
        initials: Dict[str, Any],
        params: Dict[str, Any],
        wq_params: Dict[str, Any],
        weights: Dict[str, Any] = None,
        algo: Dict[str, Any] = None,
        timestamps: list = None,
) -> Dict[str, Any]:
    """
    Assemble final configuration JSON structure.

    Combines all configuration components into the structure expected
    by coag_floc_optim.py.

    Args:
        coagulant: Coagulant type ('fecl3' or 'al2so43')
        limits: Process limits dictionary
        initials: Initial states dictionary
        params: Process parameters dictionary
        wq_params: Water quality parameters dictionary
        weights: Penalty weights (optional, uses DEFAULT_WEIGHTS if not provided)
        algo: Algorithm parameters (optional, uses DEFAULT_ALGO if not provided)

    Returns:
        Complete configuration dictionary ready for JSON export
    """
    # Use defaults if not provided
    if weights is None:
        weights = DEFAULT_WEIGHTS
    if algo is None:
        algo = DEFAULT_ALGO
    
    # Add coagulant to params
    params = dict(params)
    params["coagulant"] = coagulant

    # Build bounds list for documentation
    bounds_list = [
        {
            "name": "dose_mmol",
            "min": limits["dose_min_mmol"],
            "max": limits["dose_max_mmol"],
            "units": "mmol/L"
        },
        {
            "name": "g10_coag",
            "min": limits["g10_coag_min"],
            "max": limits["g10_coag_max"],
            "units": "1/s"
        },
        {
            "name": "V_coag_m3",
            "min": limits["V_coag_min"],
            "max": limits["V_coag_max"],
            "units": "m3"
        },
        {
            "name": "g10_floc",
            "min": limits["g10_floc_min"],
            "max": limits["g10_floc_max"],
            "units": "1/s"
        },
        {
            "name": "length_m",
            "min": limits["length_floc_min_m"],
            "max": limits["length_floc_max_m"],
            "units": "m"
        },
        {
            "name": "surf_m2",
            "min": limits["surf_min_m2"],
            "max": limits["surf_max_m2"],
            "units": "m2"
        },
    ]

    return {
        "process": "coagulation-flocculation",
        "inputs": {
            "timestamps": timestamps if timestamps is not None else [1, 3600],
            "wq_parameters": wq_params,
        },
        "coagulant": coagulant,
        "limits": limits,
        "initials": initials,
        "weights": weights,
        "params": params,
        "algorithm": algo,
        "bounds": bounds_list,
        "notes": {
            "source": "auto-generated from django_outputs.json",
            "wq_csv_format": (
                "semicolon-delimited; headers: "
                "timestamp;flow;temperature;conductivity;"
                "suspended_solids;uv254;ph;doc"
            ),
            "scaling": (
                f"bounds derived using ±{BOUNDS_SCALE}× from django base values"
            )
        }
    }


def generate_config_from_csv(csv_path: str, wq_json_path: str) -> None:
    """Generate configuration from CSV."""
    print(f"Reading configuration from: {csv_path}")

    csv_config = load_config_from_csv(csv_path)
    wq_params = read_wq_params(wq_json_path)

    use_auto_bounds = csv_config['decision_variables'].get('use_auto_bounds', True)

    if use_auto_bounds:
        print("   Using auto-calculated bounds from django_outputs.json")
        auto_limits = build_limits_from_django(
            DJANGO_JSON_PATH,
            BOUNDS_SCALE,
            csv_config['constraints'].get('pH_min', 6.5),
            csv_config['constraints'].get('pH_max', 7.5),
            csv_config['constraints'].get('doc_max', 10.0),
            csv_config['constraints'].get('tss_max', 2.0),
            csv_config['constraints'].get('theta_coag_min', 1.0),
            csv_config['constraints'].get('theta_coag_max', 30.0),
            csv_config['constraints'].get('theta_floc_min', 10.0),
            csv_config['constraints'].get('theta_floc_max', 60.0),
            csv_config['constraints'].get('coag_removal_split', 0.30),
        )
        final_limits = auto_limits
    else:
        print("   Using manual bounds from CSV")
        auto_limits = build_limits_from_django(
            DJANGO_JSON_PATH,
            BOUNDS_SCALE,
            csv_config['constraints'].get('pH_min', 6.5),
            csv_config['constraints'].get('pH_max', 7.5),
            csv_config['constraints'].get('doc_max', 10.0),
            csv_config['constraints'].get('tss_max', 2.0),
            csv_config['constraints'].get('theta_coag_min', 1.0),
            csv_config['constraints'].get('theta_coag_max', 30.0),
            csv_config['constraints'].get('theta_floc_min', 10.0),
            csv_config['constraints'].get('theta_floc_max', 60.0),
            csv_config['constraints'].get('coag_removal_split', 0.30),
        )
        final_limits = dict(auto_limits)

        # Override with manual values
        dv = csv_config['decision_variables']
        for key in ['dose_min_mmol', 'dose_max_mmol', 'g10_coag_min', 'g10_coag_max',
                    'g10_floc_min', 'g10_floc_max', 'V_coag_min', 'V_coag_max',
                    'length_floc_min_m', 'length_floc_max_m', 'surf_min_m2', 'surf_max_m2']:
            if key in dv and dv[key] != 'auto':
                final_limits[key] = dv[key]

    # Warn when the effluent target is so demanding that the flocculator's
    # implied share of the removal gap exceeds ~70% of its own influent, i.e.
    # outside the 40-70% window the ka/kb constants were calibrated to.
    TSS_in = float(wq_params["suspended_solids"]["value"])
    tss_target = final_limits["tss_out_max"]
    split = final_limits["coag_removal_split"]
    gap = TSS_in - tss_target
    if gap > 0:
        post_coag = TSS_in - split * gap
        floc_share = (1 - split) * gap / post_coag
        if floc_share > 0.70:
            print(
                f"   WARNING: target TSS {tss_target}/{TSS_in} mg/L needs flocculation to "
                f"remove {floc_share:.0%} of its influent, above the 40-70% calibrated "
                f"window; model reliability degraded for this target."
            )

    # Build initials
    ic = csv_config.get('initial_conditions', {})
    initials = {
        "suspended_solids_initial_floc": ic.get('ss_initial', 0.0)
    }

    # Build parameters
    params = dict(DEFAULT_PARAMS)
    mp = csv_config.get('model_parameters', {})
    for key in DEFAULT_PARAMS.keys():
        if key in mp:
            params[key] = mp[key]

    # Override plant-wide economic parameters from the shared plant-design file
    if os.path.exists(PLANT_DESIGN_CSV_PATH):
        plant = read_plant_design(PLANT_DESIGN_CSV_PATH)
        params["n_years"] = plant["n_years"]
        params["r_nom"] = plant["r_nom"]
        params["infl"] = plant["infl"]

    # Build weights
    weights = dict(DEFAULT_WEIGHTS)
    pen = csv_config.get('penalties', {})
    for key in DEFAULT_WEIGHTS.keys():
        if key in pen:
            weights[key] = pen[key]

    # Build algo
    algo = dict(DEFAULT_ALGO)
    opt = csv_config.get('optimization', {})
    for key in DEFAULT_ALGO.keys():
        if key in opt:
            algo[key] = opt[key]

    # Get coagulant type
    ps = csv_config.get('process_specific', {})
    coagulant = ps.get('coagulant', 'fecl3')

    timestamps = read_timestamps(TIMESTAMPS_CSV_PATH)

    # NOW USE assemble_config to create the proper structure
    config = assemble_config(
        coagulant=coagulant,
        limits=final_limits,
        initials=initials,
        params=params,
        wq_params=wq_params,
        weights=weights,
        algo=algo,
        timestamps=timestamps,
    )

    write_json(OUT_JSON_PATH, config)
    print(f"Configuration saved to: {OUT_JSON_PATH}")

def main(argv=None) -> None:
    """CLI entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="Prepare coagulation-flocculation optimization configuration.")
    parser.add_argument("--in_wq_params", required=True)
    parser.add_argument("--csv_config", default="inputs/config_coagulation_flocculation.csv")
    args = parser.parse_args(argv)

    WQ_JSON_PATH = args.in_wq_params
    if not os.path.exists(WQ_JSON_PATH):
        sys.exit(f"Error: WQ parameters file not found at {WQ_JSON_PATH}")
    if not os.path.exists(args.csv_config):
        sys.exit(f"Error: CSV config file not found at {args.csv_config}")

    print(f"Loaded WQ parameters from: {WQ_JSON_PATH}")
    generate_config_from_csv(args.csv_config, WQ_JSON_PATH)


if __name__ == "__main__":
    main()
