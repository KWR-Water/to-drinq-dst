#!/usr/bin/env python
# ============================================================================
# FULLY AUTOMATED SEQUENTIAL OPTIMIZATION RUNNER
# Uses CSV configuration files - NO user interaction needed
# All processes run automatically from start to finish
# ============================================================================

import json
import os
import sys
import shutil
import subprocess
import argparse
from datetime import datetime


def _run_python_module(module_name: str, *args: str) -> None:
    cmd = [sys.executable, "-m", module_name, *args]
    subprocess.run(cmd, check=True)


def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description=(
            "Run all enabled optimization processes sequentially using "
            "CSV-driven configuration."
        )
    )
    parser.add_argument(
        "--enabled_json",
        default="outputs/enabled_processes.json",
        help="Path to enabled processes JSON",
    )
    parser.add_argument(
        "--in_wq_params",
        default="configs/in_wq_params.json",
        help="Path to starting water quality parameters JSON",
    )
    parser.add_argument(
        "--run_dir",
        default=None,
        help=(
            "Optional output directory for this run; defaults to "
            "outputs/<timestamp>"
        ),
    )
    return parser


def parse_cli_args(argv=None) -> argparse.Namespace:
    """Parse CLI args for sequential optimization runner."""
    return build_parser().parse_args(argv)


def run_cli(args: argparse.Namespace) -> None:
    """Execute sequential optimization pipeline from parsed CLI args."""
    if not os.path.exists(args.enabled_json):
        raise FileNotFoundError(
            f"Missing {args.enabled_json}. "
            "Run select_processes.py first to generate it."
        )

    if not os.path.exists(args.in_wq_params):
        raise FileNotFoundError(
            f"Missing {args.in_wq_params}. "
            "Provide a valid --in_wq_params path."
        )

    # Load enabled processes
    with open(args.enabled_json, "r", encoding="utf-8") as f:
        enabled_data = json.load(f)
        enabled_processes = enabled_data["enabled"]

    # Create timestamped output directory
    run_dir = args.run_dir or os.path.join(
        "outputs", datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    )
    os.makedirs(run_dir, exist_ok=True)

    print("=" * 80)
    print("FULLY AUTOMATED OPTIMIZATION RUNNER (CSV MODE)")
    print("=" * 80)
    print(f"\nEnabled processes: {enabled_processes}")
    print(f"\nRun output directory: {run_dir}")
    print("\nUsing CSV configuration files from inputs/ directory")
    print("No user interaction required - fully automated execution")
    print("\n" + "=" * 80)

    # Track current water quality
    current_wq_config = args.in_wq_params

    # Process configuration mapping
    process_config = {
        "coagulation-flocculation": {
            "name": "Coagulation-Flocculation",
            "csv": "inputs/config_coagulation_flocculation.csv",
            "prepare_module": (
                "pystimela_optim.scripts.coag_floc_prepare_config"
            ),
            "config_json": "configs/coagulation-flocculation_config.json",
            "optim_module": "pystimela_optim.scripts.coag_floc_optim",
            "results_json": "outputs/coag_floc_results.json",
            "update_module": "pystimela_optim.scripts.coag_floc_optim_update",
        },
        "filtration_single": {
            "name": "Filtration (Single)",
            "csv": "inputs/config_filtration_single.csv",
            "prepare_module": (
                "pystimela_optim.scripts.filtration_prepare_config"
            ),
            "config_json": "configs/filtration_config.json",
            "optim_module": "pystimela_optim.scripts.filtration_optim",
            "results_json": "outputs/filtration_results.json",
            "update_module": "pystimela_optim.scripts.filtration_optim_update",
        },
        "filtration_dual": {
            "name": "Filtration (Dual)",
            "csv": "inputs/config_filtration_dual.csv",
            "prepare_module": (
                "pystimela_optim.scripts.dual_filtration_prepare_config"
            ),
            "config_json": "configs/dual_filtration_config.json",
            "optim_module": "pystimela_optim.scripts.dual_filtration_optim",
            "results_json": "outputs/dual_filtration_results.json",
            "update_module": (
                "pystimela_optim.scripts.dual_filtration_optim_update"
            ),
        },
        "gac": {
            "name": "GAC",
            "csv": "inputs/config_gac.csv",
            "prepare_module": "pystimela_optim.scripts.gac_prepare_config",
            "config_json": "configs/gac_config.json",
            "optim_module": "pystimela_optim.scripts.gac_optim",
            "results_json": "outputs/gac_results.json",
            "update_module": "pystimela_optim.scripts.gac_optim_update",
        },
        "chlorination": {
            "name": "Chlorination",
            "csv": "inputs/config_chlorination.csv",
            "prepare_module": (
                "pystimela_optim.scripts.chlorination_prepare_config"
            ),
            "config_json": "configs/chlorination_config.json",
            "optim_module": "pystimela_optim.scripts.chlorination_optim",
            "results_json": "outputs/chlorination_results.json",
            "update_module": (
                "pystimela_optim.scripts.chlorination_optim_update"
            ),
        },
        "ozonation": {
            "name": "Ozonation",
            "csv": "inputs/config_ozonation.csv",
            "prepare_module": (
                "pystimela_optim.scripts.ozonation_prepare_config"
            ),
            "config_json": "configs/ozonation_config.json",
            "optim_module": "pystimela_optim.scripts.ozonation_optim",
            "results_json": "outputs/ozonation_results.json",
            "update_module": "pystimela_optim.scripts.ozonation_optim_update",
        },
    }

    # Calculate total steps
    total_steps = len(enabled_processes) * 3
    current_step = 0

    # Run each enabled process
    for proc_key in enabled_processes:
        if proc_key not in process_config:
            print(f"\nWarning: Unknown process '{proc_key}' - skipping")
            continue

        proc = process_config[proc_key]

        print(f"\n\n{'=' * 80}")
        print(proc["name"].upper())
        print("=" * 80)
        print(f"Input WQ: {current_wq_config}")

        # Check if CSV file exists
        if not os.path.exists(proc["csv"]):
            print(f"\nERROR: CSV config file not found: {proc['csv']}")
            print("   Please create this file or disable the process.")
            print(f"   Skipping {proc['name']}...")
            continue

        # STEP 1: Prepare configuration from CSV
        current_step += 1
        print(
            f"\n[{current_step}/{total_steps}] "
            "Step 1/3: Preparing Configuration from CSV"
        )
        print("-" * 80)
        print(f"   CSV config: {proc['csv']}")

        _run_python_module(
            proc["prepare_module"],
            "--in_wq_params",
            current_wq_config,
            "--csv_config",
            proc["csv"],
        )

        print(f"   Config saved: {proc['config_json']}")

        # STEP 2: Run optimization
        current_step += 1
        print(
            f"\n[{current_step}/{total_steps}] "
            "Step 2/3: Running Optimization"
        )
        print("-" * 80)

        result_filename = os.path.basename(proc["results_json"])
        result_path = os.path.join(run_dir, result_filename)

        _run_python_module(
            proc["optim_module"],
            "--config",
            proc["config_json"],
            "--out_json",
            result_path,
        )

        print(f"   Results saved: {result_path}")

        # STEP 3: Update water quality
        current_step += 1
        print(
            f"\n[{current_step}/{total_steps}] "
            "Step 3/3: Updating Water Quality"
        )
        print("-" * 80)

        _run_python_module(
            proc["update_module"],
            "--wq_json",
            current_wq_config,
            "--results_json",
            result_path,
            "--out_json",
            current_wq_config,
        )

        print(f"   Water quality updated: {current_wq_config}")
        print(f"\nOutput WQ: {current_wq_config}")
        print(f"{proc['name']} complete")

    # Final summary
    print("\n\n" + "=" * 80)
    print("ALL OPTIMIZATIONS COMPLETE")
    print("=" * 80)
    print(f"\nCompleted {len(enabled_processes)} process(es):")
    for i, proc_key in enumerate(enabled_processes, 1):
        if proc_key in process_config:
            print(f"   {i}. {process_config[proc_key]['name']}")

    shutil.copy(
        current_wq_config,
        os.path.join(run_dir, "final_wq_params.json"),
    )

    print(f"\nResults directory: {run_dir}")
    print(f"Final water quality: {current_wq_config}")
    print("Configurations: configs/")
    print("\n" + "=" * 80)
    print("=" * 80)


def main(argv=None) -> None:
    """CLI entry point."""
    parsed_args = parse_cli_args(argv)
    run_cli(parsed_args)


if __name__ == "__main__":
    main()
