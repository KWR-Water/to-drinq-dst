from __future__ import annotations

"""
Single Media Filtration Process Optimization

This module optimizes water treatment filtration processes using differential
evolution. It minimizes total annual costs (construction, maintenance, materials,
filter media) subject to water quality and operational constraints (TSS, head loss,
accumulated solids).

Key Components:
- Process simulation via PyStimela
- Multi-objective scalarization with penalty functions
- Economic evaluation (CAPEX/OPEX)
- Differential evolution optimization
- Backwash schedule management
"""

import json
import argparse
from importlib import import_module
from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
from scipy.optimize import differential_evolution

datatypes = None
dwtmodels = None


def _require_pystimela() -> None:
    """Load pystimela lazily and raise a clear runtime dependency error."""
    global datatypes, dwtmodels
    if datatypes is not None and dwtmodels is not None:
        return

    try:
        datatypes = import_module("pystimela.datatypes")
        dwtmodels = import_module("pystimela.dwtmodels")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "The 'pystimela' package is required to run optimization. "
            "Install pystimela to execute this command."
        ) from exc


# ============================================================================
# Configuration Dataclasses
# ============================================================================

@dataclass
class Limits:
    """
    Process limits for regulatory/operational bounds.

    Control variable bounds define the search space for optimization.
    Constraint bounds define feasibility requirements for the solution.
    """
    # Control variable bounds
    surf_min_m2: float = 1.0  # [m²] minimum filter surface area
    surf_max_m2: float = 100.0  # [m²] maximum filter surface area
    lbed_min_m: float = 0.06  # [m] minimum bed height (media depth)
    lbed_max_m: float = 6.0  # [m] maximum bed height (media depth)
    diam_min_mm: float = 0.06  # [mm] minimum grain size
    diam_max_mm: float = 6.0  # [mm] maximum grain size

    # Constraint bounds (effluent quality and operational requirements)
    headloss_max_m: float = 1.5  # [m] maximum head loss
    tss_out_max_mgL: float = 1.0  # [mg/L] maximum effluent TSS
    accum_max_kgm3: float = 5e5  # [kg/m³] maximum accumulated solids (sum over bed)

    theta_min: float = 5.0  # [min] minimum residence time
    theta_max: float = 60.0  # [min] maximum residence time

@dataclass
class Weights:
    """
    Penalty weights for constraint violations in scalarized objective.

    These multipliers convert constraint violations into cost penalties,
    implementing a soft-constraint approach (big-M method).
    """
    lam_TSS: float = 2e5  # penalty weight for TSS violations
    lam_HL: float = 2e5  # penalty weight for head loss violations
    lam_ACC: float = 1e5  # penalty weight for accumulated solids violations

    lam_theta: float = 1e5  # penalty weight for residence time violations


@dataclass
class InitialStates:
    """
    Initial conditions for filtration unit process.

    These values represent the starting state of the filter,
    particularly the suspended solids and accumulated solids in filter cells.
    """
    suspended_solids_initial: float = 0.0  # [kg/m³] initial suspended solids
    init_accumulation_initial: float = 0.0  # [kg/m³] initial accumulated solids


@dataclass
class Params:
    """
    Process model parameters for filtration.

    Includes:
    - Physical parameters (porosity, density, water level)
    - Kinetic parameters (filtration resistance, clogging constants)
    - Economic parameters (costs, financial factors)
    - Reactor configuration (number of cells)
    """
    # Physical parameters
    lwater: float = 1.0  # [m] water level above filter bed
    filporo: float = 39.0  # [%] filter porosity
    nmax: float = 75.0  # [%] maximum pore filling
    rhod: float = 30.0  # [kg/m³] density of deposited solids

    # Kinetic parameters
    lambda0: float = 0.15  # [1/m] filtration resistance parameter
    n1: float = 290.0  # clogging constant 1
    n2: float = 310.0  # clogging constant 2
    numcel: int = 1  # number of discretization cells

    # Financial parameters for CAPEX annualization
    n_years: int = 40  # project lifetime [years]
    r_nom: float = 0.05  # nominal interest rate (Netherlands: 5%, Greece: 7%)
    infl: float = 0.031  # inflation rate (Netherlands: 3.1%, Greece: 3.6%)

    # Filter media cost
    sand_filter_cost: float = 80.0  # [€/t] cost per ton of filter media


# ============================================================================
# Water Quality Input Handling
# ============================================================================

class QualityInputs:
    """
    Time-series water quality parameters for filtration simulation.

    Constructs time-series arrays from CSV file, representing inlet water
    characteristics over the simulation period.
    """

    COLUMNS = [
        "timestamp", "flow", "temperature", "suspended_solids"
    ]

    def __init__(self, timestamps: List[float], **attrs):
        """
        Initialize with timestamps and water quality attributes.

        Args:
            timestamps: List of time points [s]
            **attrs: Water quality parameters as numpy arrays
        """
        self.timestamps = timestamps
        self.__dict__.update(attrs)

    @classmethod
    def from_json(cls, inputs_dict: Dict) -> "QualityInputs":
        """
        Build QualityInputs from JSON-style configuration dictionary.

        Args:
            inputs_dict: Configuration with timeframe, timestep, and wq_parameters

        Returns:
            QualityInputs instance with constant time-series
        """
        timestamps = inputs_dict["timestamps"]
        n_steps = len(timestamps)

        wq_params = inputs_dict["wq_parameters"]

        def get_val(key: str) -> float:
            """Extract value from wq_parameters dict, return NaN if missing."""
            return float(wq_params[key]["value"]) if key in wq_params else np.nan

        # Create constant time-series arrays for each parameter
        return cls(
            timestamps=timestamps,
            flow=np.full(n_steps, get_val("flow")),
            temperature=np.full(n_steps, get_val("temperature")),
            suspended_solids=np.full(n_steps, get_val("suspended_solids"))
        )

    def to_wq_list(self) -> List[datatypes.WaterQualityParams]:
        """
        Convert to PyStimela WaterQualityParams list.

        Returns:
            List of WaterQualityParams objects for each timestep
        """
        fields = [c for c in self.COLUMNS if c != "timestamp"]
        n = len(self.timestamps)
        wq_list = []

        for i in range(n):
            kwargs = {name: float(getattr(self, name)[i]) for name in fields}
            wq = datatypes.WaterQualityParams(timestamp=self.timestamps[i], **kwargs)
            wq_list.append(wq)

        return wq_list


# ============================================================================
# Backwash Schedule Generation
# ============================================================================

def generate_backwash_events(timestamps: List[float], freq_h: float) -> List[bool]:
    """
    Generate backwash event schedule based on fixed time frequency.

    Args:
        timestamps: List of simulation time points [s]
        freq_h: Backwash frequency [hours] (0 = no backwash)

    Returns:
        List of boolean flags indicating backwash events at each timestep
    """
    events = [False] * len(timestamps)

    if freq_h > 0:
        # Convert timestamps from seconds to hours
        times_h = np.array(timestamps) / 3600.0
        last_bw = 0.0

        for i, t in enumerate(times_h):
            if t - last_bw >= freq_h:
                events[i] = True
                last_bw = t

    return events


# ============================================================================
# Process Simulation
# ============================================================================

def stimela_simulate(
        inputs: QualityInputs,
        params: Params,
        initials: InitialStates,
        surf_m2: float,
        lbed_m: float,
        diam_mm: float,
        backwash_events: List[bool],
) -> Dict[str, float]:
    """
    Simulate filtration process using PyStimela.

    This wrapper orchestrates the filtration simulation with backwash events.

    Args:
        inputs: Time-series water quality parameters
        params: Process model parameters
        initials: Initial state conditions
        surf_m2: Filter surface area [m²]
        lbed_m: Bed height (media depth) [m]
        diam_mm: Grain size [mm]
        backwash_events: Boolean list indicating backwash at each timestep

    Returns:
        Dictionary with filtration performance metrics:
        - TSS_out_mgL: effluent total suspended solids [mg/L]
        - Head_loss_m: final head loss [m]
        - Accum_solids_kgm3: total accumulated solids [kg/m³]
    """
    _require_pystimela()
    timestamps = inputs.timestamps

    # ---- Filtration Parameters ----
    filt_params = datatypes.FiltrationParams(
        surf=surf_m2,
        lwater=params.lwater,
        lbed=lbed_m,
        diam=diam_mm,
        filporo=params.filporo,
        nmax=params.nmax,
        rhod=params.rhod,
        lambda0=params.lambda0,
        n1=params.n1,
        n2=params.n2,
        numcel=params.numcel
    )

    # Prepare input water quality
    in_wq_list = inputs.to_wq_list()
    in_wq_params = datatypes.ListWaterQualityParams(
        timestamps=timestamps,
        wqparams=in_wq_list
    )

    # Initialize filtration state in all compartments
    numcel = filt_params.numcel
    suspended_solids_initial = [initials.suspended_solids_initial] * numcel
    init_accumulation_initial = [initials.init_accumulation_initial] * numcel

    filt_init_state = datatypes.FiltrationState(
        suspended_solids=suspended_solids_initial,
        init_accumulation=init_accumulation_initial
    )

    # Prepare backwash schedule
    backwash_schedule = datatypes.BackWashData(
        timestamps=timestamps,
        events=backwash_events
    )

    # Run filtration simulation
    filt_process = dwtmodels.Filtration(params=filt_params)
    filt_results = filt_process.simulate(
        t_eval=timestamps,
        init_state=filt_init_state,
        wq_params=in_wq_params,
        bw=backwash_schedule
    )

    # Extract effluent TSS (final timestep)
    tss_out = filt_results['out_wqparams'][-1].suspended_solids

    # Extract head loss (final timestep, last cell)
    # flow_res is shaped (T, numcel)
    flow_res = filt_results["flow_res"]
    t_last = flow_res.shape[0] - 1
    headloss_last = float(flow_res[t_last, -1])

    # Extract accumulated solids (final timestep, sum over all cells)
    # sysout columns numcel:(2*numcel) contain accumulated solids
    sysout = filt_results["sysout"]
    accum_last = sysout[t_last, numcel:(2 * numcel)]
    accum_total_kgm3 = float(np.sum(accum_last))

    volume_m3 = surf_m2 * lbed_m
    avg_flow = float(np.mean(inputs.flow))  # m³/h
    theta = (volume_m3 / avg_flow) * 60.0


    return {
        "TSS_out_mgL": float(tss_out),
        "Head_loss_m": headloss_last,
        "Accum_solids_kgm3": accum_total_kgm3,
        "theta": theta
    }


# ============================================================================
# Economic Calculations
# ============================================================================

def capital_recovery_factor(r_real: float, n: int) -> float:
    """
    Calculate Capital Recovery Factor for CAPEX annualization.

    CRF converts a present value to equivalent annual cost over n years
    at real interest rate r_real.

    Args:
        r_real: Real interest rate (adjusted for inflation)
        n: Project lifetime [years]

    Returns:
        Capital recovery factor [-]
    """
    return (r_real * (1 + r_real) ** n) / ((1 + r_real) ** n - 1)


def compute_construction_cost(surf_m2: float, crf: float) -> float:
    """
    Calculate annualized construction cost using empirical equation.

    Args:
        surf_m2: Filter surface area [m²]
        crf: Capital recovery factor

    Returns:
        Annualized construction cost [€/year]
    """
    return crf * (-54.75 * surf_m2 ** 2 + 30324.5549 * surf_m2 + 269494.503)


def compute_maintenance_cost(surf_m2: float) -> float:
    """
    Calculate annual maintenance cost using empirical equation.

    Args:
        surf_m2: Filter surface area [m²]

    Returns:
        Annual maintenance cost [€/year]
    """
    return -1.2336 * surf_m2 ** 2 + 621.872 * surf_m2 + 7752.087


def compute_materials_cost(surf_m2: float) -> float:
    """
    Calculate annual materials cost using empirical equation.

    Args:
        surf_m2: Filter surface area [m²]

    Returns:
        Annual materials cost [€/year]
    """
    return 14.821 * surf_m2


def compute_filter_media_cost(
        surf_m2: float,
        lbed_m: float,
        diam_mm: float,
        params: Params,
        crf_10: float
) -> float:
    """
    Calculate annualized filter media replacement cost.

    Media is replaced every 10 years, so uses a separate CRF.

    Args:
        surf_m2: Filter surface area [m²]
        lbed_m: Bed height [m]
        diam_mm: Grain size [mm]
        params: Process parameters with media cost
        crf_10: Capital recovery factor for 10-year period

    Returns:
        Annualized filter media cost [€/year]
    """
    # Calculate filter volume
    V_filter_m3 = surf_m2 * lbed_m

    # Estimate grain density based on grain size (empirical relationship)
    density_grain = 333 * diam_mm + 1300  # [kg/m³]

    # Calculate total mass of filter media
    mass_filter = density_grain * V_filter_m3 / 1000  # [tonnes]

    # Annualize over 10-year replacement cycle
    return crf_10 * params.sand_filter_cost * mass_filter


def compute_constraint_penalties(
        TSS_out: float,
        Head_loss_out: float,
        Accum_solids_out: float,
        theta: float,
        limits: Limits,
        weights: Weights
) -> float:
    """
    Calculate soft-constraint penalty for violations.

    Implements big-M penalty method for constraint violations:
    - TSS exceeding tss_out_max_mgL
    - Head loss exceeding headloss_max_m
    - Accumulated solids exceeding accum_max_kgm3

    Args:
        TSS_out: Effluent TSS [mg/L]
        Head_loss_out: Head loss [m]
        Accum_solids_out: Accumulated solids [kg/m³]
        limits: Constraint limits
        weights: Penalty weights

    Returns:
        Total penalty value (unitless, added to objective)
    """
    penalty = 0.0

    # TSS constraint (upper bound, normalized)
    v_tss = max(0.0, (TSS_out - limits.tss_out_max_mgL) / max(limits.tss_out_max_mgL, 1e-6))
    penalty += weights.lam_TSS * v_tss

    # Head loss constraint: flow_res < 0 means friction exceeds available driving head
    if Head_loss_out < 0:
        v_hl = abs(Head_loss_out) / max(limits.headloss_max_m, 1e-6)
        penalty += weights.lam_HL * v_hl

    # Accumulated solids constraint (upper bound, normalized)
    v_acc = max(0.0, (Accum_solids_out - limits.accum_max_kgm3) / max(limits.accum_max_kgm3, 1e-6))
    penalty += weights.lam_ACC * v_acc

    if theta < limits.theta_min:
        v_theta_min = (limits.theta_min - theta) / max(limits.theta_min, 1e-6)
        penalty += weights.lam_theta * v_theta_min

        # Residence time constraint (maximum)
    if theta > limits.theta_max:
        v_theta_max = (theta - limits.theta_max) / max(limits.theta_max, 1e-6)
        penalty += weights.lam_theta * v_theta_max

    return penalty


# ============================================================================
# Optimization Objective Function
# ============================================================================

def objective_scalar(
        x: np.ndarray,
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        backwash_events: List[bool]
) -> Tuple[float, Dict[str, float]]:
    """
    Scalarized objective function: minimize total annual cost + penalties.

    This is the function minimized by differential evolution. It:
    1. Unpacks decision variables
    2. Simulates the filtration process
    3. Computes base costs (construction, maintenance, materials, filter media)
    4. Adds constraint violation penalties

    Args:
        x: Decision vector [surf_m2, lbed_m, diam_mm]
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        backwash_events: Backwash schedule

    Returns:
        Tuple of (objective_value, cost_breakdown_dict)
    """
    # Unpack decision variables
    surf_m2 = float(x[0])
    lbed_m = float(x[1])
    diam_mm = float(x[2])

    # Simulate process
    sim = stimela_simulate(
        inputs, params, initials,
        surf_m2, lbed_m, diam_mm,
        backwash_events
    )

    TSS_out = sim["TSS_out_mgL"]
    Head_loss_out = sim["Head_loss_m"]
    Accum_solids_out = sim["Accum_solids_kgm3"]
    theta_out = sim['theta']

    # ---- Cost Components ----

    # Calculate real interest rate and CRFs
    r_real = (1 + params.r_nom) / (1 + params.infl) - 1
    crf = capital_recovery_factor(r_real, params.n_years)
    crf_10 = capital_recovery_factor(r_real, 10)  # For 10-year filter media replacement

    # Construction cost [€/year]
    const_cost = compute_construction_cost(surf_m2, crf)

    # Maintenance cost [€/year]
    maint_cost = compute_maintenance_cost(surf_m2)

    # Materials cost [€/year]
    materials_cost = compute_materials_cost(surf_m2)

    # Filter media cost [€/year]
    filter_media_cost = compute_filter_media_cost(surf_m2, lbed_m, diam_mm, params, crf_10)

    # Base objective (total annual cost)
    base = const_cost + maint_cost + materials_cost + filter_media_cost

    # ---- Constraint Penalties ----
    penalty = compute_constraint_penalties(TSS_out, Head_loss_out, Accum_solids_out, theta_out, limits, weights)

    # Total objective
    objective_value = base + penalty

    # Detailed cost breakdown
    cost_breakdown = {
        "r_nom": params.r_nom,
        "infl": params.infl,
        "r_real": r_real,
        "CRF_n": crf,
        "CRF_10": crf_10,
        "construction_cost_eur_per_year": const_cost,
        "maintenance_cost_eur_per_year": maint_cost,
        "materials_cost_eur_per_year": materials_cost,
        "filters_cost_eur_per_year": filter_media_cost,
        "TSS_out_mgL": TSS_out,
        "Head_loss_m": Head_loss_out,
        "Accum_solids_kgm3": Accum_solids_out,
        "penalty": penalty,
        "theta": theta_out,
    }

    return objective_value, cost_breakdown


# ============================================================================
# Optimization Solver
# ============================================================================

def solve(
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        backwash_events: List[bool],
        seed: int = 42,
        maxiter: int = 60,
        popsize: int = 15,
        tol: float = 1e-3,
        workers: int = 1
) -> Dict:
    """
    Solve optimization problem using differential evolution.

    Minimizes total annual cost subject to water quality and operational
    constraints by optimizing filter surface area, bed height, and grain size.

    Args:
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        backwash_events: Backwash schedule
        seed: Random seed for reproducibility
        maxiter: Maximum number of DE iterations
        popsize: Population size for DE
        tol: Convergence tolerance
        workers: Number of parallel workers (1 = serial)

    Returns:
        Dictionary with optimization results, including:
        - success: optimization success flag
        - message: solver message
        - fun: optimal objective value
        - x_opt: optimal decision variables
        - outputs: effluent water quality
        - economics: detailed cost analysis
    """
    # Define decision variable bounds
    bounds = [
        (limits.surf_min_m2, limits.surf_max_m2),  # surface [m²]
        (limits.lbed_min_m, limits.lbed_max_m),  # bed height [m]
        (limits.diam_min_mm, limits.diam_max_mm),  # grain size [mm]
    ]

    # Wrapper for objective function (DE expects single return value)
    def objective_wrapper(x: np.ndarray) -> float:
        obj_val, _ = objective_scalar(
            x, inputs, params, limits, weights, initials, backwash_events
        )
        return obj_val

    # Run differential evolution
    result = differential_evolution(
        objective_wrapper,
        bounds=bounds,
        strategy="best1bin",
        maxiter=maxiter,
        popsize=popsize,
        tol=tol,
        mutation=(0.5, 1.0),
        recombination=0.7,
        seed=seed,
        polish=True,
        disp=True,
        workers=workers
    )

    # Unpack optimal solution
    x_opt = result.x
    surf_m2 = float(x_opt[0])
    lbed_m = float(x_opt[1])
    diam_mm = float(x_opt[2])

    # Derived volume
    V_filter_m3 = surf_m2 * lbed_m

    # Re-evaluate objective to get detailed cost breakdown
    obj_val, costs = objective_scalar(
        x_opt, inputs, params, limits, weights, initials, backwash_events
    )

    # Separate simulation outputs from economics
    simulation_outputs = {
        "TSS_out_mgL": round(costs["TSS_out_mgL"],3),
        "Head_loss_m": round(costs["Head_loss_m"],3),
        "Accum_solids_kgm3": round(costs["Accum_solids_kgm3"],3),
        "theta_min": round(costs["theta"],2)
    }

    economics = {
        "r_nom": round(costs["r_nom"],3),
        "infl": round(costs["infl"],3),
        "r_real": round(costs["r_real"],3),
        "CRF_n": round(costs["CRF_n"],3),
        "CRF_10": round(costs["CRF_10"],3),
        "construction_cost_eur_per_year": round(costs["construction_cost_eur_per_year"], 1),
        "maintenance_cost_eur_per_year": round(costs["maintenance_cost_eur_per_year"], 1),
        "materials_cost_eur_per_year": round(costs["materials_cost_eur_per_year"], 1),
        "filters_cost_eur_per_year": round(costs["filters_cost_eur_per_year"], 1),
        "penalty_added_unitless": round(costs["penalty"],3),
        "obj_fun_value": round(obj_val, 1),
    }

    # Compile comprehensive results report
    report = {
        "success": bool(result.success),
        "message": str(result.message),
        "fun": round(float(result.fun), 2),
        "x_opt": {
            "single_filtration_surface": round(surf_m2,1),
            "single_filtration_depth": round(lbed_m,1),
            "single_filtration_grain_size_a": round(diam_mm,2)
        },
        "derived": {
            "V_filter_m3": round(V_filter_m3,2)
        },
        "inputs": {
            "flow_mean_m3h": float(np.mean(inputs.flow)),
            "TSS_in_mgL": float(np.mean(inputs.suspended_solids)),
        },
        "outputs": simulation_outputs,
        "constraints": {
            "tss_out_max_mgL": limits.tss_out_max_mgL,
            "headloss_max_m": limits.headloss_max_m,
            "accum_max_kgm3": limits.accum_max_kgm3,
            "lbed_range_m": (limits.lbed_min_m, limits.lbed_max_m),
            "diam_range_mm": (limits.diam_min_mm, limits.diam_max_mm),
            "theta_min": limits.theta_min,  #
            "theta_max": limits.theta_max  #

        },
        "economics": economics,
        "optimal variables": {
            "surf_m2": round(surf_m2,2),
            "lbed_m": round(lbed_m,2),
            "diam_mm": round(diam_mm,2),
            "V_filter_m3": round(V_filter_m3,2),
            "theta_min": round(costs["theta"],2)
        }
    }

    return report


# ============================================================================
# Command-Line Interface
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Run filtration optimization from JSON config or CSV"
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to configuration JSON file"
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility"
    )
    parser.add_argument(
        "--maxiter",
        type=int,
        default=300,
        help="Maximum DE iterations"
    )
    parser.add_argument(
        "--popsize",
        type=int,
        default=30,
        help="DE population size"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of parallel workers"
    )
    parser.add_argument(
        "--out_json",
        type=str,
        default="outputs/filtration_results.json",
        help="Path to output results JSON file"
    )
    parser.add_argument(
        "--bw_freq_h",
        type=float,
        default=0.0,
        help="Backwash frequency in hours (0 = no backwash)"
    )
    return parser


def parse_cli_args(argv=None) -> argparse.Namespace:
    """Parse CLI args for filtration optimization."""
    return build_parser().parse_args(argv)


def run_cli(args: argparse.Namespace) -> Dict:
    """Run optimization from parsed CLI args and write output JSON."""

    from pystimela_optim import api as optim_api

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    algo = cfg.get("algorithm", {})
    # Keep historical behavior: config algorithm/backwash values take precedence.
    seed = algo.get("seed", args.seed)
    maxiter = algo.get("maxiter", args.maxiter)
    popsize = algo.get("popsize", args.popsize)
    workers = algo.get("workers", args.workers)
    tol = algo.get("tol", 1e-3)
    bw_freq_h = cfg.get("backwash_freq_h", 0.0)
    # the api.optimize_filtration function handles backwash events generation
    report = optim_api.optimize_filtration(
        cfg,
        seed=seed,
        maxiter=maxiter,
        popsize=popsize,
        workers=workers,
        tol=tol,
        bw_freq_h=bw_freq_h,
    )

    # Save results
    with open(args.out_json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Results saved to {args.out_json}")
    return report


def main(argv=None):
    """CLI entry point."""
    args = parse_cli_args(argv)
    run_cli(args)


if __name__ == "__main__":
    main()