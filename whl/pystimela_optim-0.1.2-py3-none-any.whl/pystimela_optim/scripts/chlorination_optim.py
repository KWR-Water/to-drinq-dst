from __future__ import annotations

"""
Chlorination Process Optimization

This module optimizes water treatment chlorination processes using
differential evolution. It minimizes total annual costs (chemical, construction,
maintenance) subject to water quality constraints (residual chlorine, TTHMs, HAAs).

Key Components:
- Process simulation via PyStimela
- Multi-objective scalarization with penalty functions
- Economic evaluation (CAPEX/OPEX)
- Differential evolution optimization
"""

import json
import argparse
from importlib import import_module
from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
from scipy.optimize import differential_evolution

datatypes = None
dwtmodels = None

# Required minimum E.coli log10 reduction, log10(N0/N). Fixed target (1-log = 90% removal).
ECOLI_LOG_REDUCTION_MIN = 2.0
# Penalty weight for E.coli log-reduction violations (hardcoded, not from config).
LAM_ECOLI = 1e6


def _require_pystimela() -> None:
    """Load pystimela lazily and raise a clear runtime dependency error."""
    global datatypes, dwtmodels
    if datatypes is not None and dwtmodels is not None:
        return

    try:
        datatypes = import_module("pystimela.datatypes")
        dwtmodels = import_module("pystimela.dwtmodels")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "The 'pystimela' package is required to run optimization. "
            "Install pystimela to execute this command."
        ) from exc


# ============================================================================
# Configuration Dataclasses
# ============================================================================

@dataclass
class Limits:
    """
    Process limits for regulatory/operational bounds.

    Control variable bounds define the search space for optimization.
    Constraint bounds define feasibility requirements for the solution.
    """
    # Control variable bounds
    chlorine_dose_min: float = 0.1  # [mg/L] minimum chlorine dose
    chlorine_dose_max: float = 5.0  # [mg/L] maximum chlorine dose
    volume_min: float = 1.0  # [m³] minimum contact tank volume
    volume_max: float = 30.0  # [m³] maximum contact tank volume

    # Constraint bounds (effluent quality requirements)
    residual_min: float = 0.4  # [mg/L] minimum free chlorine residual
    tthms_max: float = 80.0  # [µg/L] maximum total trihalomethanes
    haas_max: float = 60.0  # [µg/L] maximum haloacetic acids

    # Residence time constraints
    theta_min: float = 5.0  # [min] minimum residence time in reactor
    theta_max: float = 60.0  # [min] maximum residence time in reactor


@dataclass
class Weights:
    """
    Penalty weights for constraint violations in scalarized objective.

    These multipliers convert constraint violations into cost penalties,
    implementing a soft-constraint approach (big-M method).
    """
    lam_residual: float = 1e6  # penalty weight for insufficient residual chlorine
    lam_tthms: float = 1e5  # penalty weight for TTHMs violations
    lam_haas: float = 1e5  # penalty weight for HAAs violations
    lam_theta: float = 1e6  # penalty weight for residence time violations

@dataclass
class InitialStates:
    """
    Initial conditions for chlorination unit process.

    These values represent the starting state of the system,
    particularly the disinfection byproducts and residual chlorine.
    """
    reschl_initial: float = 0.001  # [mg/L] residual chlorine at start
    tthms_initial: float = 0.0  # [µg/L] initial TTHMs concentration
    haas_initial: float = 0.0  # [µg/L] initial HAAs concentration
    ecoli_initial: float = 0.0  # [-] initial E.coli concentration in tank


@dataclass
class Params:
    """
    Process model parameters for chlorination.

    Includes:
    - Hydraulic parameters (baffling factor)
    - Chemical parameters (chlorine solution concentration)
    - Economic parameters (chemical costs, financial factors)
    """
    # Chlorination parameters
    baffling_factor: float = 1.0  # [-] baffling factor (0-1, influences T10 contact time)

    # Chemical cost parameters
    price_per_kg: float = 0.51  # [€/kg] chlorine solution price
    solution: float = 0.15  # [-] chlorine concentration in commercial solution (15%)

    # Financial parameters for CAPEX annualization
    n_years: int = 40  # project lifetime [years]
    r_nom: float = 0.05  # nominal interest rate (Netherlands: 5%, Greece: 7%)
    infl: float = 0.031  # inflation rate (Netherlands: 3.1%, Greece: 3.6%)


# ============================================================================
# Water Quality Input Handling
# ============================================================================

class QualityInputs:
    """
    Time-series water quality parameters for chlorination simulation.

    Constructs time-series arrays from CSV or JSON configuration,
    representing inlet water characteristics over the simulation period.
    """

    COLUMNS = [
        "timestamp", "flow", "temperature", "doc",
        "ammonia", "ph", "uv254", "bromide", "ecoli"
    ]

    def __init__(self, timestamps: List[float], **attrs):
        """
        Initialize with timestamps and water quality attributes.

        Args:
            timestamps: List of time points [s]
            **attrs: Water quality parameters as numpy arrays
        """
        self.timestamps = timestamps
        self.__dict__.update(attrs)

    @classmethod
    def from_json(cls, inputs_dict: Dict) -> "QualityInputs":
        """
        Build QualityInputs from JSON-style configuration dictionary.

        Args:
            inputs_dict: Configuration with timeframe, timestep, and wq_parameters

        Returns:
            QualityInputs instance with constant time-series
        """
        timestamps = inputs_dict["timestamps"]
        n_steps = len(timestamps)

        wq_params = inputs_dict["wq_parameters"]

        def get_val(key: str) -> float:
            """Extract value from wq_parameters dict, return NaN if missing."""
            return float(wq_params[key]["value"]) if key in wq_params else np.nan

        # Missing E.coli in the config defaults to 0 rather than NaN
        ecoli_val = get_val("ecoli")
        if np.isnan(ecoli_val):
            ecoli_val = 0.0

        # Create constant time-series arrays for each parameter
        return cls(
            timestamps=timestamps,
            flow=np.full(n_steps, get_val("flow")),
            temperature=np.full(n_steps, get_val("temperature")),
            doc=np.full(n_steps, get_val("DOC")),
            ammonia=np.full(n_steps, get_val("ammonia")),
            ph=np.full(n_steps, get_val("pH")),
            uv254=np.full(n_steps, get_val("uv254")),
            bromide=np.full(n_steps, get_val("bromide")),
            ecoli=np.full(n_steps, ecoli_val)
        )

    def to_wq_list(self) -> List[datatypes.WaterQualityParams]:
        """
        Convert to PyStimela WaterQualityParams list.

        Returns:
            List of WaterQualityParams objects for each timestep
        """
        _require_pystimela()
        fields = [c for c in self.COLUMNS if c != "timestamp"]
        n = len(self.timestamps)
        wq_list = []

        for i in range(n):
            kwargs = {name: float(getattr(self, name)[i]) for name in fields}
            wq = datatypes.WaterQualityParams(timestamp=self.timestamps[i], **kwargs)
            wq_list.append(wq)

        return wq_list


# ============================================================================
# Process Simulation
# ============================================================================

def stimela_simulate(
        inputs: QualityInputs,
        params: Params,
        initials: InitialStates,
        chlorine_dose: float,
        volume: float,
) -> Dict[str, float]:
    """
    Simulate chlorination process using PyStimela.

    This wrapper orchestrates the chlorination treatment with dosing and
    disinfection byproduct formation kinetics.

    Args:
        inputs: Time-series water quality parameters
        params: Process model parameters
        initials: Initial state conditions
        chlorine_dose: Chlorine dose [mg/L]
        volume: Contact tank volume [m³]

    Returns:
        Dictionary with effluent water quality:
        - residual_out: residual chlorine [mg/L]
        - tthms_out: total trihalomethanes [µg/L]
        - haas_out: haloacetic acids [µg/L]
    """
    _require_pystimela()
    timestamps = inputs.timestamps

    # Convert chlorine dose (mg/L) to dosage rate (g/h) for Stimela
    # 1 mg/L = 1 g/m³; multiply by flow [m³/h] = g/h
    flow_m3h = float(inputs.flow[0])  # m³/h
    dosage_gph = chlorine_dose * flow_m3h  # g/h

    # Calculate residence time (theta) in minutes
    # theta = Volume / Flow
    theta = (volume / flow_m3h) * 60.0  # convert hours to minutes

    # Prepare input water quality
    in_wq_list = inputs.to_wq_list()
    in_wq_params = datatypes.ListWaterQualityParams(
        timestamps=timestamps,
        wqparams=in_wq_list
    )

    # ---- Chlorination Stage ----
    chl_params = datatypes.ChlorinationParams(
        volume=volume,
        baffling_factor=params.baffling_factor
    )

    # Initialize chlorination state
    init_state = datatypes.ChlorinationState(
        reschl=initials.reschl_initial,
        tthms=initials.tthms_initial,
        haas=initials.haas_initial,
        ecoli=initials.ecoli_initial
    )

    # Run chlorination simulation
    chl_process = dwtmodels.Chlorination(params=chl_params)
    chl_results = chl_process.simulate(
        t_eval=timestamps,
        init_state=init_state,
        wq_params=in_wq_params,
        dosage=[dosage_gph for _ in timestamps]  # g/h for Stimela
    )

    # Extract final effluent quality
    return {
        "residual_out": float(chl_results["reschl"][-1]),
        "tthms_out": float(chl_results["ttmhms"][-1]),
        "haas_out": float(chl_results["haas"][-1]),
        "ecoli_out": float(chl_results["ecoli"][-1]),
        "theta": theta
    }


# ============================================================================
# Economic Calculations
# ============================================================================

def capital_recovery_factor(r_real: float, n: int) -> float:
    """
    Calculate Capital Recovery Factor for CAPEX annualization.

    CRF converts a present value to equivalent annual cost over n years
    at real interest rate r_real.

    Args:
        r_real: Real interest rate (adjusted for inflation)
        n: Project lifetime [years]

    Returns:
        Capital recovery factor [-]
    """
    return (r_real * (1 + r_real) ** n) / ((1 + r_real) ** n - 1)


def compute_chlorine_cost(
        chlorine_dose: float,
        flow_m3h: float,
        params: Params
) -> float:
    """
    Calculate annual chlorine chemical cost.

    Args:
        chlorine_dose: Chlorine dose [mg/L]
        flow_m3h: Average flow rate [m³/h]
        params: Process parameters with chlorine properties

    Returns:
        Annual chemical cost [€/year]
    """
    # Convert dose to mass flow rate
    # 1 mg/L = 1 g/m³; multiply by flow [m³/h] = g/h
    cl2_g_h = chlorine_dose * flow_m3h

    # Convert to kg/day
    cl2_kg_d = cl2_g_h / 1000.0 * 24.0

    # Convert to commercial product mass (accounting for solution concentration)
    cl_solution_kg_d = cl2_kg_d / params.solution

    # Annualize cost
    chlorine_cost_year = params.price_per_kg * cl_solution_kg_d * 365.0

    return chlorine_cost_year


def compute_tank_cost(
        volume: float,
        params: Params
) -> Tuple[float, float, float]:
    """
    Calculate annualized tank costs (CAPEX + OPEX).

    Uses empirical cost equations for construction and maintenance.

    Args:
        volume: Contact tank volume [m³]
        params: Financial parameters for annualization

    Returns:
        Tuple of (crf, annualized_construction_cost, maintenance_cost) [€/year]
    """
    # Calculate real interest rate (inflation-adjusted)
    r_real = (1 + params.r_nom) / (1 + params.infl) - 1

    # Capital recovery factor
    crf = capital_recovery_factor(r_real, params.n_years)

    # Empirical cost equations
    constr_cost = crf * (-0.0207 * volume ** 2 + 769.34 * volume - 1275.73)
    maintenance_cost = -0.00024 * volume ** 2 + 8.475 * volume + 452.65

    return crf, constr_cost, maintenance_cost


def compute_constraint_penalties(
        residual_out: float,
        tthms_out: float,
        haas_out: float,
        theta_out: float,
        ecoli_out: float,
        ecoli_in: float,
        limits: Limits,
        weights: Weights
) -> float:
    """
    Calculate soft-constraint penalty for violations.

    Implements big-M penalty method for constraint violations:
    - Residual chlorine below residual_min
    - TTHMs exceeding tthms_max
    - HAAs exceeding haas_max
    - E.coli log reduction below ECOLI_LOG_REDUCTION_MIN

    Args:
        residual_out: Effluent residual chlorine [mg/L]
        tthms_out: Effluent TTHMs [µg/L]
        haas_out: Effluent HAAs [µg/L]
        ecoli_out: Effluent E.coli [CFU/L]
        ecoli_in: Influent E.coli [CFU/L]
        limits: Constraint limits
        weights: Penalty weights

    Returns:
        Total penalty value (unitless, added to objective)
    """
    penalty = 0.0

    # Residual chlorine constraint (lower bound, normalized)
    if residual_out < limits.residual_min:
        v_resid = (limits.residual_min - residual_out) / max(limits.residual_min, 1e-6)
        penalty += weights.lam_residual * v_resid

    # TTHMs constraint (upper bound, normalized)
    if tthms_out > limits.tthms_max:
        v_tthm = (tthms_out - limits.tthms_max) / max(limits.tthms_max, 1e-6)
        penalty += weights.lam_tthms * v_tthm

    # HAAs constraint (upper bound, normalized)
    if haas_out > limits.haas_max:
        v_haa = (haas_out - limits.haas_max) / max(limits.haas_max, 1e-6)
        penalty += weights.lam_haas * v_haa

    # Residence time constraint (minimum)
    if theta_out < limits.theta_min:
        violation = limits.theta_min - theta_out
        penalty += weights.lam_theta * violation

    # Residence time constraint (maximum)
    if theta_out > limits.theta_max:
        violation = theta_out - limits.theta_max
        penalty += weights.lam_theta * violation

    # E.coli log-reduction constraint (require >= ECOLI_LOG_REDUCTION_MIN)
    if ecoli_in > 0:
        lrv = np.log10(ecoli_in / max(ecoli_out, 1e-12))
        if lrv < ECOLI_LOG_REDUCTION_MIN:
            v_ecoli = (ECOLI_LOG_REDUCTION_MIN - lrv) / ECOLI_LOG_REDUCTION_MIN
            penalty += LAM_ECOLI * v_ecoli

    return penalty


# ============================================================================
# Optimization Objective Function
# ============================================================================

def objective_scalar(
        x: np.ndarray,
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates
) -> Tuple[float, Dict[str, float]]:
    """
    Scalarized objective function: minimize total annual cost + penalties.

    This is the function minimized by differential evolution. It:
    1. Unpacks decision variables
    2. Simulates the process
    3. Computes base costs (chemical, tank)
    4. Adds constraint violation penalties

    Args:
        x: Decision vector [chlorine_dose, volume]
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states

    Returns:
        Tuple of (objective_value, cost_breakdown_dict)
    """
    # Unpack decision variables
    chlorine_dose = float(x[0])  # mg/L
    volume = float(x[1])  # m³

    # Simulate process
    sim = stimela_simulate(
        inputs, params, initials,
        chlorine_dose, volume
    )

    residual_out = sim["residual_out"]
    tthms_out = sim["tthms_out"]
    haas_out = sim["haas_out"]
    ecoli_out = sim["ecoli_out"]
    theta_out = sim["theta"]

    # Influent E.coli (for log-reduction constraint)
    ecoli_in = float(np.mean(inputs.ecoli))

    # Calculate average flow rate [m³/h]
    flow_m3h = float(np.mean(inputs.flow))

    # ---- Cost Components ----

    # Chemical cost [€/year]
    chlorine_cost_year = compute_chlorine_cost(chlorine_dose, flow_m3h, params)

    # Tank cost [€/year]
    crf, constr_cost, maintenance_cost = compute_tank_cost(volume, params)
    tank_cost_year = constr_cost + maintenance_cost

    # Base objective (total annual cost)
    base = chlorine_cost_year + tank_cost_year

    # ---- Constraint Penalties ----
    penalty = compute_constraint_penalties(
        residual_out, tthms_out, haas_out, theta_out,
        ecoli_out, ecoli_in, limits, weights
    )

    # Total objective
    objective_value = base + penalty

    # Detailed cost breakdown
    cost_breakdown = {
        "crf": crf,
        "chlorine_cost_year": chlorine_cost_year,
        "constr_cost_year": constr_cost,
        "maintenance_cost_year": maintenance_cost,
        "tank_cost_year": tank_cost_year,
        "penalty": penalty,
        "theta": theta_out
    }

    return objective_value, cost_breakdown


# ============================================================================
# Optimization Solver
# ============================================================================

def solve(
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        seed: int = 42,
        maxiter: int = 60,
        popsize: int = 15,
        tol: float = 1e-3,
) -> Dict:
    """
    Solve optimization problem using differential evolution.

    Minimizes total annual cost subject to water quality constraints
    by optimizing chlorine dose and contact tank volume.

    Args:
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        seed: Random seed for reproducibility
        maxiter: Maximum number of DE iterations
        popsize: Population size for DE
        tol: Convergence tolerance

    Returns:
        Dictionary with optimization results, including:
        - success: optimization success flag
        - message: solver message
        - fun: optimal objective value
        - x_opt: optimal decision variables
        - outputs: effluent water quality
        - costs_breakdown: detailed cost analysis
    """
    # Define decision variable bounds
    bounds = [
        (limits.chlorine_dose_min, limits.chlorine_dose_max),  # chlorine dose [mg/L]
        (limits.volume_min, limits.volume_max),  # volume [m³]
    ]

    # Wrapper for objective function (DE expects single return value)
    def objective_wrapper(x: np.ndarray) -> float:
        obj_val, _ = objective_scalar(x, inputs, params, limits, weights, initials)
        return obj_val

    # Run differential evolution
    result = differential_evolution(
        objective_wrapper,
        bounds=bounds,
        strategy="best1bin",
        maxiter=maxiter,
        popsize=popsize,
        tol=tol,
        mutation=(0.5, 1.0),
        recombination=0.7,
        seed=seed,
        polish=True,
        disp=True
    )

    # Unpack optimal solution
    x_opt = result.x
    chlorine_dose = float(x_opt[0])
    volume = float(x_opt[1])

    # Re-simulate with optimal parameters to extract detailed results
    sim = stimela_simulate(
        inputs, params, initials,
        chlorine_dose, volume
    )

    # Re-evaluate objective to get cost breakdown
    obj_val, costs = objective_scalar(
        x_opt, inputs, params, limits, weights, initials
    )

    # Extract effluent quality
    residual_out = sim["residual_out"]
    tthms_out = sim["tthms_out"]
    haas_out = sim["haas_out"]
    ecoli_out = sim["ecoli_out"]
    theta = sim["theta"]

    # E.coli log10 reduction, log10(N0/N) (None when no influent E.coli)
    ecoli_in = float(np.mean(inputs.ecoli))
    ecoli_log_reduction = (
        round(float(np.log10(ecoli_in / max(ecoli_out, 1e-12))), 3)
        if ecoli_in > 0 else None
    )

    # Calculate average flow and derived values
    avg_flow = float(np.mean(inputs.flow))  # m³/h
    cl2_g_h = chlorine_dose * avg_flow
    cl2_kg_d = cl2_g_h / 1000.0 * 24.0
    cl_solution_kg_d = cl2_kg_d / params.solution

    # Compile comprehensive results report
    report = {
        "success": bool(result.success),
        "message": str(result.message),
        "fun": round(float(result.fun), 2),
        "x_opt": {
            "chlorination_chemical_dose": round(chlorine_dose,2),
            "chlorination_volume": round(volume,2),
        },
        "derived": {
            "avg_flow_m3h": avg_flow,
            "cl2_g_per_h": round(cl2_g_h,2),
            "cl2_kg_per_d": round(cl2_kg_d,2),
            "cl_solution_kg_per_d": round(cl_solution_kg_d,2),
            "crf_used": round(costs["crf"], 4),
        },
        "inputs": {
            "flow_mean_m3h": avg_flow,
            "DOC_input_mgL": float(np.mean(inputs.doc)),
            "pH_input": float(np.mean(inputs.ph)),
            "average_ecoli_in": ecoli_in,
        },
        "outputs": {
            "residual_out_mgL": round(residual_out,3),
            "tthms_out_ugL": round(tthms_out,3),
            "haas_out_ugL": round(haas_out,3),
            "ecoli_out": round(ecoli_out,3),
            "ecoli_log_reduction": ecoli_log_reduction,
            "theta_min": round(theta,2)
        },
        "constraints": {
            "residual_min_mgL": limits.residual_min,
            "tthms_max_ugL": limits.tthms_max,
            "haas_max_ugL": limits.haas_max,
            "theta_min_min": limits.theta_min,
            "theta_max_min": limits.theta_max,
            "ecoli_log_reduction_min": ECOLI_LOG_REDUCTION_MIN,
        },
        "optimal variables": {
            "chlorine_dose_mgL": round(chlorine_dose,2),
            "volume_m3": round(volume,2)
        },
        "costs_breakdown": {
            "chlorine_cost_year_eur": round(costs["chlorine_cost_year"], 1),
            "constr_cost_year": round(costs["constr_cost_year"], 1),
            "maintenance_cost_year": round(costs["maintenance_cost_year"], 1),
            "tank_cost_year_eur": round(costs["tank_cost_year"], 1),
            "penalty_added_unitless": costs["penalty"],
            "obj_fun_value": round(obj_val, 1),
        }
    }

    return report


# ============================================================================
# Command-Line Interface
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Run chlorination optimization from JSON config or CSV"
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to configuration JSON file"
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility"
    )
    parser.add_argument(
        "--maxiter",
        type=int,
        default=300,
        help="Maximum DE iterations"
    )
    parser.add_argument(
        "--popsize",
        type=int,
        default=20,
        help="DE population size"
    )
    parser.add_argument(
        "--out_json",
        type=str,
        default="outputs/chlorination_results.json",
        help="Path to output results JSON file"
    )
    return parser


def parse_cli_args(argv=None) -> argparse.Namespace:
    """Parse CLI args for chlorination optimization."""
    return build_parser().parse_args(argv)


def run_cli(args: argparse.Namespace) -> Dict:
    """Run optimization from parsed CLI args and write output JSON."""

    from pystimela_optim import api as optim_api

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    algo = cfg.get("algorithm", {})
    # Keep historical behavior: algorithm values in config take precedence.
    seed = algo.get("seed", args.seed)
    maxiter = algo.get("maxiter", args.maxiter)
    popsize = algo.get("popsize", args.popsize)
    tol = algo.get("tol", 1e-3)

    report = optim_api.optimize_chlorination(
        cfg,
        seed=seed,
        maxiter=maxiter,
        popsize=popsize,
        tol=tol,
    )

    # Save results
    with open(args.out_json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Results saved to {args.out_json}")
    return report


def main(argv=None):
    """CLI entry point."""
    args = parse_cli_args(argv)
    run_cli(args)


if __name__ == "__main__":
    main()
