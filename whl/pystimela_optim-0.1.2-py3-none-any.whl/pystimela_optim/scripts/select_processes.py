import pandas as pd
import json
import argparse
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="Select enabled water treatment processes from CSV")
    parser.add_argument("--csv", type=str, required=True, help="Path to CSV file with columns: processes, enabled")
    parser.add_argument("--out", type=str, required=True, help="Path to output JSON file")
    args = parser.parse_args()

    csv_path = Path(args.csv)
    out_path = Path(args.out)

    # Read and validate
    df = pd.read_csv(csv_path, sep=None,engine='python')
    if "processes" not in df.columns or "enabled" not in df.columns:
        raise ValueError("CSV must contain 'processes' and 'enabled' columns")

    # Filter enabled == 1
    enabled_df = df[df["enabled"] == 1].copy()
    enabled_df["processes"] = enabled_df["processes"].str.strip()

    data = {
        "enabled": enabled_df["processes"].tolist(),
        "count": len(enabled_df)
    }

    # Save to JSON
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    # Print summary
    print(f"✅ Saved {len(enabled_df)} enabled processes to {out_path}")
    for p in enabled_df["processes"]:
        print(f"  - {p}")

if __name__ == "__main__":
    main()
