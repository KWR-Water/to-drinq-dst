"""
Configuration Preparation Tool for Dual Filtration Optimization

This module builds the optimization configuration from a CSV file. It:
- Reads baseline design from django_outputs.json
- Automatically generates process bounds with configurable scaling
- Allows manual override of all parameters
- Validates inputs and generates final JSON configuration

The generated configuration is consumed by dual_filtration_optim.py.
"""

import json
import os
import sys
from typing import Dict, Any
import csv

# ============================================================================
# Constants and Defaults
# ============================================================================

BOUNDS_SCALE = 10.0  # Fixed scaling factor for bounds: ±10× baseline values

DEFAULT_WEIGHTS = {
    "lam_TSS": 2e5,
    "lam_HL": 2e5,
    "lam_ACC1": 1e5,
    "lam_ACC2": 1e5,
    "lam_theta": 1e5,

}

DEFAULT_ALGO = {
    "seed": 42,
    "maxiter": 100,
    "popsize": 15,
    "tol": 1e-3,
    "workers": 1,
}

DEFAULT_PARAMS = {
    # Common physical parameters
    "lwater": 1.0,
    "rhod": 30.0,
    # Upper bed (sand) kinetic parameters
    "filporo1": 40.0,
    "lambda01": 0.003,
    "n1": 20.0,
    "numcel1": 6,
    # Lower bed (anthracite) kinetic parameters
    "filporo2": 38.0,
    "lambda02": 0.03,
    "n2": 3.0,
    "numcel2": 6,
    # Financial parameters
    "n_years": 40,
    "r_nom": 0.05,
    "infl": 0.031,
    # Filter media costs
    "sand_filter_cost": 80.0,
    "coal_filter_cost": 232.0,
}

DJANGO_JSON_PATH = "configs/django_outputs.json"
OUT_JSON_PATH = "configs/dual_filtration_config.json"
WQ_JSON_PATH = "configs/in_wq_params.json"

TIMESTAMPS_CSV_PATH = "inputs/timestamps/filtration_dual.csv"
PLANT_DESIGN_CSV_PATH = "inputs/django_plant_design.csv"


def read_plant_design(path: str) -> Dict[str, Any]:
    """Read plant-wide economic parameters (n_years, r_nom, infl) from CSV."""
    values = {}
    with open(path, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter=";"):
            values[row["parameters"].strip()] = row["value"].strip()
    return {
        "n_years": int(values["n_years"]),
        "r_nom": float(values["r_nom"]),
        "infl": float(values["infl"]),
    }


# Velocity constraint: filtration velocity must stay within [V_MIN_MH, V_MAX_MH] m/h
V_MIN_MH = 5.0
V_MAX_MH = 15.0


# ============================================================================
# Load configurations from csv
# ============================================================================

def load_config_from_csv(csv_path: str):
    config = {'decision_variables': {}, 'constraints': {}, 'initial_conditions': {},
              'model_parameters': {}, 'operation': {}, 'penalties': {}, 'optimization': {}, 'simulation': {}}
    with open(csv_path, 'r', encoding='utf-8') as f:
        # Read a sample of the file to detect the delimiter automatically
        sample = f.read(2048)
        f.seek(0)

        # Try to guess the delimiter (usually ',' or ';' or '\t')
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample)
        except csv.Error:
            # fallback if detection fails (e.g., single-line CSV)
            dialect = csv.get_dialect('excel')
            dialect.delimiter = ','
        reader = csv.DictReader(f, dialect=dialect)
        reader.fieldnames = [name.strip().lstrip('\ufeff') for name in reader.fieldnames]
        for row in reader:
            section = row['section'].lower().replace('-', '_')
            param, value = row['parameter'], row['value']
            if value.lower() == 'auto': converted_value = 'auto'
            elif value.lower() in ('true', 'false'): converted_value = value.lower() == 'true'
            else:
                try: converted_value = float(value) if '.' in value else int(value)
                except ValueError: converted_value = value
            if section in config: config[section][param] = converted_value
    return config


# ============================================================================
# JSON I/O Utilities
# ============================================================================

def load_json(path: str) -> Dict[str, Any]:
    """Load JSON file and return as dictionary."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: Dict[str, Any]) -> None:
    """Write dictionary to JSON file with automatic directory creation."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def read_timestamps(path: str) -> list:
    """Read timestamps CSV (single column 'time_s') and return list of floats."""
    with open(path, "r") as f:
        lines = [l.strip() for l in f if l.strip()]
    # skip header if it starts with a letter
    return [float(l) for l in lines if not l[0].isalpha()]


# ============================================================================
# Configuration Builders
# ============================================================================

def build_limits_from_django(
    django_json_path: str,
    scale: float,
    tss_out_max: float,
    headloss_max: float,
    accum1_max: float,
    accum2_max: float,
    theta_min: float = 5.0,
    theta_max: float = 60.0
) -> Dict[str, float]:
    """Generate optimization bounds from baseline design values."""
    data = load_json(django_json_path)
    base = data.get("Process_outputs", data)

    try:
        filt_surf = float(base["dual_filtration_surface"]["value"])
        filt_depth_a = float(base["dual_filtration_depth"]["value"])
        filt_depth_b = float(base["dual_filtration_depth_b"]["value"])
        filt_grain_a = float(base["dual_filtration_grain_size_a"]["value"])
        filt_grain_b = float(base["dual_filtration_grain_size_b"]["value"])
    except Exception as e:
        raise KeyError(f"Missing expected fields in {django_json_path}: {e}")

    return {
        "surf_min_m2": filt_surf / scale,
        "surf_max_m2": filt_surf * scale,
        "lbed1_min_m": filt_depth_a / scale,
        "lbed1_max_m": filt_depth_a * scale,
        "lbed2_min_m": filt_depth_b / scale,
        "lbed2_max_m": filt_depth_b * scale,
        "diam1_min_mm": filt_grain_a / scale,
        "diam1_max_mm": filt_grain_a * scale,
        "diam2_min_mm": filt_grain_b / scale,
        "diam2_max_mm": filt_grain_b * scale,
        "headloss_max_m": headloss_max,
        "theta_min": theta_min,
        "theta_max": theta_max,
        "tss_out_max_mgL": tss_out_max,
        "accum1_max_kgm3": accum1_max,
        "accum2_max_kgm3": accum2_max,
    }


def read_wq_params(json_path: str) -> Dict[str, Any]:
    """Read inlet water quality parameters from JSON."""
    data = load_json(json_path)
    wp = data["WQ_parameters"]
    return {
        "flow": wp["flow"],
        "temperature": wp["temperature"],
        "suspended_solids": wp["suspended_solids"],
    }


def assemble_config(
    limits: Dict[str, Any],
    initials: Dict[str, Any],
    params: Dict[str, Any],
    wq_params: Dict[str, Any],
    backwash_freq_h: float,
    weights: Dict[str, Any] = None,
    algo: Dict[str, Any] = None,
    timestamps: list = None,
) -> Dict[str, Any]:
    """Assemble final configuration JSON structure."""
    # Use defaults if not provided
    if weights is None:
        weights = DEFAULT_WEIGHTS
    if algo is None:
        algo = DEFAULT_ALGO
    
    bounds_list = [
        {"name": "surf_m2", "min": limits["surf_min_m2"], "max": limits["surf_max_m2"], "units": "m²"},
        {"name": "lbed1_m", "min": limits["lbed1_min_m"], "max": limits["lbed1_max_m"], "units": "m"},
        {"name": "lbed2_m", "min": limits["lbed2_min_m"], "max": limits["lbed2_max_m"], "units": "m"},
        {"name": "diam1_mm", "min": limits["diam1_min_mm"], "max": limits["diam1_max_mm"], "units": "mm"},
        {"name": "diam2_mm", "min": limits["diam2_min_mm"], "max": limits["diam2_max_mm"], "units": "mm"},
    ]

    return {
        "process": "dual_filtration",
        "inputs": {
            "timestamps": timestamps if timestamps is not None else [1, 3600],
            "wq_parameters": wq_params,
        },
        "limits": limits,
        "initials": initials,
        "weights": weights,
        "params": params,
        "algorithm": algo,
        "backwash_freq_h": backwash_freq_h,
        "bounds": bounds_list,
        "notes": {
            "source": "auto-generated from django_outputs.json",
            "wq_csv_format": "semicolon-delimited; headers: timestamp;flow;temperature;suspended_solids",
            "scaling": f"bounds derived using ±{BOUNDS_SCALE}× from django base values",
        },
    }


def generate_config_from_csv(csv_path: str, wq_json_path: str):
    """Generate configuration from CSV."""
    print(f"Reading configuration from: {csv_path}")
    
    csv_config = load_config_from_csv(csv_path)
    wq_params = read_wq_params(wq_json_path)
    use_auto = csv_config['decision_variables'].get('use_auto_bounds', True)

    if use_auto:
        print("   Using auto-calculated bounds from django_outputs.json")
    else:
        print("   Using manual bounds from CSV")

    auto_limits = build_limits_from_django(
        DJANGO_JSON_PATH, BOUNDS_SCALE,
        csv_config['constraints'].get('tss_out_max', 1.0),
        csv_config['constraints'].get('headloss_max', 2.0),
        csv_config['constraints'].get('accum1_max', 500000.0),
        csv_config['constraints'].get('accum2_max', 500000.0),
        csv_config['constraints'].get('theta_min', 5.0),
        csv_config['constraints'].get('theta_max', 60.0),
    )

    final_limits = auto_limits if use_auto else dict(auto_limits)
    if not use_auto:
        dv = csv_config['decision_variables']
        for key in ['surf_min_m2', 'surf_max_m2', 'lbed1_min_m', 'lbed1_max_m',
                    'lbed2_min_m', 'lbed2_max_m', 'diam1_min_mm', 'diam1_max_mm',
                    'diam2_min_mm', 'diam2_max_mm']:
            if key in dv and dv[key] != 'auto': final_limits[key] = dv[key]

    ic = csv_config.get('initial_conditions', {})
    initials = {
        "suspended_solids_upper_init": ic.get('ss1_initial', 0.0),
        "accumulation_upper_init": ic.get('accum1_initial', 0.0),
        "suspended_solids_lower_init": ic.get('ss2_initial', 0.0),
        "accumulation_lower_init": ic.get('accum2_initial', 0.0),
    }

    params = dict(DEFAULT_PARAMS)
    for key, val in csv_config.get('model_parameters', {}).items():
        if key in params: params[key] = val

    # Override plant-wide economic parameters from the shared plant-design file
    if os.path.exists(PLANT_DESIGN_CSV_PATH):
        plant = read_plant_design(PLANT_DESIGN_CSV_PATH)
        params["n_years"] = plant["n_years"]
        params["r_nom"] = plant["r_nom"]
        params["infl"] = plant["infl"]

    weights = dict(DEFAULT_WEIGHTS)
    for key, val in csv_config.get('penalties', {}).items():
        if key in weights: weights[key] = val

    algo = dict(DEFAULT_ALGO)
    for key, val in csv_config.get('optimization', {}).items():
        if key in algo: algo[key] = val

    timestamps = read_timestamps(TIMESTAMPS_CSV_PATH)

    # Clamp surf bounds to velocity constraint: V = flow/surf must be in [V_MIN_MH, V_MAX_MH]
    flow_m3h = float(wq_params["flow"]["value"])
    final_limits["surf_min_m2"] = max(final_limits["surf_min_m2"], flow_m3h / V_MAX_MH)
    final_limits["surf_max_m2"] = min(final_limits["surf_max_m2"], flow_m3h / V_MIN_MH)

    # NOW USE assemble_config to create the proper structure
    config = assemble_config(
        limits=final_limits,
        initials=initials,
        params=params,
        wq_params=wq_params,
        backwash_freq_h=csv_config.get('operation', {}).get('backwash_freq', 0.0),
        weights=weights,
        algo=algo,
        timestamps=timestamps,
    )

    write_json(OUT_JSON_PATH, config)
    print(f"Configuration saved to: {OUT_JSON_PATH}")

###
# Entry point
###


def main(argv=None) -> None:
    """CLI entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="Prepare dual filtration optimization configuration.")
    parser.add_argument("--in_wq_params", required=True)
    parser.add_argument("--csv_config", default="inputs/config_filtration_dual.csv")
    args = parser.parse_args()

    WQ_JSON_PATH = args.in_wq_params
    if not os.path.exists(WQ_JSON_PATH):
        sys.exit(f"Error: WQ parameters file not found at {WQ_JSON_PATH}")
    if not os.path.exists(args.csv_config):
        sys.exit(f"Error: CSV config file not found at {args.csv_config}")

    print(f"Loaded WQ parameters from: {WQ_JSON_PATH}")
    generate_config_from_csv(args.csv_config, WQ_JSON_PATH)


if __name__ == "__main__":
    main()
