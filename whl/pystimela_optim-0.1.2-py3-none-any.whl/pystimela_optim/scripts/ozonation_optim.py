from __future__ import annotations

"""
Ozonation Process Optimization

This module optimizes water treatment ozonation processes using differential
evolution. It minimizes total annual costs (construction, maintenance, energy)
subject to water quality constraints (bromate, AOC, E. coli).

Key Components:
- Process simulation via PyStimela
- Multi-objective scalarization with penalty functions
- Economic evaluation (CAPEX/OPEX)
- Differential evolution optimization
"""

import json
import time
import argparse
from importlib import import_module
from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
from scipy.optimize import differential_evolution

datatypes = None
dwtmodels = None

# Required minimum E.coli log10 reduction, log10(N0/N). Fixed target (1-log = 90% removal).
ECOLI_LOG_REDUCTION_MIN = 2.0

# Hard wall-clock limit for the optimizer [s]. The DE callback stops the search
# once exceeded; the best solution found so far is returned.
TIME_LIMIT_S = 300.0


def _require_pystimela() -> None:
    """Load pystimela lazily and raise a clear runtime dependency error."""
    global datatypes, dwtmodels
    if datatypes is not None and dwtmodels is not None:
        return

    try:
        datatypes = import_module("pystimela.datatypes")
        dwtmodels = import_module("pystimela.dwtmodels")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "The 'pystimela' package is required to run optimization. "
            "Install pystimela to execute this command."
        ) from exc


# ============================================================================
# Configuration Dataclasses
# ============================================================================

@dataclass
class Limits:
    """
    Process limits for regulatory/operational bounds.

    Control variable bounds define the search space for optimization.
    Constraint bounds define feasibility requirements for the solution.
    """
    # Control variable bounds
    ozone_dosed_min: float = 0.001  # [mg/L] minimum ozone dose
    ozone_dosed_max: float = 5.0  # [mg/L] maximum ozone dose
    hreact_min: float = 0.1  # [m] minimum reactor height
    hreact_max: float = 20.0  # [m] maximum reactor height
    areact_min: float = 0.1  # [m²] minimum reactor cross-sectional area
    areact_max: float = 50.0  # [m²] maximum reactor cross-sectional area

    # Residence time constraints
    theta_min: float = 5.0  # [min] minimum residence time in reactor
    theta_max: float = 60.0  # [min] maximum residence time in reactor

    # Reactor shape plausibility (aspect ratio = height / equivalent diameter)
    aspect_ratio_min: float = 1.0  # [-] min height/diameter (bubble-column plausibility)
    aspect_ratio_max: float = 15.0  # [-] max height/diameter

    # Constraint bounds (effluent quality requirements)
    bromate_max: float = 10.0  # [µg/L] maximum bromate (regulatory)
    aoc_max: float = 500.0  # [µg/L] maximum AOC


@dataclass
class Weights:
    """
    Penalty weights for constraint violations in scalarized objective.

    These multipliers convert constraint violations into cost penalties,
    implementing a soft-constraint approach (big-M method).
    """
    lam_BrO3: float = 1e5  # penalty weight for bromate violations
    lam_AOC: float = 1e5  # penalty weight for AOC violations
    lam_Ecoli: float = 1e6  # penalty weight for E. coli violations

    lam_theta: float = 1e6  # penalty weight for residence time violations
    lam_aspect: float = 1e5  # penalty weight for implausible reactor aspect ratio


@dataclass
class InitialStates:
    """
    Initial conditions for ozonation unit process.

    These values represent the starting state of the reactor,
    particularly the concentrations in reactor cells.
    """
    o3_liquid_initial: float = 0.0  # [mg/L] initial dissolved ozone
    o3_gas_initial: float = 0.0  # [mg/L] initial gaseous ozone
    uv254_initial: float = 0.0  # [1/m] initial UV254 absorbance
    bromate_initial: float = 0.0  # [µg/L] initial bromate
    ecoli_initial: float = 0.0  # [CFU/L] initial E. coli
    ct_ecoli_initial: float = 0.0  # [-] initial CT for E. coli


@dataclass
class Params:
    """
    Process model parameters for ozonation.

    Includes:
    - Reactor configuration (co-current vs counter-current)
    - Kinetic parameters (ozone decay, bromate formation, E. coli inactivation)
    - Economic parameters (energy costs, financial factors)
    """
    meetee: bool  # REQUIRED: True = co-current, False = counter-current

    # Ozonation kinetic parameters
    kuv_sel: bool = True  # flag: use UV rate constant
    kuv: float = 0.5  # [1/s] UV rate constant
    y_factor: float = 0.01  # [(mg/L)/(1/m)] stoichiometric yield factor
    kafbo3_sel: bool = True  # flag: use ozone decay constant
    kafbo3: float = 0.27164  # [1/s] ozone decay constant
    factor_klo3: float = 0.04  # bromate formation scaling factor
    db0: float = 3.0  # [m] initial bromide-related parameter
    ceuva254_sel: bool = True  # flag for UV absorbance coefficient
    ceuva254: float = 3.0  # UV absorbance coefficient
    f_bro3init: float = 2.5  # initial bromate fraction
    kct_bro3_sel: bool = True  # flag for Ct–bromate constant
    ktc_bro3: float = 3.0  # Ct–bromate constant
    f_aoc_sel: bool = True  # flag for AOC fraction
    f_aoc: float = 50.0  # [(µg-C/L)/(mg-O3/L)] AOC fraction parameter
    kec_sel: bool = True  # flag for E. coli inactivation rate
    kec: float = 300.0  # E. coli inactivation rate constant
    ct_lagec: float = 0.01  # Ct lag for E. coli inactivation
    numcel: int = 1  # number of reactor compartments

    # Energy cost parameters
    sec_kwh_per_kg_o3: float = 15.0  # [kWh/kg] specific energy consumption
    elec_eur_per_kwh: float = 0.14  # [€/kWh] electricity price
    hours_per_year: int = 8765  # hours per year

    # Financial parameters for CAPEX annualization
    n_years: int = 40  # project lifetime [years]
    r_nom: float = 0.05  # nominal interest rate (Netherlands: 5%, Greece: 7%)
    infl: float = 0.031  # inflation rate (Netherlands: 3.1%, Greece: 3.6%)


# ============================================================================
# Water Quality Input Handling
# ============================================================================

class QualityInputs:
    """
    Time-series water quality parameters for ozonation simulation.

    Constructs time-series arrays from CSV file or JSON configuration,
    representing inlet water characteristics over the simulation period.
    """

    COLUMNS = [
        "timestamp", "flow", "temperature", "doc",
        "ozone", "ph", "uv254", "bromide", "bromate",
        "ozone_dosed", "ecoli", "aoc", "gas_flow", "cgo_o3"
    ]

    def __init__(self, timestamps: List[float], **attrs):
        """
        Initialize with timestamps and water quality attributes.

        Args:
            timestamps: List of time points [s]
            **attrs: Water quality parameters as numpy arrays
        """
        self.timestamps = timestamps
        self.__dict__.update(attrs)

    @classmethod
    def from_json(cls, inputs_dict: Dict) -> "QualityInputs":
        """
        Build QualityInputs from JSON-style configuration dictionary.

        Args:
            inputs_dict: Configuration with timeframe, timestep, and wq_parameters

        Returns:
            QualityInputs instance with constant time-series
        """
        timestamps = inputs_dict["timestamps"]
        n_steps = len(timestamps)

        wq_params = inputs_dict["wq_parameters"]

        def get_val(key: str) -> float:
            """Extract value from wq_parameters dict, return NaN if missing."""
            return float(wq_params[key]["value"]) if key in wq_params else np.nan

        # Create constant time-series arrays for each parameter
        return cls(
            timestamps=timestamps,
            flow=np.full(n_steps, get_val("flow")),
            temperature=np.full(n_steps, get_val("temperature")),
            doc=np.full(n_steps, get_val("doc")),
            ozone=np.full(n_steps, 0.0),  # Will be set by optimization
            ph=np.full(n_steps, get_val("ph")),
            uv254=np.full(n_steps, get_val("uv254")),
            bromide=np.full(n_steps, get_val("bromide")),
            bromate=np.full(n_steps, get_val("bromate")),
            ozone_dosed=np.full(n_steps, 0.0),  # Will be set by optimization
            ecoli=np.full(n_steps, get_val("ecoli")),
            aoc=np.full(n_steps, get_val("aoc")),
            gas_flow=np.full(n_steps, 0.0),
            cgo_o3=np.full(n_steps, 0.0)
        )

    def to_wq_list(self) -> List[object]:
        """
        Convert to PyStimela WaterQualityParams list.

        Returns:
            List of WaterQualityParams objects for each timestep
        """
        _require_pystimela()
        fields = [c for c in self.COLUMNS if c != "timestamp"]
        n = len(self.timestamps)
        wq_list = []

        for i in range(n):
            kwargs = {name: float(getattr(self, name)[i]) for name in fields}
            wq = datatypes.WaterQualityParams(timestamp=self.timestamps[i], **kwargs)
            wq_list.append(wq)

        return wq_list

    def set_value(self, name: str, value: float) -> None:
        """
        Overwrite a parameter column with a scalar constant.

        Args:
            name: Parameter name
            value: Constant value to fill entire column

        Raises:
            AttributeError: If parameter name is invalid
        """
        if not hasattr(self, name):
            raise AttributeError(f"{name} is not a valid QualityInputs field")

        arr = getattr(self, name)
        setattr(self, name, np.full_like(arr, value, dtype=float))


# ============================================================================
# Process Simulation
# ============================================================================

def stimela_simulate(
        inputs: QualityInputs,
        params: Params,
        initials: InitialStates,
        ozone_dosed: float,
        hreact: float,
        areact: float,
) -> Dict[str, float]:
    """
    Simulate ozonation process using PyStimela.

    This wrapper orchestrates the ozonation reactor simulation.

    Args:
        inputs: Time-series water quality parameters
        params: Process model parameters
        initials: Initial state conditions
        ozone_dosed: Ozone dose [mg/L]
        hreact: Reactor height [m]
        areact: Reactor cross-sectional area [m²]

    Returns:
        Dictionary with effluent water quality:
        - bromate_out: bromate concentration [µg/L]
        - AOC_out: assimilable organic carbon [µg/L]
        - Ecoli_out: E. coli count [CFU/L]
    """
    _require_pystimela()
    timestamps = inputs.timestamps

    # Update water quality inputs with decision variables
    inputs.set_value('ozone_dosed', ozone_dosed)
    inputs.set_value('ozone', ozone_dosed)

    # Prepare input water quality
    in_wq_list = inputs.to_wq_list()

    in_wq_params = datatypes.ListWaterQualityParams(
        timestamps=timestamps,
        wqparams=in_wq_list
    )


    # ---- Ozonation Stage ----
    ozon_params = datatypes.OzonationParams(
        hreact=hreact,
        areact=areact,
        meetee=params.meetee,
        kuv_sel=params.kuv_sel,
        kuv=params.kuv,
        y_factor=params.y_factor,
        kafbo3_sel=params.kafbo3_sel,
        kafbo3=params.kafbo3,
        factor_klo3=params.factor_klo3,
        db0=params.db0,
        ceuva254_sel=params.ceuva254_sel,
        ceuva254=params.ceuva254,
        f_bro3init=params.f_bro3init,
        kct_bro3_sel=params.kct_bro3_sel,
        ktc_bro3=params.ktc_bro3,
        f_aoc_sel=params.f_aoc_sel,
        f_aoc=params.f_aoc,
        kec_sel=params.kec_sel,
        kec=params.kec,
        ct_lagec=params.ct_lagec,
        numcel=params.numcel
    )

    # Initialize state in all compartments
    N = params.numcel
    init_state = datatypes.OzonationState(
        o3_liquid=[initials.o3_liquid_initial] * N,
        o3_gas=[initials.o3_gas_initial] * N,
        uv254=[initials.uv254_initial] * N,
        bromate=[initials.bromate_initial] * N,
        ecoli=[initials.ecoli_initial] * N,
        ct_ecoli=[initials.ct_ecoli_initial] * N
    )

    # Run ozonation simulation
    ozon_process = dwtmodels.Ozonation(params=ozon_params)
    ozon_results = ozon_process.simulate(
        t_eval=timestamps,
        init_state=init_state,
        wq_params=in_wq_params
    )

    # Extract final effluent quality
    ozon_out = ozon_results['out_wqparams'][-1]


    # Calculate residence time [minutes]
    volume_m3 = hreact * areact
    avg_flow = float(np.mean(inputs.flow))  # m³/h
    theta = (volume_m3 / avg_flow) * 60.0  # convert hours to minutes

    return {
        "bromate_out": float(ozon_out.bromate),
        "AOC_out": float(ozon_out.aoc),
        "Ecoli_out": float(ozon_out.ecoli),
        "theta": theta
    }


# ============================================================================
# Economic Calculations
# ============================================================================

def capital_recovery_factor(r_real: float, n: int) -> float:
    """
    Calculate Capital Recovery Factor for CAPEX annualization.

    CRF converts a present value to equivalent annual cost over n years
    at real interest rate r_real.

    Args:
        r_real: Real interest rate (adjusted for inflation)
        n: Project lifetime [years]

    Returns:
        Capital recovery factor [-]
    """
    return (r_real * (1 + r_real) ** n) / ((1 + r_real) ** n - 1)


def compute_energy_cost(
        ozone_dosed: float,
        flow_m3_h: float,
        params: Params
) -> Tuple[float, float, float]:
    """
    Calculate annual energy cost for ozone generation.

    Args:
        ozone_dosed: Ozone dose [mg/L]
        flow_m3_h: Average flow rate [m³/h]
        params: Energy cost parameters

    Returns:
        Tuple of (kg_per_h, kwh_per_h, energy_cost_year) [€/year]
    """
    # Calculate ozone mass flow rate [kg/h]
    kg_per_h = ozone_dosed * flow_m3_h / 1000.0

    # Calculate power consumption [kWh/h]
    kwh_per_h = kg_per_h * params.sec_kwh_per_kg_o3

    # Annualize cost [€/year]
    energy_cost_year = kwh_per_h * params.elec_eur_per_kwh * params.hours_per_year

    return kg_per_h, kwh_per_h, energy_cost_year


def compute_tank_cost(
        volume_m3: float,
        params: Params
) -> Tuple[float, float, float]:
    """
    Calculate annualized tank costs (CAPEX + OPEX).

    Uses empirical cost equations for construction and maintenance.

    Args:
        volume_m3: Total reactor volume [m³]
        params: Financial parameters for annualization

    Returns:
        Tuple of (crf, annualized_construction_cost, maintenance_cost) [€/year]
    """
    # Calculate real interest rate (inflation-adjusted)
    r_real = (1 + params.r_nom) / (1 + params.infl) - 1

    # Capital recovery factor
    crf = capital_recovery_factor(r_real, params.n_years)

    # Empirical cost equations
    constr_cost = crf * (2135.7342 * volume_m3 + 81493.501)
    maintenance_cost = 54.6748 * volume_m3 + 4786.2336

    return crf, constr_cost, maintenance_cost


def aspect_ratio(hreact: float, areact: float) -> float:
    """Reactor height-to-equivalent-diameter ratio (dimensionless)."""
    diameter = np.sqrt(4.0 * areact / np.pi)
    return hreact / max(diameter, 1e-12)


def compute_constraint_penalties(
        bromate_out: float,
        AOC_out: float,
        Ecoli_out: float,
        ecoli_in: float,
        theta: float,
        hreact: float,
        areact: float,
        limits: Limits,
        weights: Weights
) -> float:
    """
    Calculate soft-constraint penalty for violations.

    Implements big-M penalty method for constraint violations:
    - Bromate exceeding regulatory limit
    - AOC exceeding limit
    - E. coli log reduction below ECOLI_LOG_REDUCTION_MIN

    Args:
        bromate_out: Effluent bromate [µg/L]
        AOC_out: Effluent AOC [µg/L]
        Ecoli_out: Effluent E. coli [CFU/L]
        ecoli_in: Influent E. coli [CFU/L]
        limits: Constraint limits
        weights: Penalty weights

    Returns:
        Total penalty value (unitless, added to objective)
    """
    penalty = 0.0

    # Bromate constraint (upper bound, normalized)
    if bromate_out > limits.bromate_max:
        v_bro3 = (bromate_out - limits.bromate_max) / max(limits.bromate_max, 1e-6)
        penalty += weights.lam_BrO3 * v_bro3

    # AOC constraint (upper bound, normalized)
    if AOC_out > limits.aoc_max:
        v_aoc = (AOC_out - limits.aoc_max) / max(limits.aoc_max, 1e-6)
        penalty += weights.lam_AOC * v_aoc

    # E. coli log-reduction constraint (require >= ECOLI_LOG_REDUCTION_MIN)
    if ecoli_in > 0:
        lrv = np.log10(ecoli_in / max(Ecoli_out, 1e-12))
        if lrv < ECOLI_LOG_REDUCTION_MIN:
            v_ecoli = (ECOLI_LOG_REDUCTION_MIN - lrv) / ECOLI_LOG_REDUCTION_MIN
            penalty += weights.lam_Ecoli * v_ecoli

    # Residence time constraint (minimum)
    if theta < limits.theta_min:
        v_theta_min = (limits.theta_min - theta) / max(limits.theta_min, 1e-6)
        penalty += weights.lam_theta * v_theta_min

    # Residence time constraint (maximum)
    if theta > limits.theta_max:
        v_theta_max = (theta - limits.theta_max) / max(limits.theta_max, 1e-6)
        penalty += weights.lam_theta * v_theta_max

    # Reactor shape plausibility (aspect ratio = height / equivalent diameter)
    ar = aspect_ratio(hreact, areact)
    if ar < limits.aspect_ratio_min:
        v_ar_min = (limits.aspect_ratio_min - ar) / max(limits.aspect_ratio_min, 1e-6)
        penalty += weights.lam_aspect * v_ar_min
    if ar > limits.aspect_ratio_max:
        v_ar_max = (ar - limits.aspect_ratio_max) / max(limits.aspect_ratio_max, 1e-6)
        penalty += weights.lam_aspect * v_ar_max

    return penalty


# ============================================================================
# Optimization Objective Function
# ============================================================================

def objective_scalar(
        x: np.ndarray,
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates
) -> Tuple[float, Dict[str, float]]:
    """
    Scalarized objective function: minimize total annual cost + penalties.

    This is the function minimized by differential evolution. It:
    1. Unpacks decision variables
    2. Simulates the process
    3. Computes base costs (energy, tank)
    4. Adds constraint violation penalties

    Args:
        x: Decision vector [ozone_dosed, hreact, areact]
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states

    Returns:
        Tuple of (objective_value, cost_breakdown_dict)
    """
    # Unpack decision variables
    ozone_dosed = float(x[0])
    hreact = float(x[1])
    areact = float(x[2])

    # Derived volumes
    volume_m3 = hreact * areact

    # Simulate process
    sim = stimela_simulate(
        inputs, params, initials,
        ozone_dosed, hreact, areact
    )

    bromate_out = sim["bromate_out"]
    AOC_out = sim["AOC_out"]
    Ecoli_out = sim["Ecoli_out"]
    theta_out = sim["theta"]

    # Calculate average flow rate [m³/h]
    avg_flow = float(np.mean(inputs.flow))

    # ---- Cost Components ----

    # Energy cost [€/year]
    kg_per_h, kwh_per_h, energy_cost_year = compute_energy_cost(
        ozone_dosed, avg_flow, params
    )

    # Tank cost [€/year]
    crf, constr_cost, maintenance_cost = compute_tank_cost(volume_m3, params)
    tank_cost_year = constr_cost + maintenance_cost

    # Base objective (total annual cost)
    base = energy_cost_year + tank_cost_year

    # ---- Constraint Penalties ----
    ecoli_in = float(np.mean(inputs.ecoli))
    penalty = compute_constraint_penalties(
        bromate_out, AOC_out, Ecoli_out, ecoli_in, theta_out,
        hreact, areact, limits, weights
    )

    # Total objective
    objective_value = base + penalty

    # Detailed cost breakdown
    cost_breakdown = {
        "crf": crf,
        "constr_cost_year": constr_cost,
        "maintenance_cost_year": maintenance_cost,
        "tank_cost_year": tank_cost_year,
        "ozone_kg_per_h": kg_per_h,
        "kwh_per_h": kwh_per_h,
        "energy_cost_year": energy_cost_year,
        "bromate_out": bromate_out,
        "AOC_out": AOC_out,
        "Ecoli_out": Ecoli_out,
        "penalty": penalty,
        "theta": theta_out,
    }

    return objective_value, cost_breakdown


# ============================================================================
# Optimization Solver
# ============================================================================

def solve(
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        seed: int = 42,
        maxiter: int = 60,
        popsize: int = 15,
        tol: float = 1e-3,
        workers: int = 1
) -> Dict:
    """
    Solve optimization problem using differential evolution.

    Minimizes total annual cost subject to water quality constraints
    by optimizing ozone dose and reactor geometry.

    Args:
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        seed: Random seed for reproducibility
        maxiter: Maximum number of DE iterations
        popsize: Population size for DE
        tol: Convergence tolerance
        workers: Number of parallel workers (1 = serial)

    Returns:
        Dictionary with optimization results, including:
        - success: optimization success flag
        - message: solver message
        - fun: optimal objective value
        - x_opt: optimal decision variables
        - outputs: effluent water quality
        - costs: detailed cost analysis
    """
    # Define decision variable bounds
    bounds = [
        (limits.ozone_dosed_min, limits.ozone_dosed_max),  # ozone dose [mg/L]
        (limits.hreact_min, limits.hreact_max),  # reactor height [m]
        (limits.areact_min, limits.areact_max),  # reactor area [m²]
    ]

    # Wrapper for objective function (DE expects single return value)
    def objective_wrapper(x: np.ndarray) -> float:
        obj_val, _ = objective_scalar(x, inputs, params, limits, weights, initials)
        return obj_val

    # Run differential evolution with a hard wall-clock limit
    t_start = time.perf_counter()

    def time_limit_callback(xk, convergence=0):
        return (time.perf_counter() - t_start) > TIME_LIMIT_S

    result = differential_evolution(
        objective_wrapper,
        bounds=bounds,
        strategy="best1bin",
        maxiter=maxiter,
        popsize=popsize,
        tol=tol,
        mutation=(0.5, 1.0),
        recombination=0.7,
        seed=seed,
        polish=True,
        disp=True,
        workers=workers,
        callback=time_limit_callback
    )

    # Unpack optimal solution
    x_opt = result.x
    ozone_dosed = float(x_opt[0])
    hreact = float(x_opt[1])
    areact = float(x_opt[2])

    # Derived volumes
    volume_m3 = hreact * areact

    # Re-evaluate objective to get cost breakdown
    obj_val, costs = objective_scalar(
        x_opt, inputs, params, limits, weights, initials
    )

    # Extract effluent quality
    bromate_out = costs["bromate_out"]
    AOC_out = costs["AOC_out"]
    Ecoli_out = costs["Ecoli_out"]
    theta_out = costs["theta"]

    # E.coli log10 reduction, log10(N0/N) (None when no influent E.coli)
    ecoli_in = float(np.mean(inputs.ecoli))
    ecoli_log_reduction = (
        round(float(np.log10(ecoli_in / max(Ecoli_out, 1e-12))), 3)
        if ecoli_in > 0 else None
    )

    # Calculate average flow and HRT
    avg_flow = float(np.mean(inputs.flow))
    hrt_minutes = (volume_m3 / max(avg_flow, 1e-12)) * 60.0

    # Reactor shape (equivalent circular diameter and aspect ratio)
    diameter_m = float(np.sqrt(4.0 * areact / np.pi))
    ar = aspect_ratio(hreact, areact)

    # Compile comprehensive results report
    report = {
        "success": bool(result.success),
        "message": str(result.message),
        "fun": round(float(result.fun), 2),
        "x_opt": {
            "ozonation_chemical_dose": round(ozone_dosed,3),
            "ozonation_height": round(hreact,2),
            "ozonation_area": round(areact,2),
        },
        "derived": {
            "volume_m3": round(volume_m3,2),
            "crf_used": round(costs["crf"], 3),
            "hrt_minutes": round(hrt_minutes,2),
            "diameter_m": round(diameter_m, 2),
            "aspect_ratio": round(ar, 2),
        },
        "inputs": {
            "average_flow_m3h": avg_flow,
            "average_UV254_in_1m": float(np.mean(inputs.uv254)),
            "average_bromide_in_mgL": float(np.mean(inputs.bromide)),
            "average_ecoli_in": float(np.mean(inputs.ecoli)),
        },
        "outputs": {
            "bromate_out_ugL": round(bromate_out,3),
            "AOC_out_ugL": round(AOC_out,3),
            "Ecoli_out": round(Ecoli_out,3),
            "ecoli_log_reduction": ecoli_log_reduction,
            "theta_out_min": round(theta_out, 1),
            "aspect_ratio": round(ar, 2),
        },
        "constraints": {
            "bromate_max_ugL": limits.bromate_max,
            "aoc_max_ugL": limits.aoc_max,
            "ecoli_log_reduction_min": ECOLI_LOG_REDUCTION_MIN,
            "theta_min_min": limits.theta_min,
            "theta_max_min": limits.theta_max,
            "aspect_ratio_min": limits.aspect_ratio_min,
            "aspect_ratio_max": limits.aspect_ratio_max,
        },
        "optimal variables": {
            "ozone_dosed_mgL": round(ozone_dosed,3),
            "hreact_m": round(hreact,2),
            "areact_m2": round(areact,2),
            "volume_m3": round(volume_m3,2)
        },
        "costs": {
            "ozone_kg_per_h": round(costs["ozone_kg_per_h"], 3),
            "kwh_per_h": round(costs["kwh_per_h"], 2),
            "energy_cost_eur_per_year": round(costs["energy_cost_year"], 1),
            "constr_cost_year": round(costs["constr_cost_year"], 1),
            "maintenance_cost_year": round(costs["maintenance_cost_year"], 1),
            "tank_cost_eur_per_year": round(costs["tank_cost_year"], 1),
            "total_cost_eur_per_year_excl_penalties": round(
                costs["energy_cost_year"] + costs["tank_cost_year"], 1
            ),
            "penalty_added_unitless": costs["penalty"],
            "obj_fun_value": round(obj_val, 1),
        }
    }

    return report


# ============================================================================
# Command-Line Interface
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Run ozonation optimization from JSON config or CSV"
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        required=True,
        help="Path to configuration JSON file"
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility"
    )
    parser.add_argument(
        "--maxiter",
        type=int,
        default=300,
        help="Maximum DE iterations"
    )
    parser.add_argument(
        "--popsize",
        type=int,
        default=30,
        help="DE population size"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of parallel workers"
    )
    parser.add_argument(
        "--out_json",
        type=str,
        default="outputs/ozonation_results.json",
        help="Path to output results JSON file"
    )
    parser.add_argument(
        "--meetee",
        type=str,
        default="True",
        choices=["True", "False"],
        help="Co-current (True) or counter-current (False) flow"
    )
    return parser


def parse_cli_args(argv=None) -> argparse.Namespace:
    """Parse CLI args for ozonation optimization."""
    return build_parser().parse_args(argv)


def run_cli(args: argparse.Namespace) -> Dict:
    """Run optimization from parsed CLI args and write output JSON."""

    from pystimela_optim import api as optim_api

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    algo = cfg.get("algorithm", {})
    # Keep historical behavior: config algorithm values take precedence.
    seed = algo.get("seed", args.seed)
    maxiter = algo.get("maxiter", args.maxiter)
    popsize = algo.get("popsize", args.popsize)
    workers = algo.get("workers", args.workers)
    tol = algo.get("tol", 1e-3)
    # Kept for full CLI compatibility, even though it is not used in solve().
    _meetee = args.meetee

    report = optim_api.optimize_ozonation(
        cfg,
        seed=seed,
        maxiter=maxiter,
        popsize=popsize,
        workers=workers,
        tol=tol,
    )

    # Save results
    with open(args.out_json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Results saved to {args.out_json}")
    return report


def main(argv=None):
    """CLI entry point."""
    args = parse_cli_args(argv)
    run_cli(args)


if __name__ == "__main__":
    main()
