import pandas as pd
import json
import argparse
import os
import sys


def _read_params_csv(path: str) -> pd.DataFrame:
    """Read a [parameters, units, value] CSV and validate its columns."""
    df = pd.read_csv(path, sep=None, engine='python')
    df.columns = df.columns.str.strip()  # remove trailing spaces

    expected_cols = ["parameters", "units", "value"]
    if list(df.columns) != expected_cols:
        print(f"❌ Error: Expected columns {expected_cols} in {path}, but found {list(df.columns)}")
        sys.exit(1)
    return df


def prepare_wq_config(in_csv: str, out_json: str, flow_csv: str):
    """
    Reads the flow CSV and the water quality CSV, each with exact columns:
    [parameters, units, value]
    and writes a nested JSON with structure:

    {
        "WQ_parameters": {
            "flow": {"units": "m3/h", "value": 92},
            "temperature": {"units": "C", "value": 17},
            ...
        }
    }

    The flow value lives in its own CSV (flow_csv) and is merged in first so
    downstream scripts keep reading it from WQ_parameters["flow"] as before.
    """

    # --- Read CSVs (flow first so it leads the merged parameters) ---
    flow_df = _read_params_csv(flow_csv)
    df = _read_params_csv(in_csv)
    combined = pd.concat([flow_df, df], ignore_index=True)

    # --- Build dictionary ---
    wq_dict = {
        "WQ_parameters": {
            str(row["parameters"]).strip(): {
                "units": str(row["units"]).strip(),
                "value": float(row["value"])
            }
            for _, row in combined.iterrows()
        }
    }

    # --- Write JSON ---
    os.makedirs(os.path.dirname(out_json) or ".", exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(wq_dict, f, indent=2, ensure_ascii=False)

    print(f"✅ Water Quality JSON saved to: {out_json}")


def main(argv=None) -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="Prepare JSON WQ config from CSV")
    parser.add_argument("--in_csv", type=str, default="./inputs/wq_params.csv",
                        help="Path to WQ parameters CSV file")
    parser.add_argument("--flow_csv", type=str, default="inputs/django_flow.csv",
                        help="Path to flow CSV file")
    parser.add_argument("--out_json", type=str, default="configs/in_wq_params.json",
                        help="Output JSON file path")

    args = parser.parse_args(argv)
    prepare_wq_config(args.in_csv, args.out_json, args.flow_csv)


if __name__ == "__main__":
    main()
