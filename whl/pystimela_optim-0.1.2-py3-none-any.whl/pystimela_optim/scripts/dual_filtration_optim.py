from __future__ import annotations

"""
Dual Media Filtration Process Optimization

This module optimizes water treatment dual-media filtration processes using
differential evolution. It minimizes total annual costs (construction, maintenance,
materials, filter media) subject to water quality and operational constraints
(TSS, head loss, accumulated solids for both layers).

Key Components:
- Process simulation via PyStimela
- Multi-objective scalarization with penalty functions
- Economic evaluation (CAPEX/OPEX)
- Differential evolution optimization
- Backwash schedule management
"""

import json
import time
import argparse
from importlib import import_module
from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
from scipy.optimize import differential_evolution

datatypes = None
dwtmodels = None

# Hard wall-clock limit for the optimizer [s]. The DE callback stops the search
# once exceeded; the best solution found so far is returned.
TIME_LIMIT_S = 300


def _require_pystimela() -> None:
    """Load pystimela lazily and raise a clear runtime dependency error."""
    global datatypes, dwtmodels
    if datatypes is not None and dwtmodels is not None:
        return

    try:
        datatypes = import_module("pystimela.datatypes")
        dwtmodels = import_module("pystimela.dwtmodels")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "The 'pystimela' package is required to run optimization. "
            "Install pystimela to execute this command."
        ) from exc


# ============================================================================
# Configuration Dataclasses
# ============================================================================

@dataclass
class Limits:
    """
    Process limits for regulatory/operational bounds.

    Control variable bounds define the search space for optimization.
    Constraint bounds define feasibility requirements for the solution.
    """
    # Control variable bounds (surface area - common to both layers)
    surf_min_m2: float = 1.0  # [m²] minimum filter surface area
    surf_max_m2: float = 100.0  # [m²] maximum filter surface area

    # Upper bed (sand) bounds
    lbed1_min_m: float = 0.06  # [m] minimum upper bed height
    lbed1_max_m: float = 6.0  # [m] maximum upper bed height
    diam1_min_mm: float = 0.06  # [mm] minimum upper grain size
    diam1_max_mm: float = 6.0  # [mm] maximum upper grain size

    # Lower bed (anthracite) bounds
    lbed2_min_m: float = 0.06  # [m] minimum lower bed height
    lbed2_max_m: float = 6.0  # [m] maximum lower bed height
    diam2_min_mm: float = 0.06  # [mm] minimum lower grain size
    diam2_max_mm: float = 6.0  # [mm] maximum lower grain size

    # Constraint bounds (effluent quality and operational requirements)
    headloss_max_m: float = 2.0  # [m] maximum total head loss (both layers)
    tss_out_max_mgL: float = 1.0  # [mg/L] maximum effluent TSS
    accum1_max_kgm3: float = 5e5  # [kg/m³] maximum accumulated solids (upper layer)
    accum2_max_kgm3: float = 5e5  # [kg/m³] maximum accumulated solids (lower layer)

    # ADD these 2 lines:
    theta_min: float = 5.0  # [min] minimum residence time
    theta_max: float = 60.0  # [min] maximum residence time


@dataclass
class Weights:
    """
    Penalty weights for constraint violations in scalarized objective.

    These multipliers convert constraint violations into cost penalties,
    implementing a soft-constraint approach (big-M method).
    """
    lam_TSS: float = 2e5  # penalty weight for TSS violations
    lam_HL: float = 2e5  # penalty weight for head loss violations
    lam_ACC1: float = 1e5  # penalty weight for upper layer accumulated solids violations
    lam_ACC2: float = 1e5  # penalty weight for lower layer accumulated solids violations

    # ADD this line:
    lam_theta: float = 1e5  # penalty weight for residence time violations


@dataclass
class InitialStates:
    """
    Initial conditions for dual-media filtration unit process.

    These values represent the starting state of the filter,
    particularly the suspended solids and accumulated solids in each layer.
    """
    # Upper layer (sand)
    suspended_solids_upper_init: float = 0.0  # [kg/m³]
    accumulation_upper_init: float = 0.0  # [kg/m³]

    # Lower layer (anthracite)
    suspended_solids_lower_init: float = 0.0  # [kg/m³]
    accumulation_lower_init: float = 0.0  # [kg/m³]


@dataclass
class Params:
    """
    Process model parameters for dual-media filtration.

    Includes:
    - Physical parameters (porosity, density, water level)
    - Kinetic parameters (filtration resistance, clogging constants)
    - Economic parameters (costs, financial factors)
    - Reactor configuration (number of cells per layer)
    """
    # Common physical parameters
    lwater: float = 1.0  # [m] water level above filter bed
    rhod: float = 30.0  # [kg/m³] density of deposited solids

    # Upper bed (sand) kinetic parameters
    filporo1: float = 40.0  # [%] filter porosity (upper layer)
    lambda01: float = 0.003  # [1/m] filtration resistance parameter (upper layer)
    n1: float = 20.0  # clogging constant (upper layer)
    numcel1: int = 6  # number of discretization cells (upper layer)

    # Lower bed (anthracite) kinetic parameters
    filporo2: float = 38.0  # [%] filter porosity (lower layer)
    lambda02: float = 0.03  # [1/m] filtration resistance parameter (lower layer)
    n2: float = 3.0  # clogging constant (lower layer)
    numcel2: int = 6  # number of discretization cells (lower layer)

    # Financial parameters for CAPEX annualization
    n_years: int = 40  # project lifetime [years]
    r_nom: float = 0.05  # nominal interest rate (Netherlands: 5%, Greece: 7%)
    infl: float = 0.031  # inflation rate (Netherlands: 3.1%, Greece: 3.6%)

    # Filter media costs
    sand_filter_cost: float = 80.0  # [€/t] cost per ton of sand
    coal_filter_cost: float = 232.0  # [€/t] cost per ton of anthracite


# ============================================================================
# Water Quality Input Handling
# ============================================================================

class QualityInputs:
    """
    Time-series water quality parameters for dual filtration simulation.

    Constructs time-series arrays from CSV file or JSON configuration,
    representing inlet water characteristics over the simulation period.
    """

    COLUMNS = [
        "timestamp", "flow", "temperature", "suspended_solids"
    ]

    def __init__(self, timestamps: List[float], **attrs):
        """
        Initialize with timestamps and water quality attributes.

        Args:
            timestamps: List of time points [s]
            **attrs: Water quality parameters as numpy arrays
        """
        self.timestamps = timestamps
        self.__dict__.update(attrs)

    @classmethod
    def from_json(cls, inputs_dict: Dict) -> "QualityInputs":
        """
        Build QualityInputs from JSON-style configuration dictionary.

        Args:
            inputs_dict: Configuration with timeframe, timestep, and wq_parameters

        Returns:
            QualityInputs instance with constant time-series
        """
        timestamps = inputs_dict["timestamps"]
        n_steps = len(timestamps)

        wq_params = inputs_dict["wq_parameters"]

        def get_val(key: str) -> float:
            """Extract value from wq_parameters dict, return NaN if missing."""
            return float(wq_params[key]["value"]) if key in wq_params else np.nan

        # Create constant time-series arrays for each parameter
        return cls(
            timestamps=timestamps,
            flow=np.full(n_steps, get_val("flow")),
            temperature=np.full(n_steps, get_val("temperature")),
            suspended_solids=np.full(n_steps, get_val("suspended_solids"))
        )

    def to_wq_list(self) -> List[datatypes.WaterQualityParams]:
        """
        Convert to PyStimela WaterQualityParams list.

        Returns:
            List of WaterQualityParams objects for each timestep
        """
        fields = [c for c in self.COLUMNS if c != "timestamp"]
        n = len(self.timestamps)
        wq_list = []

        for i in range(n):
            kwargs = {name: float(getattr(self, name)[i]) for name in fields}
            wq = datatypes.WaterQualityParams(timestamp=self.timestamps[i], **kwargs)
            wq_list.append(wq)

        return wq_list


# ============================================================================
# Backwash Schedule Generation
# ============================================================================

def generate_backwash_events(timestamps: List[float], freq_h: float) -> List[bool]:
    """
    Generate backwash event schedule based on fixed time frequency.

    Args:
        timestamps: List of simulation time points [s]
        freq_h: Backwash frequency [hours] (0 = no backwash)

    Returns:
        List of boolean flags indicating backwash events at each timestep
    """
    events = [False] * len(timestamps)

    if freq_h > 0:
        # Convert timestamps from seconds to hours
        times_h = np.array(timestamps) / 3600.0
        last_bw = 0.0

        for i, t in enumerate(times_h):
            if t - last_bw >= freq_h:
                events[i] = True
                last_bw = t

    return events


# ============================================================================
# Process Simulation
# ============================================================================

def stimela_simulate_dual(
        inputs: QualityInputs,
        params: Params,
        initials: InitialStates,
        surf_m2: float,
        lbed1_m: float,
        lbed2_m: float,
        diam1_mm: float,
        diam2_mm: float,
        backwash_events: List[bool],
) -> Dict[str, float]:
    """
    Simulate dual-media filtration process using PyStimela.

    This wrapper orchestrates the dual-layer filtration simulation with backwash events.

    Args:
        inputs: Time-series water quality parameters
        params: Process model parameters
        initials: Initial state conditions
        surf_m2: Filter surface area [m²]
        lbed1_m: Upper bed height (sand depth) [m]
        lbed2_m: Lower bed height (anthracite depth) [m]
        diam1_mm: Upper grain size [mm]
        diam2_mm: Lower grain size [mm]
        backwash_events: Boolean list indicating backwash at each timestep

    Returns:
        Dictionary with dual-layer filtration performance metrics:
        - TSS_out_mgL: effluent total suspended solids [mg/L]
        - Head_loss_upper_m: head loss across upper layer [m]
        - Head_loss_lower_m: head loss across lower layer [m]
        - Accum_solids_upper_kgm3: accumulated solids in upper layer [kg/m³]
        - Accum_solids_lower_kgm3: accumulated solids in lower layer [kg/m³]
    """
    _require_pystimela()
    timestamps = inputs.timestamps

    # ---- Dual Filtration Parameters ----
    filt_params = datatypes.DualFiltrationParams(
        surf=surf_m2,
        lwater=params.lwater,
        lbed1=lbed1_m,
        lbed2=lbed2_m,
        diam1=diam1_mm,
        diam2=diam2_mm,
        filporo1=params.filporo1,
        filporo2=params.filporo2,
        rhod=params.rhod,
        lambda01=params.lambda01,
        lambda02=params.lambda02,
        n1=params.n1,
        n2=params.n2,
        numcel1=params.numcel1,
        numcel2=params.numcel2,
    )

    # Prepare input water quality
    in_wq_list = inputs.to_wq_list()
    in_wq_params = datatypes.ListWaterQualityParams(
        timestamps=timestamps,
        wqparams=in_wq_list
    )

    # Initialize dual filtration state in all compartments
    numcel1 = int(filt_params.numcel1)
    numcel2 = int(filt_params.numcel2)


    suspended_solids_upper = [initials.suspended_solids_upper_init] * numcel1
    accumulation_upper = [initials.accumulation_upper_init] * numcel1
    suspended_solids_lower = [initials.suspended_solids_lower_init] * numcel2
    accumulation_lower = [initials.accumulation_lower_init] * numcel2

    filt_init_state = datatypes.DualFiltrationState(
        suspended_solids_upper=suspended_solids_upper,
        init_accumulation_upper=accumulation_upper,
        suspended_solids_lower=suspended_solids_lower,
        init_accumulation_lower=accumulation_lower,
    )

    # Prepare backwash schedule
    backwash_schedule = datatypes.BackWashData(
        timestamps=timestamps,
        events=backwash_events
    )

    # Run dual filtration simulation
    filt_process = dwtmodels.DualFiltration(params=filt_params)
    filt_results = filt_process.simulate(
        t_eval=timestamps,
        init_state=filt_init_state,
        wq_params=in_wq_params,
        bw=backwash_schedule
    )

    # Extract effluent TSS (final timestep)
    tss_out = filt_results['out_wqparams'][-1].suspended_solids

    # Extract head loss (final timestep, last cell of each layer)
    headloss_upper = float(filt_results["flowres_u"][-1, -1])
    headloss_lower = float(filt_results["flowres_l"][-1, -1])

    # Extract accumulated solids (final timestep, sum over all cells per layer)
    sysout = filt_results["sysout"]
    accum_upper_last = sysout[-1, numcel1:(2 * numcel1)]
    accum_lower_last = sysout[-1, (2 * numcel1 + numcel2):]
    accum_upper_total = float(np.sum(accum_upper_last))
    accum_lower_total = float(np.sum(accum_lower_last))

    total_volume_m3 = surf_m2 * (lbed1_m + lbed2_m)
    avg_flow = float(np.mean(inputs.flow))  # m³/h
    theta = (total_volume_m3 / avg_flow) * 60.0

    return {
        "TSS_out_mgL": float(tss_out),
        "Head_loss_upper_m": headloss_upper,
        "Head_loss_lower_m": headloss_lower,
        "Accum_solids_upper_kgm3": accum_upper_total,
        "Accum_solids_lower_kgm3": accum_lower_total,
        "theta":theta
    }


# ============================================================================
# Economic Calculations
# ============================================================================

def capital_recovery_factor(r_real: float, n: int) -> float:
    """
    Calculate Capital Recovery Factor for CAPEX annualization.

    CRF converts a present value to equivalent annual cost over n years
    at real interest rate r_real.

    Args:
        r_real: Real interest rate (adjusted for inflation)
        n: Project lifetime [years]

    Returns:
        Capital recovery factor [-]
    """
    return (r_real * (1 + r_real) ** n) / ((1 + r_real) ** n - 1)


def compute_construction_cost(surf_m2: float, crf: float) -> float:
    """
    Calculate annualized construction cost using empirical equation.

    Args:
        surf_m2: Filter surface area [m²]
        crf: Capital recovery factor

    Returns:
        Annualized construction cost [€/year]
    """
    return crf * (-56.39 * surf_m2 ** 2 + 30558.186 * surf_m2 + 268522.65)


def compute_maintenance_cost(surf_m2: float) -> float:
    """
    Calculate annual maintenance cost using empirical equation.

    Args:
        surf_m2: Filter surface area [m²]

    Returns:
        Annual maintenance cost [€/year]
    """
    return -1.2336 * surf_m2 ** 2 + 621.872 * surf_m2 + 7752.087


def compute_materials_cost(surf_m2: float) -> float:
    """
    Calculate annual materials cost using empirical equation.

    Args:
        surf_m2: Filter surface area [m²]

    Returns:
        Annual materials cost [€/year]
    """
    return 36.9669 * surf_m2


def compute_filter_media_cost(
        surf_m2: float,
        lbed1_m: float,
        lbed2_m: float,
        diam1_mm: float,
        diam2_mm: float,
        params: Params,
        crf_10: float
) -> Tuple[float, float, float]:
    """
    Calculate annualized filter media replacement cost for both layers.

    Media is replaced every 10 years, so uses a separate CRF.

    Args:
        surf_m2: Filter surface area [m²]
        lbed1_m: Upper bed height [m]
        lbed2_m: Lower bed height [m]
        diam1_mm: Upper grain size [mm]
        diam2_mm: Lower grain size [mm]
        params: Process parameters with media costs
        crf_10: Capital recovery factor for 10-year period

    Returns:
        Tuple of (media_cost_upper_eur/year, media_cost_lower_eur/year, total_eur/year)
    """
    # Upper layer (sand)
    V_upper_m3 = surf_m2 * lbed1_m
    density_grain1 = 333 * diam1_mm + 1300  # Sand [kg/m³]
    mass_upper = density_grain1 * V_upper_m3 / 1000  # [tonnes]
    cost_upper = crf_10 * params.sand_filter_cost * mass_upper

    # Lower layer (anthracite)
    V_lower_m3 = surf_m2 * lbed2_m
    density_grain2 = 150 * diam2_mm + 675  # Anthracite [kg/m³]
    mass_lower = density_grain2 * V_lower_m3 / 1000  # [tonnes]
    cost_lower = crf_10 * params.coal_filter_cost * mass_lower

    return cost_upper, cost_lower, cost_upper + cost_lower


def compute_constraint_penalties(
        TSS_out: float,
        Head_loss_upper: float,
        Head_loss_lower: float,
        Accum_solids_upper: float,
        Accum_solids_lower: float,
        theta: float,
        limits: Limits,
        weights: Weights
) -> float:
    """
    Calculate soft-constraint penalty for violations.

    Implements big-M penalty method for constraint violations:
    - TSS exceeding tss_out_max_mgL
    - Total head loss exceeding headloss_max_m
    - Accumulated solids exceeding accum1_max_kgm3 (upper) or accum2_max_kgm3 (lower)

    Args:
        TSS_out: Effluent TSS [mg/L]
        Head_loss_upper: Head loss across upper layer [m]
        Head_loss_lower: Head loss across lower layer [m]
        Accum_solids_upper: Accumulated solids in upper layer [kg/m³]
        Accum_solids_lower: Accumulated solids in lower layer [kg/m³]
        limits: Constraint limits
        weights: Penalty weights

    Returns:
        Total penalty value (unitless, added to objective)
    """
    penalty = 0.0

    # TSS constraint (upper bound, normalized)
    v_tss = max(0.0, (TSS_out - limits.tss_out_max_mgL) / max(limits.tss_out_max_mgL, 1e-6))
    penalty += weights.lam_TSS * v_tss

    # Head loss constraint: penalize each layer where flow_res < 0 (friction exceeds driving head)
    if Head_loss_upper < 0:
        penalty += weights.lam_HL * abs(Head_loss_upper) / max(limits.headloss_max_m, 1e-6)
    if Head_loss_lower < 0:
        penalty += weights.lam_HL * abs(Head_loss_lower) / max(limits.headloss_max_m, 1e-6)

    # Accumulated solids constraints (per layer, normalized)
    v_acc1 = max(0.0, (Accum_solids_upper - limits.accum1_max_kgm3) / max(limits.accum1_max_kgm3, 1e-6))
    penalty += weights.lam_ACC1 * v_acc1

    v_acc2 = max(0.0, (Accum_solids_lower - limits.accum2_max_kgm3) / max(limits.accum2_max_kgm3, 1e-6))
    penalty += weights.lam_ACC2 * v_acc2

    if theta < limits.theta_min:
        v_theta_min = (limits.theta_min - theta) / max(limits.theta_min, 1e-6)
        penalty += weights.lam_theta * v_theta_min

        # Residence time constraint (maximum)
    if theta > limits.theta_max:
        v_theta_max = (theta - limits.theta_max) / max(limits.theta_max, 1e-6)
        penalty += weights.lam_theta * v_theta_max

    return penalty


# ============================================================================
# Optimization Objective Function
# ============================================================================

def objective_scalar(
        x: np.ndarray,
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        backwash_events: List[bool]
) -> Tuple[float, Dict[str, float]]:
    """
    Scalarized objective function: minimize total annual cost + penalties.

    This is the function minimized by differential evolution. It:
    1. Unpacks decision variables
    2. Simulates the dual filtration process
    3. Computes base costs (construction, maintenance, materials, filter media)
    4. Adds constraint violation penalties

    Args:
        x: Decision vector [surf_m2, lbed1_m, lbed2_m, diam1_mm, diam2_mm]
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        backwash_events: Backwash schedule

    Returns:
        Tuple of (objective_value, cost_breakdown_dict)
    """
    # Unpack decision variables
    surf_m2 = float(x[0])
    lbed1_m = float(x[1])
    lbed2_m = float(x[2])
    diam1_mm = float(x[3])
    diam2_mm = float(x[4])

    # Simulate process
    sim = stimela_simulate_dual(
        inputs, params, initials,
        surf_m2, lbed1_m, lbed2_m, diam1_mm, diam2_mm,
        backwash_events
    )

    TSS_out = sim["TSS_out_mgL"]
    Head_loss_upper = sim["Head_loss_upper_m"]
    Head_loss_lower = sim["Head_loss_lower_m"]
    Accum_solids_upper = sim["Accum_solids_upper_kgm3"]
    Accum_solids_lower = sim["Accum_solids_lower_kgm3"]
    theta = sim["theta"]

    # ---- Cost Components ----

    # Calculate real interest rate and CRFs
    r_real = (1 + params.r_nom) / (1 + params.infl) - 1
    crf = capital_recovery_factor(r_real, params.n_years)
    crf_10 = capital_recovery_factor(r_real, 10)

    # Construction cost [€/year]
    const_cost = compute_construction_cost(surf_m2, crf)

    # Maintenance cost [€/year]
    maint_cost = compute_maintenance_cost(surf_m2)

    # Materials cost [€/year]
    materials_cost = compute_materials_cost(surf_m2)

    # Filter media cost [€/year]
    media_cost_upper, media_cost_lower, media_cost_total = compute_filter_media_cost(
        surf_m2, lbed1_m, lbed2_m, diam1_mm, diam2_mm, params, crf_10
    )

    # Base objective (total annual cost)
    base = const_cost + maint_cost + materials_cost + media_cost_total

    # ---- Constraint Penalties ----
    penalty = compute_constraint_penalties(
        TSS_out, Head_loss_upper, Head_loss_lower,
        Accum_solids_upper, Accum_solids_lower, theta,
        limits, weights
    )

    # Total objective
    objective_value = base + penalty

    # Detailed cost breakdown
    cost_breakdown = {
        "r_nom": params.r_nom,
        "infl": params.infl,
        "r_real": r_real,
        "CRF_n": crf,
        "CRF_10": crf_10,
        "construction_cost_eur_per_year": const_cost,
        "maintenance_cost_eur_per_year": maint_cost,
        "materials_cost_eur_per_year": materials_cost,
        "media_cost_upper_eur_per_year": media_cost_upper,
        "media_cost_lower_eur_per_year": media_cost_lower,
        "media_cost_total_eur_per_year": media_cost_total,
        "TSS_out_mgL": TSS_out,
        "Head_loss_upper_m": Head_loss_upper,
        "Head_loss_lower_m": Head_loss_lower,
        "Head_loss_total_m": Head_loss_upper + Head_loss_lower,
        "Accum_solids_upper_kgm3": Accum_solids_upper,
        "Accum_solids_lower_kgm3": Accum_solids_lower,
        "penalty": penalty,
        "theta":theta
    }

    return objective_value, cost_breakdown


# ============================================================================
# Optimization Solver
# ============================================================================

def solve(
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        backwash_events: List[bool],
        seed: int = 42,
        maxiter: int = 60,
        popsize: int = 15,
        tol: float = 1e-3,
        workers: int = 1
) -> Dict:
    """
    Solve optimization problem using differential evolution.

    Minimizes total annual cost subject to water quality and operational
    constraints by optimizing filter surface area, bed heights, and grain sizes
    for both layers.

    Args:
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        backwash_events: Backwash schedule
        seed: Random seed for reproducibility
        maxiter: Maximum number of DE iterations
        popsize: Population size for DE
        tol: Convergence tolerance
        workers: Number of parallel workers (1 = serial)

    Returns:
        Dictionary with optimization results, including:
        - success: optimization success flag
        - message: solver message
        - fun: optimal objective value
        - x_opt: optimal decision variables
        - outputs: effluent water quality and layer performance
        - economics: detailed cost analysis
    """
    # Define decision variable bounds
    bounds = [
        (limits.surf_min_m2, limits.surf_max_m2),  # surface [m²]
        (limits.lbed1_min_m, limits.lbed1_max_m),  # upper bed height [m]
        (limits.lbed2_min_m, limits.lbed2_max_m),  # lower bed height [m]
        (limits.diam1_min_mm, limits.diam1_max_mm),  # upper grain size [mm]
        (limits.diam2_min_mm, limits.diam2_max_mm),  # lower grain size [mm]
    ]

    # Wrapper for objective function (DE expects single return value)
    def objective_wrapper(x: np.ndarray) -> float:
        obj_val, _ = objective_scalar(
            x, inputs, params, limits, weights, initials, backwash_events
        )
        return obj_val
    # Run differential evolution with a hard wall-clock limit
    t_start = time.perf_counter()

    def time_limit_callback(xk, convergence=0):
        return (time.perf_counter() - t_start) > TIME_LIMIT_S

    # Run differential evolution
    result = differential_evolution(
        objective_wrapper,
        bounds=bounds,
        strategy="best1bin",
        maxiter=maxiter,
        popsize=popsize,
        tol=tol,
        mutation=(0.5, 1.0),
        recombination=0.7,
        seed=seed,
        polish=True,
        disp=True,
        workers=workers,
        callback=time_limit_callback
    )

    # Unpack optimal solution
    x_opt = result.x
    surf_m2 = float(x_opt[0])
    lbed1_m = float(x_opt[1])
    lbed2_m = float(x_opt[2])
    diam1_mm = float(x_opt[3])
    diam2_mm = float(x_opt[4])

    # Derived volumes
    V_upper_m3 = surf_m2 * lbed1_m
    V_lower_m3 = surf_m2 * lbed2_m
    V_filter_m3 = V_upper_m3 + V_lower_m3

    # Re-evaluate objective to get detailed cost breakdown
    obj_val, costs = objective_scalar(
        x_opt, inputs, params, limits, weights, initials, backwash_events
    )

    # Separate simulation outputs from economics
    simulation_outputs = {
        "TSS_out_mgL": costs["TSS_out_mgL"],
        "Head_loss_upper_m": costs["Head_loss_upper_m"],
        "Head_loss_lower_m": costs["Head_loss_lower_m"],
        "Head_loss_total_m": costs["Head_loss_total_m"],
        "Accum_solids_upper_kgm3": costs["Accum_solids_upper_kgm3"],
        "Accum_solids_lower_kgm3": costs["Accum_solids_lower_kgm3"],
        "theta_min": costs["theta"],
    }

    economics = {
        "r_nom": costs["r_nom"],
        "infl": costs["infl"],
        "r_real": costs["r_real"],
        "CRF_n": costs["CRF_n"],
        "CRF_10": costs["CRF_10"],
        "construction_cost_eur_per_year": round(costs["construction_cost_eur_per_year"], 1),
        "maintenance_cost_eur_per_year": round(costs["maintenance_cost_eur_per_year"], 1),
        "materials_cost_eur_per_year": round(costs["materials_cost_eur_per_year"], 1),
        "media_cost_upper_eur_per_year": round(costs["media_cost_upper_eur_per_year"], 1),
        "media_cost_lower_eur_per_year": round(costs["media_cost_lower_eur_per_year"], 1),
        "media_cost_total_eur_per_year": round(costs["media_cost_total_eur_per_year"], 1),
        "penalty_added_unitless": costs["penalty"],
        "obj_fun_value": round(obj_val, 1),
    }

    # Compile comprehensive results report
    report = {
        "success": bool(result.success),
        "message": str(result.message),
        "fun": round(float(result.fun), 2),
        "x_opt": {
            "dual_filtration_surface": round(surf_m2,1),
            "dual_filtration_depth": round(lbed1_m,1),
            "dual_filtration_depth_b": round(lbed2_m,1),
            "dual_filtration_grain_size_a": round(diam1_mm,2),
            "dual_filtration_grain_size_b": round(diam2_mm,2)
        },
        "derived": {
            "V_upper_m3": round(V_upper_m3,2),
            "V_lower_m3": round(V_lower_m3,2),
            "V_filter_m3": round(V_filter_m3,2),
        },
        "inputs": {
            "flow_mean_m3h": float(np.mean(inputs.flow)),
            "TSS_in_mgL": float(np.mean(inputs.suspended_solids)),
        },
        "outputs": simulation_outputs,
        "constraints": {
            "tss_out_max_mgL": limits.tss_out_max_mgL,
            "headloss_max_m": limits.headloss_max_m,
            "accum1_max_kgm3": limits.accum1_max_kgm3,
            "accum2_max_kgm3": limits.accum2_max_kgm3,
            "lbed1_range_m": (limits.lbed1_min_m, limits.lbed1_max_m),
            "lbed2_range_m": (limits.lbed2_min_m, limits.lbed2_max_m),
            "diam1_range_mm": (limits.diam1_min_mm, limits.diam1_max_mm),
            "diam2_range_mm": (limits.diam2_min_mm, limits.diam2_max_mm),
            "theta_min": limits.theta_min,  # ADD THIS
            "theta_max": limits.theta_max  # ADD THIS
        },
        "economics": economics,
        "optimal variables": {
            "surf_m2": round(surf_m2,2),
            "lbed1_m": round(lbed1_m,2),
            "lbed2_m": round(lbed2_m,2),
            "diam1_mm": round(diam1_mm,2),
            "diam2_mm": round(diam2_mm,2),
            "V_filter_m3": round(V_filter_m3,2)
        }
    }

    return report


# ============================================================================
# Command-Line Interface
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Run dual filtration optimization from JSON config or CSV"
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to configuration JSON file"
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility"
    )
    parser.add_argument(
        "--maxiter",
        type=int,
        default=300,
        help="Maximum DE iterations"
    )
    parser.add_argument(
        "--popsize",
        type=int,
        default=30,
        help="DE population size"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of parallel workers"
    )
    parser.add_argument(
        "--out_json",
        type=str,
        default="outputs/dual_filtration_results.json",
        help="Path to output results JSON file"
    )
    parser.add_argument(
        "--bw_freq_h",
        type=float,
        default=0.0,
        help="Backwash frequency in hours (0 = no backwash)"
    )
    return parser


def parse_cli_args(argv=None) -> argparse.Namespace:
    """Parse CLI args for dual filtration optimization."""
    return build_parser().parse_args(argv)


def run_cli(args: argparse.Namespace) -> Dict:
    """Run optimization from parsed CLI args and write output JSON."""

    from pystimela_optim import api as optim_api

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    algo = cfg.get("algorithm", {})
    # Keep historical behavior: config algorithm/backwash values take precedence.
    seed = algo.get("seed", args.seed)
    maxiter = algo.get("maxiter", args.maxiter)
    popsize = algo.get("popsize", args.popsize)
    workers = algo.get("workers", args.workers)
    tol = algo.get("tol", 1e-3)
    bw_freq_h = cfg.get("backwash_freq_h", 0.0)

    report = optim_api.optimize_dual_filtration(
        cfg,
        seed=seed,
        maxiter=maxiter,
        popsize=popsize,
        workers=workers,
        tol=tol,
        bw_freq_h=bw_freq_h,
    )

    # Save results
    with open(args.out_json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Results saved to {args.out_json}")
    return report


def main(argv=None):
    """CLI entry point."""
    args = parse_cli_args(argv)
    run_cli(args)


if __name__ == "__main__":
    main()
