from __future__ import annotations

"""
Coagulation-Flocculation Process Optimization

This module optimizes water treatment coagulation-flocculation processes using
differential evolution. It minimizes total annual costs (chemical, construction,
maintenance, energy) subject to water quality constraints (pH, DOC, TSS).

Key Components:
- Process simulation via PyStimela
- Multi-objective scalarization with penalty functions
- Economic evaluation (CAPEX/OPEX)
- Differential evolution optimization
"""

import json
import argparse
from importlib import import_module
from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np
from scipy.optimize import differential_evolution

datatypes = None
dwtmodels = None


def _require_pystimela() -> None:
    """Load pystimela lazily and raise a clear runtime dependency error."""
    global datatypes, dwtmodels
    if datatypes is not None and dwtmodels is not None:
        return

    try:
        datatypes = import_module("pystimela.datatypes")
        dwtmodels = import_module("pystimela.dwtmodels")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "The 'pystimela' package is required to run optimization. "
            "Install pystimela to execute this command."
        ) from exc


# ============================================================================
# Configuration Dataclasses
# ============================================================================

@dataclass
class Limits:
    """
    Process limits for regulatory/operational bounds.

    Control variable bounds define the search space for optimization.
    Constraint bounds define feasibility requirements for the solution.
    """
    # Control variable bounds
    g10_coag_min: float = 100.0  # [1/s] minimum coagulation velocity gradient
    g10_floc_min: float = 10.0  # [1/s] minimum flocculation velocity gradient
    dose_min_mmol: float = 0.0001  # [mmol/L] minimum coagulant dose
    dose_max_mmol: float = 0.3  # [mmol/L] maximum coagulant dose
    V_coag_min: float = 1.0  # [m³] minimum coagulation volume
    V_coag_max: float = 15.0  # [m³] maximum coagulation volume
    length_floc_min_m: float = 0.5  # [m] minimum flocculation length
    length_floc_max_m: float = 6.0  # [m] maximum flocculation length
    surf_min_m2: float = 1.0  # [m²] minimum flocculation surface
    surf_max_m2: float = 20.0  # [m²] maximum flocculation surface

    # Constraint bounds (effluent quality requirements)
    tss_out_max: float = 30.0  # [mg/L] maximum total suspended solids
    g10_coag_max: float = 1000.0  # [1/s] maximum coagulation velocity gradient
    g10_floc_max: float = 80.0  # [1/s] maximum flocculation velocity gradient
    pH_min: float = 6.5  # [-] minimum effluent pH
    pH_max: float = 7.5  # [-] maximum effluent pH
    doc_out_max: float = 10.0  # [mg/L] maximum dissolved organic carbon

    # Per-stage TSS removal split: fraction of the required removal gap
    # (TSS_in - tss_out_max) assigned to the coagulation stage. Forces a
    # realistic dose because coagulation is the only dose-dependent TSS pathway.
    coag_removal_split: float = 0.30

    # NEW: Residence time constraints
    theta_coag_min: float = 1.0
    theta_coag_max: float = 30.0
    theta_floc_min: float = 10.0
    theta_floc_max: float = 60.0


@dataclass
class Weights:
    """
    Penalty weights for constraint violations in scalarized objective.

    These multipliers convert constraint violations into cost penalties,
    implementing a soft-constraint approach (big-M method).
    """
    lam_pH: float = 2e4  # penalty weight for pH violations
    lam_DOC: float = 2e4  # penalty weight for DOC violations
    lam_TSS: float = 2e4  # penalty weight for TSS violations
    lam_G: float = 5e3  # penalty weight for velocity gradient violations

    lam_theta_coag: float = 1e5  # penalty for coagulation residence time violations
    lam_theta_floc: float = 1e5  # penalty for flocculation residence time violations

    lam_split: float = 1e5  # penalty for coagulation under-removing its share of TSS

@dataclass
class InitialStates:
    """
    Initial conditions for water treatment unit processes.

    These values represent the starting state of the system,
    particularly the suspended solids already present in flocculation cells.
    """
    suspended_solids_initial_floc: float = 0.0  # [kg/m³]


@dataclass
class Params:
    """
    Process model parameters for coagulation and flocculation.

    Includes:
    - Kinetic parameters (adsorption, aggregation, breakup)
    - Economic parameters (chemical costs, financial factors, energy costs)
    - Reactor configuration (number of cells)
    """
    coagulant: str  # 'fecl3' or 'al2so43'

    # Coagulation kinetic parameters
    a1: float = 284.0  # DOC adsorption parameter
    a2: float = 74.2  # DOC adsorption parameter
    a3: float = 4.91  # DOC adsorption parameter
    # Argaman-Kaufman floc kinetics (low-end literature values), temperature-scaled:
    # ka = ka20 * 1.05^(T-20), kb = kb20_* * 1.03^(20-T)
    ka20: float = 3.68e-5  # floc aggregation constant at 20°C (both stages)
    kb20_coag: float = 7e-9  # floc breakup at 20°C, rapid-mix basin (small: flocs not yet grown)
    kb20_floc: float = 1.83e-7  # floc breakup at 20°C, flocculation reactor
    b: float = 0.147  # DOC adsorption constant
    k1: float = -0.075  # non-adsorbable DOC fraction parameter
    k2: float = 0.56  # non-adsorbable DOC fraction parameter

    # Flocculation kinetic parameters
    numcel: int = 25  # number of reactor compartments

    # Coagulant cost parameters - FeCl₃
    fecl3_mmol_to_mgL: float = 162.2  # molecular weight conversion
    fecl3_dilution_frac: float = 0.40  # active fraction in commercial product
    fecl3_chem_cost_per_kg: float = 0.535  # €/kg commercial product

    # Coagulant cost parameters - Al₂(SO₄)₃
    al2so43_mmol_to_mgL: float = 342.18  # molecular weight conversion
    al2so43_dilution_frac: float = 0.48  # active fraction in commercial product
    al2so43_chem_cost_per_kg: float = 0.35  # €/kg commercial product

    # Financial parameters for CAPEX annualization
    n_years: int = 40  # project lifetime [years]
    r_nom: float = 0.05  # nominal interest rate (Netherlands: 5%, Greece: 7%)
    infl: float = 0.031  # inflation rate (Netherlands: 3.1%, Greece: 3.6%)

    # Energy cost parameters
    mu: float = 0.001  # dynamic viscosity [N·s/m²]
    n_eff: float = 0.8  # mechanical efficiency [-]
    elec_price: float = 0.14  # electricity price [€/kWh]


# ============================================================================
# Water Quality Input Handling
# ============================================================================

class QualityInputs:
    """
    Time-series water quality parameters for process simulation.

    Constructs constant time-series arrays from JSON configuration,
    representing inlet water characteristics over the simulation period.
    """

    COLUMNS = [
        "timestamp", "flow", "temperature", "conductivity",
        "suspended_solids", "uv254", "ph", "doc", "mnumber"
    ]

    def __init__(self, timestamps: List[float], **attrs):
        """
        Initialize with timestamps and water quality attributes.

        Args:
            timestamps: List of time points [s]
            **attrs: Water quality parameters as numpy arrays
        """
        self.timestamps = timestamps
        self.__dict__.update(attrs)

    @classmethod
    def from_json(cls, inputs_dict: Dict) -> "QualityInputs":
        """
        Build QualityInputs from JSON-style configuration dictionary.

        Args:
            inputs_dict: Configuration with timeframe, timestep, and wq_parameters

        Returns:
            QualityInputs instance with constant time-series
        """
        timestamps = inputs_dict["timestamps"]
        n_steps = len(timestamps)

        wq_params = inputs_dict["wq_parameters"]

        def get_val(key: str) -> float:
            """Extract value from wq_parameters dict, return NaN if missing."""
            return float(wq_params[key]["value"]) if key in wq_params else np.nan

        # Create constant time-series arrays for each parameter
        return cls(
            timestamps=timestamps,
            flow=np.full(n_steps, get_val("flow")),
            temperature=np.full(n_steps, get_val("temperature")),
            conductivity=np.full(n_steps, get_val("conductivity")),
            suspended_solids=np.full(n_steps, get_val("suspended_solids")),
            uv254=np.full(n_steps, get_val("uv254")),
            ph=np.full(n_steps, get_val("ph")),
            doc=np.full(n_steps, get_val("doc")),
            mnumber=np.full(n_steps, get_val("mnumber"))
        )

    def to_wq_list(self) -> List[object]:
        """
        Convert to PyStimela WaterQualityParams list.

        Returns:
            List of WaterQualityParams objects for each timestep
        """
        _require_pystimela()
        fields = [c for c in self.COLUMNS if c != "timestamp"]
        n = len(self.timestamps)
        wq_list = []

        for i in range(n):
            kwargs = {name: float(getattr(self, name)[i]) for name in fields}
            wq = datatypes.WaterQualityParams(timestamp=self.timestamps[i], **kwargs)
            wq_list.append(wq)

        return wq_list


# ============================================================================
# Process Simulation
# ============================================================================

def stimela_simulate(
        inputs: QualityInputs,
        params: Params,
        initials: InitialStates,
        dose_mmol: float,
        g10_coag: float,
        V_coag_m3: float,
        g10_floc: float,
        length_m: float,
        surf_m2: float,
) -> Dict[str, float]:
    """
    Simulate coagulation-flocculation process using PyStimela.

    This wrapper orchestrates the full treatment sequence:
    1. Coagulation with chemical dosing
    2. Flocculation in multi-compartment reactor

    Args:
        inputs: Time-series water quality parameters
        params: Process model parameters
        initials: Initial state conditions
        dose_mmol: Coagulant dose [mmol/L]
        g10_coag: Coagulation velocity gradient [1/s]
        V_coag_m3: Coagulation tank volume [m³]
        g10_floc: Flocculation velocity gradient [1/s]
        length_m: Flocculation reactor length [m]
        surf_m2: Flocculation reactor surface area [m²]

    Returns:
        Dictionary with effluent water quality:
        - pH_out: effluent pH
        - DOC_out_mgL: dissolved organic carbon [mg/L]
        - TSS_out_mgL: total suspended solids [mg/L]
        - M-number: residual coagulant [mmol/L]
        - uv254: UV absorbance at 254nm [1/m]
        - conductivity: electrical conductivity [mS/m]
    """
    _require_pystimela()
    timestamps = inputs.timestamps

    # Temperature-dependent floc aggregation/breakup constants (per-stage kb)
    temp_C = float(np.mean(inputs.temperature))
    ka = params.ka20 * 1.05 ** (temp_C - 20.0)
    kb_coag = params.kb20_coag * 1.03 ** (20.0 - temp_C)
    kb_floc = params.kb20_floc * 1.03 ** (20.0 - temp_C)

    # ---- Coagulation Stage ----
    coag_params = datatypes.CoagulationParams(
        g10=g10_coag,
        a1=params.a1,
        a2=params.a2,
        a3=params.a3,
        ka=ka,
        kb=kb_coag,
        b=params.b,
        k1=params.k1,
        k2=params.k2,
        volume=V_coag_m3
    )

    # Set coagulant dose based on selected chemical
    al2so43_dose = 0.0
    fecl3_dose = 0.0
    if params.coagulant.lower() == "al2so43":
        al2so43_dose = float(dose_mmol)
    elif params.coagulant.lower() == "fecl3":
        fecl3_dose = float(dose_mmol)

    # Prepare input water quality
    in_wq_list = inputs.to_wq_list()
    in_wq_params = datatypes.ListWaterQualityParams(
        timestamps=inputs.timestamps,
        wqparams=in_wq_list
    )

    # Create dosage series (constant over time)
    coag_dosages = [
        datatypes.CoagulationDosage(al2so43=al2so43_dose, fecl3=fecl3_dose)
        for _ in timestamps
    ]

    # Run coagulation simulation
    coag_process = dwtmodels.Coagulation(params=coag_params)
    coag_results = coag_process.simulate(dosage=coag_dosages, in_wp=in_wq_params)

    # Post-coagulation TSS (the only dose-dependent TSS stage) for per-stage split
    TSS_post_coag = float(coag_results.wqparams[-1].suspended_solids)

    # ---- Flocculation Stage ----
    floc_params = datatypes.FlocculationParams(
        length=length_m,
        ka=ka,
        kb=kb_floc,
        g10=g10_floc,
        surf=surf_m2,
        numcel=params.numcel
    )

    # Initialize suspended solids state in all compartments
    suspended_solids = [initials.suspended_solids_initial_floc] * floc_params.numcel
    floc_init_state = datatypes.FlocculationState(suspended_solids=suspended_solids)

    # Run flocculation simulation
    floc_process = dwtmodels.Flocculation(params=floc_params)
    floc_results = floc_process.simulate(
        t_eval=timestamps,
        initial_state=floc_init_state,
        in_wp=coag_results
    )

    # Extract final effluent quality
    floc_out = floc_results['out_wqparams'][-1]

    # Calculate residence times [minutes]
    avg_flow = float(np.mean(inputs.flow))  # m³/h

    # Coagulation residence time
    theta_coag = (V_coag_m3 / avg_flow) * 60.0

    # Flocculation residence time
    V_floc_m3 = length_m * surf_m2
    theta_floc = (V_floc_m3 / avg_flow) * 60.0

    return {
        "pH_out": float(floc_out.ph),
        "DOC_out_mgL": float(floc_out.doc),
        "TSS_out_mgL": float(floc_out.suspended_solids),
        "TSS_post_coag_mgL": TSS_post_coag,
        "M-number": float(floc_out.mnumber),
        "uv254": float(floc_out.uv254),
        "conductivity": float(floc_out.conductivity),
        "theta_coag": theta_coag,  # NEW
        "theta_floc": theta_floc,  # New
    }


# ============================================================================
# Economic Calculations
# ============================================================================

def capital_recovery_factor(r_real: float, n: int) -> float:
    """
    Calculate Capital Recovery Factor for CAPEX annualization.

    CRF converts a present value to equivalent annual cost over n years
    at real interest rate r_real.

    Args:
        r_real: Real interest rate (adjusted for inflation)
        n: Project lifetime [years]

    Returns:
        Capital recovery factor [-]
    """
    return (r_real * (1 + r_real) ** n) / ((1 + r_real) ** n - 1)


def compute_coagulant_cost(
        dose_mmol: float,
        flow_m3_day: float,
        params: Params
) -> float:
    """
    Calculate annual coagulant chemical cost.

    Args:
        dose_mmol: Coagulant dose [mmol/L]
        flow_m3_day: Average flow rate [m³/day]
        params: Process parameters with coagulant properties

    Returns:
        Annual chemical cost [€/year]
    """
    # Select coagulant-specific parameters
    if params.coagulant.lower() == "fecl3":
        mmol_to_mgL = params.fecl3_mmol_to_mgL
        dilution_frac = params.fecl3_dilution_frac
        chem_cost_per_kg = params.fecl3_chem_cost_per_kg
    elif params.coagulant.lower() == "al2so43":
        mmol_to_mgL = params.al2so43_mmol_to_mgL
        dilution_frac = params.al2so43_dilution_frac
        chem_cost_per_kg = params.al2so43_chem_cost_per_kg
    else:
        return 0.0

    # Convert dose to mg/L
    mgL_dose = dose_mmol * mmol_to_mgL

    # Calculate daily pure chemical mass [kg/day]
    kg_day_pure = mgL_dose * flow_m3_day / 1000.0

    # Convert to commercial product mass (accounting for dilution)
    kg_day_commercial = kg_day_pure / dilution_frac

    # Annualize cost
    chem_cost_year = kg_day_commercial * chem_cost_per_kg * 365.0

    return chem_cost_year


def compute_tank_cost(
        volume_m3: float,
        params: Params
) -> Tuple[float, float, float]:
    """
    Calculate annualized tank costs (CAPEX + OPEX).

    Uses empirical cost equations for construction and maintenance.

    Args:
        volume_m3: Total reactor volume [m³]
        params: Financial parameters for annualization

    Returns:
        Tuple of (crf, annualized_construction_cost, maintenance_cost) [€/year]
    """
    # Calculate real interest rate (inflation-adjusted)
    r_real = (1 + params.r_nom) / (1 + params.infl) - 1

    # Capital recovery factor
    crf = capital_recovery_factor(r_real, params.n_years)

    # Empirical cost equations
    constr_cost = crf * (5198.61 * volume_m3 + 366512.7)
    maintenance_cost = 112.29 * volume_m3 + 11516.0

    return crf, constr_cost, maintenance_cost


def compute_energy_cost(
        g10_coag: float,
        V_coag_m3: float,
        g10_floc: float,
        V_floc_m3: float,
        params: Params
) -> Tuple[float, float, float]:
    """
    Calculate annual energy cost for mixing.

    Power dissipation: P = G² × μ × V / η_eff

    Args:
        g10_coag: Coagulation velocity gradient [1/s]
        V_coag_m3: Coagulation volume [m³]
        g10_floc: Flocculation velocity gradient [1/s]
        V_floc_m3: Flocculation volume [m³]
        params: Energy cost parameters

    Returns:
        Tuple of (energy_coag, energy_floc, total_energy_cost) [€/year]
    """
    hours_year = 24 * 365

    def g_to_power(G: float, V: float) -> float:
        """Convert velocity gradient to power dissipation [W]."""
        return (G ** 2) * params.mu * V / params.n_eff

    # Calculate power for each stage [W]
    P_coag = g_to_power(g10_coag, V_coag_m3)
    P_floc = g_to_power(g10_floc, V_floc_m3)

    # Convert to annual energy [kWh/year]
    energy_kWh_year_coag = (P_coag * hours_year) / 1000.0
    energy_kWh_year_floc = (P_floc * hours_year) / 1000.0
    energy_kWh_year_total = energy_kWh_year_coag + energy_kWh_year_floc

    # Calculate cost [€/year]
    energy_cost_year = energy_kWh_year_total * params.elec_price

    return energy_kWh_year_coag, energy_kWh_year_floc, energy_cost_year


def compute_constraint_penalties(
        pH_out: float,
        DOC_out: float,
        TSS_out: float,
        g10_coag: float,
        g10_floc: float,
        theta_coag: float,   # ADD
        theta_floc: float,   # ADD
        TSS_in: float,
        TSS_post_coag: float,
        limits: Limits,
        weights: Weights
) -> float:
    """
    Calculate soft-constraint penalty for violations.

    Implements big-M penalty method for constraint violations:
    - pH outside [pH_min, pH_max]
    - DOC exceeding doc_out_max
    - TSS exceeding tss_out_max
    - G10 exceeding velocity gradient limits

    Args:
        pH_out: Effluent pH
        DOC_out: Effluent DOC [mg/L]
        TSS_out: Effluent TSS [mg/L]
        g10_coag: Coagulation velocity gradient [1/s]
        g10_floc: Flocculation velocity gradient [1/s]
        limits: Constraint limits
        weights: Penalty weights

    Returns:
        Total penalty value (unitless, added to objective)
    """
    penalty = 0.0

    # pH constraint (two-sided)
    v_ph = 0.0
    if pH_out < limits.pH_min:
        v_ph = limits.pH_min - pH_out
    elif pH_out > limits.pH_max:
        v_ph = pH_out - limits.pH_max
    penalty += weights.lam_pH * v_ph

    # DOC constraint (upper bound, normalized)
    v_doc = max(0.0, (DOC_out - limits.doc_out_max) / max(limits.doc_out_max, 1e-6))
    penalty += weights.lam_DOC * v_doc

    # TSS constraint (upper bound, normalized)
    v_tss = max(0.0, (TSS_out - limits.tss_out_max) / max(limits.tss_out_max, 1e-6))
    penalty += weights.lam_TSS * v_tss

    # Velocity gradient constraints (upper bounds, normalized)
    if g10_coag > limits.g10_coag_max:
        penalty += weights.lam_G * (g10_coag - limits.g10_coag_max) / limits.g10_coag_max
    if g10_floc > limits.g10_floc_max:
        penalty += weights.lam_G * (g10_floc - limits.g10_floc_max) / limits.g10_floc_max

    # Coagulation residence time constraints
    if theta_coag < limits.theta_coag_min:
        v = (limits.theta_coag_min - theta_coag) / max(limits.theta_coag_min, 1e-6)
        penalty += weights.lam_theta_coag * v
    if theta_coag > limits.theta_coag_max:
        v = (theta_coag - limits.theta_coag_max) / max(limits.theta_coag_max, 1e-6)
        penalty += weights.lam_theta_coag * v

    # Flocculation residence time constraints
    if theta_floc < limits.theta_floc_min:
        v = (limits.theta_floc_min - theta_floc) / max(limits.theta_floc_min, 1e-6)
        penalty += weights.lam_theta_floc * v
    if theta_floc > limits.theta_floc_max:
        v = (theta_floc - limits.theta_floc_max) / max(limits.theta_floc_max, 1e-6)
        penalty += weights.lam_theta_floc * v

    # Per-stage TSS removal split (one-sided floor on coagulation).
    # Coagulation is the model's only dose-dependent TSS pathway, so requiring it
    # to carry its share of the required removal forces a realistic dose. The
    # flocculator's share is handled implicitly by the TSS constraint above.
    gap = TSS_in - limits.tss_out_max
    if gap > 0:
        coag_target = limits.coag_removal_split * gap
        coag_removal = TSS_in - TSS_post_coag
        penalty += weights.lam_split * max(0.0, coag_target - coag_removal) / gap

    return penalty


# ============================================================================
# Optimization Objective Function
# ============================================================================

def objective_scalar(
        x: np.ndarray,
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates
) -> Tuple[float, Dict[str, float]]:
    """
    Scalarized objective function: minimize total annual cost + penalties.

    This is the function minimized by differential evolution. It:
    1. Unpacks decision variables
    2. Simulates the process
    3. Computes base costs (chemical, tank, energy)
    4. Adds constraint violation penalties

    Args:
        x: Decision vector [dose, g10_coag, V_coag, g10_floc, length, surf]
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states

    Returns:
        Tuple of (objective_value, cost_breakdown_dict)
    """
    # Unpack decision variables
    dose_mmol = float(x[0])
    g10_coag = float(x[1])
    V_coag_m3 = float(x[2])
    g10_floc = float(x[3])
    length_m = float(x[4])
    surf_m2 = float(x[5])

    # Derived volumes
    V_floc_m3 = length_m * surf_m2
    volume_m3 = V_coag_m3 + V_floc_m3

    # Simulate process
    sim = stimela_simulate(
        inputs, params, initials,
        dose_mmol, g10_coag, V_coag_m3,
        g10_floc, length_m, surf_m2
    )

    pH_out = sim["pH_out"]
    DOC_out = sim["DOC_out_mgL"]
    TSS_out = sim["TSS_out_mgL"]
    TSS_post_coag = sim["TSS_post_coag_mgL"]
    theta_coag = sim["theta_coag"]  # ADD
    theta_floc = sim["theta_floc"]  # ADD

    TSS_in = float(np.mean(inputs.suspended_solids))

    # Calculate average flow rate [m³/day]
    flow_m3_day = np.mean(inputs.flow) * 24.0  # flow is in m³/h

    # ---- Cost Components ----

    # Chemical cost [€/year]
    chem_cost_year = compute_coagulant_cost(dose_mmol, flow_m3_day, params)

    # Tank cost [€/year]
    crf, constr_cost, maintenance_cost = compute_tank_cost(volume_m3, params)
    tank_cost_year = constr_cost + maintenance_cost

    # Energy cost [€/year]
    energy_kWh_year_coag, energy_kWh_year_floc, energy_cost_year = compute_energy_cost(
        g10_coag, V_coag_m3, g10_floc, V_floc_m3, params
    )

    # Base objective (total annual cost)
    base = chem_cost_year + tank_cost_year + energy_cost_year

    # ---- Constraint Penalties ----
    penalty = compute_constraint_penalties(
        pH_out, DOC_out, TSS_out, g10_coag, g10_floc, theta_coag, theta_floc,
        TSS_in, TSS_post_coag, limits, weights
    )

    # Total objective
    objective_value = base + penalty

    # Detailed cost breakdown
    cost_breakdown = {
        "crf": crf,
        "chem_cost_year": chem_cost_year,
        "constr_cost_year": constr_cost,
        "maintenance_cost_year": maintenance_cost,
        "tank_cost_year": tank_cost_year,
        "energy_cost_year": energy_cost_year,
        "energy_kWh_year_coag": energy_kWh_year_coag,
        "energy_kWh_year_floc": energy_kWh_year_floc,
        "penalty": penalty,
        "theta_coag": theta_coag,  # ADD
        "theta_floc": theta_floc,  # ADD
    }

    return objective_value, cost_breakdown


# ============================================================================
# Optimization Solver
# ============================================================================

def solve(
        inputs: QualityInputs,
        params: Params,
        limits: Limits,
        weights: Weights,
        initials: InitialStates,
        seed: int = 42,
        maxiter: int = 60,
        popsize: int = 15,
        tol: float = 1e-3,
) -> Dict:
    """
    Solve optimization problem using differential evolution.

    Minimizes total annual cost subject to water quality constraints
    by optimizing coagulant dose, velocity gradients, and reactor dimensions.

    Args:
        inputs: Water quality inputs
        params: Process parameters
        limits: Process limits and constraints
        weights: Penalty weights
        initials: Initial states
        seed: Random seed for reproducibility
        maxiter: Maximum number of DE iterations
        popsize: Population size for DE
        tol: Convergence tolerance

    Returns:
        Dictionary with optimization results, including:
        - success: optimization success flag
        - message: solver message
        - fun: optimal objective value
        - x_opt: optimal decision variables
        - outputs: effluent water quality
        - costs_breakdown: detailed cost analysis
    """
    # Define decision variable bounds
    bounds = [
        (limits.dose_min_mmol, limits.dose_max_mmol),  # dose [mmol/L]
        (limits.g10_coag_min, limits.g10_coag_max),  # g10 coag [1/s]
        (limits.V_coag_min, limits.V_coag_max),  # V_coag [m³]
        (limits.g10_floc_min, limits.g10_floc_max),  # g10 floc [1/s]
        (limits.length_floc_min_m, limits.length_floc_max_m),  # length [m]
        (limits.surf_min_m2, limits.surf_max_m2),  # surf [m²]
    ]

    # Wrapper for objective function (DE expects single return value)
    def objective_wrapper(x: np.ndarray) -> float:
        obj_val, _ = objective_scalar(x, inputs, params, limits, weights, initials)
        return obj_val

    # Run differential evolution
    result = differential_evolution(
        objective_wrapper,
        bounds=bounds,
        strategy="best1bin",
        maxiter=maxiter,
        popsize=popsize,
        tol=tol,
        mutation=(0.5, 1.0),
        recombination=0.7,
        seed=seed,
        polish=True,
        disp=True
    )

    # Unpack optimal solution
    x_opt = result.x
    dose_mmol = float(x_opt[0])
    g10_coag = float(x_opt[1])
    V_coag_m3 = float(x_opt[2])
    g10_floc = float(x_opt[3])
    length_m = float(x_opt[4])
    surf_m2 = float(x_opt[5])

    # Derived volumes
    V_floc_m3 = length_m * surf_m2
    volume_m3 = V_coag_m3 + V_floc_m3

    # Re-simulate with optimal parameters to extract detailed results
    sim = stimela_simulate(
        inputs, params, initials,
        dose_mmol, g10_coag, V_coag_m3,
        g10_floc, length_m, surf_m2
    )

    # Re-evaluate objective to get cost breakdown
    obj_val, costs = objective_scalar(
        x_opt, inputs, params, limits, weights, initials
    )

    # Extract effluent quality
    pH_out = sim["pH_out"]
    DOC_out = sim["DOC_out_mgL"]
    TSS_out = sim["TSS_out_mgL"]
    TSS_post_coag = sim["TSS_post_coag_mgL"]
    M_number_out = sim["M-number"]
    uv254_out = sim["uv254"]
    conductivity_out = sim["conductivity"]

    theta_coag = costs["theta_coag"]  # ADD
    theta_floc = costs["theta_floc"]  # ADD

    # Per-stage TSS removal split (for reporting; see compute_constraint_penalties)
    TSS_in = float(np.mean(inputs.suspended_solids))
    gap = TSS_in - limits.tss_out_max
    coag_removal_mgL = TSS_in - TSS_post_coag
    floc_removal_mgL = TSS_post_coag - TSS_out
    coag_target_removal_mgL = limits.coag_removal_split * gap if gap > 0 else 0.0
    coag_removal_pct_of_gap = round(100.0 * coag_removal_mgL / gap, 1) if gap > 0 else None
    floc_removal_pct_of_gap = round(100.0 * floc_removal_mgL / gap, 1) if gap > 0 else None

    # Convert dose to mg/L using the correct chemical's molecular weight
    if params.coagulant.lower() == "fecl3":
        dose_mgL = dose_mmol * params.fecl3_mmol_to_mgL
    elif params.coagulant.lower() == "al2so43":
        dose_mgL = dose_mmol * params.al2so43_mmol_to_mgL
    else:
        dose_mgL = float("nan")

    # Compile comprehensive results report
    report = {
        "success": bool(result.success),
        "message": str(result.message),
        "fun": round(float(result.fun), 2),
        "x_opt": {
            "coagulation_chemical_dose_mmol": round(dose_mmol,5),
            "coagulation_G": round(g10_coag,0),
            "coagulation_volume": round(V_coag_m3,1),
            "flocculation_G": round(g10_floc,0),
            "flocculation_length": round(length_m,1),
            "flocculation_surface": round(surf_m2,1)
        },
        "derived": {
            "V_coag_m3": round(V_coag_m3,2),
            "V_floc_m3": round(V_floc_m3,2),
            "V_total_m3": round(volume_m3,2),
            "coagulation_chemical_dose": round(dose_mgL,1),
        },
        "inputs": {
            "pH_input": np.mean(inputs.ph),
            "DOC_input_mgL": np.mean(inputs.doc),
            "TSS_input_mgL": np.mean(inputs.suspended_solids),
        },
        "outputs": {
            "pH_out": round(pH_out,2),
            "DOC_out_mgL": round(DOC_out,3),
            "TSS_out_mgL": round(TSS_out,3),
            "M-number_out_mmolL": round(M_number_out,3),
            "uv254_out_1m": round(uv254_out,3),
            "conductivity_out_mS/m": round(conductivity_out,3),
            "theta_coag_min": round(theta_coag, 1),  # ADD
            "theta_floc_min": round(theta_floc, 1),  # ADD
            "TSS_post_coag_mgL": round(TSS_post_coag, 3),
            "coag_removal_mgL": round(coag_removal_mgL, 3),
            "floc_removal_mgL": round(floc_removal_mgL, 3),
            "coag_target_removal_mgL": round(coag_target_removal_mgL, 3),
            "coag_removal_pct_of_gap": coag_removal_pct_of_gap,
            "floc_removal_pct_of_gap": floc_removal_pct_of_gap,
        },
        "constraints": {
            "pH_min": limits.pH_min,
            "pH_max": limits.pH_max,
            "doc_out_max": limits.doc_out_max,
            "tss_out_max": limits.tss_out_max,
            "coag_removal_split": limits.coag_removal_split,
        },
        "optimal variables": {
            "chem_dose_mmol": round(dose_mmol,5),
            "g10_coag+g10_floc": round(g10_coag + g10_floc,2),
            "V_total_m3": round(volume_m3,2)
        },
        "costs_breakdown": {
            "chem_cost_year_eur": round(costs["chem_cost_year"], 1),
            "constr_cost_year": round(costs["constr_cost_year"], 1),
            "maintenance_cost_year": round(costs["maintenance_cost_year"], 1),
            "tank_cost_year_eur": round(costs["tank_cost_year"], 1),
            "energy_kWh_year_coag": round(costs["energy_kWh_year_coag"], 1),
            "energy_kWh_year_floc": round(costs["energy_kWh_year_floc"], 1),
            "energy_cost_year_eur": round(costs["energy_cost_year"], 1),
            "penalty_added_unitless": round(costs["penalty"],3),
            "obj_fun_value": round(obj_val, 1),
        }
    }

    return report


# ============================================================================
# Command-Line Interface
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Run coagulation-flocculation optimization from JSON config"
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to configuration JSON file"
    )
    parser.add_argument(
        "--out_json",
        type=str,
        default="outputs/coag_floc_results.json",
        help="Path to output results JSON file"
    )
    return parser


def parse_cli_args(argv=None) -> argparse.Namespace:
    """Parse CLI args for coagulation-flocculation optimization."""
    return build_parser().parse_args(argv)


def run_cli(args: argparse.Namespace) -> Dict:
    """Run optimization from parsed CLI args and write output JSON."""

    from pystimela_optim import api as optim_api

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    algo = cfg.get("algorithm", {})
    # Keep historical behavior: algorithm values in config take precedence.
    seed = algo.get("seed", 42)
    maxiter = algo.get("maxiter", 60)
    popsize = algo.get("popsize", 15)
    tol = algo.get("tol", 1e-3)

    report = optim_api.optimize_coag_floc(
        cfg,
        seed=seed,
        maxiter=maxiter,
        popsize=popsize,
        tol=tol,
    )

    # Save results
    with open(args.out_json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Results saved to {args.out_json}")
    return report


def main(argv=None):
    """CLI entry point."""
    args = parse_cli_args(argv)
    run_cli(args)


if __name__ == "__main__":
    main()