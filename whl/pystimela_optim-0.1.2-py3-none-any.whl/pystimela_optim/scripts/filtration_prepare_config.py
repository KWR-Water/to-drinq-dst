"""
Configuration Preparation Tool for Filtration Optimization

This module builds the optimization configuration from a CSV file. It:
- Reads baseline design from django_outputs.json
- Automatically generates process bounds with configurable scaling
- Allows manual override of all parameters
- Validates inputs and generates final JSON configuration

The generated configuration is consumed by filtration_optim.py.
"""

import json
import os
import sys
from typing import Dict, Any
import csv

# ============================================================================
# Constants and Defaults
# ============================================================================

# Fixed scaling factor for bounds: ±10× baseline values
BOUNDS_SCALE = 10.0

# Default penalty weights for constraint violations
DEFAULT_WEIGHTS = {
    "lam_TSS": 2e4,
    "lam_HL": 2e4,
    "lam_ACC": 1e4,
    "lam_theta": 1e6,
}

# Default differential evolution algorithm parameters
DEFAULT_ALGO = {
    "seed": 42,
    "maxiter": 300,
    "popsize": 30,
    "tol": 1e-3,
    "workers": 1,
}

# Default process model parameters
DEFAULT_PARAMS = {
    # Physical parameters
    "lwater": 1.0,
    "filporo": 39.0,
    "nmax": 75.0,
    "rhod": 30.0,
    # Kinetic parameters
    "lambda0": 0.15,
    "n1": 290.0,
    "n2": 310.0,
    "numcel": 5,
    # Financial parameters
    "n_years": 40,
    "r_nom": 0.05,
    "infl": 0.031,
    # Filter media cost
    "sand_filter_cost": 80.0,
}

# Fixed file paths
DJANGO_JSON_PATH = "configs/django_outputs.json"
OUT_JSON_PATH = "configs/filtration_config.json"
WQ_JSON_PATH = "configs/in_wq_params.json"

TIMESTAMPS_CSV_PATH = "inputs/timestamps/filtration_single.csv"
PLANT_DESIGN_CSV_PATH = "inputs/django_plant_design.csv"


def read_plant_design(path: str) -> Dict[str, Any]:
    """Read plant-wide economic parameters (n_years, r_nom, infl) from CSV."""
    values = {}
    with open(path, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter=";"):
            values[row["parameters"].strip()] = row["value"].strip()
    return {
        "n_years": int(values["n_years"]),
        "r_nom": float(values["r_nom"]),
        "infl": float(values["infl"]),
    }

# Velocity constraint: filtration velocity must stay within [V_MIN_MH, V_MAX_MH] m/h
V_MIN_MH = 5.0
V_MAX_MH = 15.0


# ============================================================================
# Load configurations from csv
# ============================================================================

def load_config_from_csv(csv_path: str):
    config = {'decision_variables': {}, 'constraints': {}, 'initial_conditions': {},
              'model_parameters': {}, 'operation': {}, 'penalties': {}, 'optimization': {}, 'simulation': {}}
    with open(csv_path, 'r') as f:
        # Read a sample of the file to detect the delimiter automatically
        sample = f.read(2048)
        f.seek(0)

        # Try to guess the delimiter (usually ',' or ';' or '\t')
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample)
        except csv.Error:
            # fallback if detection fails (e.g., single-line CSV)
            dialect = csv.get_dialect('excel')
            dialect.delimiter = ','
        reader = csv.DictReader(f, dialect=dialect)

        for row in reader:
            section = row['section'].lower().replace('-', '_')
            param, value = row['parameter'], row['value']
            if value.lower() == 'auto': converted_value = 'auto'
            elif value.lower() in ('true', 'false'): converted_value = value.lower() == 'true'
            else:
                try: converted_value = float(value) if '.' in value else int(value)
                except ValueError: converted_value = value
            if section in config: config[section][param] = converted_value
    return config


# ============================================================================
# JSON I/O Utilities
# ============================================================================

def load_json(path: str) -> Dict[str, Any]:
    """Load JSON file and return as dictionary."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: Dict[str, Any]) -> None:
    """Write dictionary to JSON file with automatic directory creation."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def read_timestamps(path: str) -> list:
    """Read timestamps CSV (single column 'time_s') and return list of floats."""
    with open(path, "r") as f:
        lines = [l.strip() for l in f if l.strip()]
    # skip header if it starts with a letter
    return [float(l) for l in lines if not l[0].isalpha()]


# ============================================================================
# Configuration Builders
# ============================================================================

def build_limits_from_django(
        django_json_path: str,
        scale: float,
        tss_out_max: float,
        headloss_max: float,
        accum_max: float,
        theta_min: float = 5.0,   # ADD
        theta_max: float = 60.0   # ADD
) -> Dict[str, float]:
    """
    Generate optimization bounds from baseline design values.

    Reads baseline design parameters from django_outputs.json and expands
    them into min/max bounds using the specified scale factor.

    Args:
        django_json_path: Path to django outputs JSON
        scale: Scaling factor for bounds (±scale × baseline)
        tss_out_max: Maximum effluent TSS [mg/L]
        headloss_max: Maximum head loss [m]
        accum_max: Maximum accumulated solids [kg/m³]

    Returns:
        Dictionary of process limits

    Raises:
        KeyError: If expected fields are missing from django JSON
    """
    data = load_json(django_json_path)

    # Django outputs are nested under "Process_outputs"
    base = data.get("Process_outputs", data)

    try:
        # Extract single filtration parameters
        filt_surf = float(base["single_filtration_surface"]["value"])
        filt_depth = float(base["single_filtration_depth"]["value"])
        filt_grain_size = float(base["single_filtration_grain_size_a"]["value"])
    except Exception as e:
        raise KeyError(f"Missing expected fields in {django_json_path}: {e}")

    return {
        # Filter surface area bounds [m²]
        "surf_min_m2": filt_surf / scale,
        "surf_max_m2": filt_surf * scale,
        # Bed height (depth) bounds [m]
        "lbed_min_m": filt_depth / scale,
        "lbed_max_m": filt_depth * scale,
        # Grain size bounds [mm]
        "diam_min_mm": filt_grain_size / scale,
        "diam_max_mm": filt_grain_size * scale,
        "theta_min": theta_min,  # ADD
        "theta_max": theta_max,  # ADD
        # Operational constraints
        "headloss_max_m": headloss_max,
        "tss_out_max_mgL": tss_out_max,
        "accum_max_kgm3": accum_max,

    }


def read_wq_params(json_path: str) -> Dict[str, Any]:
    """
    Read inlet water quality parameters from JSON.

    Extracts and remaps WQ parameters for downstream processing.
    Converts keys to lowercase/snake_case for consistency.

    Args:
        json_path: Path to water quality parameters JSON

    Returns:
        Dictionary with remapped WQ parameter keys
    """
    data = load_json(json_path)
    wp = data["WQ_parameters"]

    return {
        "flow": wp["flow"],
        "temperature": wp["temperature"],
        "suspended_solids": wp["suspended_solids"],
    }


def assemble_config(
        limits: Dict[str, Any],
        initials: Dict[str, Any],
        params: Dict[str, Any],
        wq_params: Dict[str, Any],
        backwash_freq_h: float,
        weights: Dict[str, Any] = None,
        algo: Dict[str, Any] = None,
        timestamps: list = None,
) -> Dict[str, Any]:
    """
    Assemble final configuration JSON structure.

    Combines all configuration components into the structure expected
    by filtration_optim.py.

    Args:
        limits: Process limits dictionary
        initials: Initial states dictionary
        params: Process parameters dictionary
        wq_params: Water quality parameters dictionary
        backwash_freq_h: Backwash frequency [hours]
        weights: Penalty weights (optional, uses DEFAULT_WEIGHTS if not provided)
        algo: Algorithm parameters (optional, uses DEFAULT_ALGO if not provided)

    Returns:
        Complete configuration dictionary ready for JSON export
    """
    # Use defaults if not provided
    if weights is None:
        weights = DEFAULT_WEIGHTS
    if algo is None:
        algo = DEFAULT_ALGO
    
    # Build bounds list for documentation
    bounds_list = [
        {
            "name": "surf_m2",
            "min": limits["surf_min_m2"],
            "max": limits["surf_max_m2"],
            "units": "m2"
        },
        {
            "name": "lbed_m",
            "min": limits["lbed_min_m"],
            "max": limits["lbed_max_m"],
            "units": "m"
        },
        {
            "name": "diam_mm",
            "min": limits["diam_min_mm"],
            "max": limits["diam_max_mm"],
            "units": "mm"
        },
    ]

    return {
        "process": "filtration",
        "inputs": {
            "timestamps": timestamps if timestamps is not None else [1, 3600],
            "wq_parameters": wq_params,
        },
        "limits": limits,
        "initials": initials,
        "weights": weights,
        "params": params,
        "algorithm": algo,
        "backwash_freq_h": backwash_freq_h,
        "bounds": bounds_list,
        "notes": {
            "source": "auto-generated from django_outputs.json",
            "wq_csv_format": (
                "semicolon-delimited; headers: "
                "timestamp;flow;temperature;suspended_solids"
            ),
            "scaling": (
                f"bounds derived using ±{BOUNDS_SCALE}× from django base values"
            )
        }
    }


def generate_config_from_csv(csv_path: str, wq_json_path: str):
    """Generate configuration from CSV."""
    print(f"Reading configuration from: {csv_path}")
    
    csv_config = load_config_from_csv(csv_path)
    wq_params = read_wq_params(wq_json_path)
    use_auto = csv_config['decision_variables'].get('use_auto_bounds', True)

    if use_auto:
        print("   Using auto-calculated bounds from django_outputs.json")
    else:
        print("   Using manual bounds from CSV")

    auto_limits = build_limits_from_django(DJANGO_JSON_PATH, BOUNDS_SCALE,
                                           csv_config['constraints'].get('tss_out_max', 1.0),
                                           csv_config['constraints'].get('headloss_max', 1.5),
                                           csv_config['constraints'].get('accum_max', 500000.0),
                                           csv_config['constraints'].get('theta_min', 5.0),
                                           csv_config['constraints'].get('theta_max', 60.0))

    final_limits = auto_limits if use_auto else dict(auto_limits)
    if not use_auto:
        dv = csv_config['decision_variables']
        for key in ['surf_min_m2', 'surf_max_m2', 'lbed_min_m', 'lbed_max_m', 'diam_min_mm', 'diam_max_mm']:
            if key in dv and dv[key] != 'auto': final_limits[key] = dv[key]

    ic = csv_config.get('initial_conditions', {})
    initials = {"suspended_solids_initial": ic.get('ss_initial', 0.0),
                "init_accumulation_initial": ic.get('accum_initial', 0.0)}

    params = dict(DEFAULT_PARAMS)
    for key, val in csv_config.get('model_parameters', {}).items():
        if key in params: params[key] = val

    # Override plant-wide economic parameters from the shared plant-design file
    if os.path.exists(PLANT_DESIGN_CSV_PATH):
        plant = read_plant_design(PLANT_DESIGN_CSV_PATH)
        params["n_years"] = plant["n_years"]
        params["r_nom"] = plant["r_nom"]
        params["infl"] = plant["infl"]

    weights = dict(DEFAULT_WEIGHTS)
    for key, val in csv_config.get('penalties', {}).items():
        if key in weights: weights[key] = val

    algo = dict(DEFAULT_ALGO)
    for key, val in csv_config.get('optimization', {}).items():
        if key in algo: algo[key] = val

    timestamps = read_timestamps(TIMESTAMPS_CSV_PATH)

    # Clamp surf bounds to velocity constraint: V = flow/surf must be in [V_MIN_MH, V_MAX_MH]
    flow_m3h = float(wq_params["flow"]["value"])
    final_limits["surf_min_m2"] = max(final_limits["surf_min_m2"], flow_m3h / V_MAX_MH)
    final_limits["surf_max_m2"] = min(final_limits["surf_max_m2"], flow_m3h / V_MIN_MH)

    # NOW USE assemble_config to create the proper structure
    config = assemble_config(
        limits=final_limits,
        initials=initials,
        params=params,
        wq_params=wq_params,
        backwash_freq_h=csv_config.get('operation', {}).get('backwash_freq', 0.0),
        weights=weights,
        algo=algo,
        timestamps=timestamps,
    )

    write_json(OUT_JSON_PATH, config)
    print(f"Configuration saved to: {OUT_JSON_PATH}")

# ============================================================================
# Entry Point
# ============================================================================

def main(argv=None) -> None:
    """CLI entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="Prepare single filtration optimization configuration.")
    parser.add_argument("--in_wq_params", required=True)
    parser.add_argument("--csv_config", default="inputs/config_filtration_single.csv")
    args = parser.parse_args(argv)

    WQ_JSON_PATH = args.in_wq_params
    if not os.path.exists(WQ_JSON_PATH):
        sys.exit(f"Error: WQ parameters file not found at {WQ_JSON_PATH}")
    if not os.path.exists(args.csv_config):
        sys.exit(f"Error: CSV config file not found at {args.csv_config}")

    print(f"Loaded WQ parameters from: {WQ_JSON_PATH}")
    generate_config_from_csv(args.csv_config, WQ_JSON_PATH)


if __name__ == "__main__":
    main()
