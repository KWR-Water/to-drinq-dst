"""
Configuration Preparation Tool for GAC Filtration Optimization

This module builds the optimization configuration from a CSV file. It:
- Reads baseline design from django_outputs.json
- Automatically generates process bounds with configurable scaling
- Allows manual override of all parameters
- Validates inputs and generates final JSON configuration

The generated configuration is consumed by gac_optim.py.
"""

import json
import os
import sys
from typing import Dict, Any
import csv

# ============================================================================
# Constants and Defaults
# ============================================================================

# Fixed scaling factor for bounds: ±10× baseline values
BOUNDS_SCALE = 10.0

# Default penalty weights for constraint violations
DEFAULT_WEIGHTS = {
    "lam_DOC": 1e6,
    "lam_theta": 1e6,
}

# Default differential evolution algorithm parameters
DEFAULT_ALGO = {
    "seed": 42,
    "maxiter": 100,
    "popsize": 20,
    "tol": 1e-3,
    "workers": 1,
}

# Default process model parameters
DEFAULT_PARAMS = {
    # Physical parameters
    "diam": 2.0,
    "filporo": 50.0,
    "rho_k": 500.0,
    # Kinetic parameters (Freundlich adsorption)
    "freund_n": 0.5,
    "freund_k": 20.0,
    "mass_tr_coef_k2": 0.006,
    "numcel": 5,
    # Financial parameters
    "n_years": 40,
    "r_nom": 0.05,
    "infl": 0.031,
    # GAC replacement cost
    "gac_replacement_cost": 5000.0,
}

# Fixed file paths
DJANGO_JSON_PATH = "configs/django_outputs.json"
OUT_JSON_PATH = "configs/gac_config.json"
WQ_JSON_PATH = "configs/in_wq_params.json"

TIMESTAMPS_CSV_PATH = "inputs/timestamps/gac.csv"
PLANT_DESIGN_CSV_PATH = "inputs/django_plant_design.csv"


def read_plant_design(path: str) -> Dict[str, Any]:
    """Read plant-wide economic parameters (n_years, r_nom, infl) from CSV."""
    values = {}
    with open(path, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter=";"):
            values[row["parameters"].strip()] = row["value"].strip()
    return {
        "n_years": int(values["n_years"]),
        "r_nom": float(values["r_nom"]),
        "infl": float(values["infl"]),
    }

# ============================================================================
# Load configurations from csv
# ============================================================================

def load_config_from_csv(csv_path: str):
    config = {'decision_variables': {}, 'constraints': {}, 'model_parameters': {},
              'penalties': {}, 'optimization': {}, 'simulation': {}}
    with open(csv_path, 'r', encoding='utf-8') as f:
        # Read a sample of the file to detect the delimiter automatically
        sample = f.read(2048)
        f.seek(0)

        # Try to guess the delimiter (usually ',' or ';' or '\t')
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample)
        except csv.Error:
            # fallback if detection fails (e.g., single-line CSV)
            dialect = csv.get_dialect('excel')
            dialect.delimiter = ','
        reader = csv.DictReader(f, dialect=dialect)
        reader.fieldnames = [name.strip().lstrip('\ufeff') for name in reader.fieldnames]
        for row in reader:
            section = row['section'].lower().replace('-', '_')
            param, value = row['parameter'], row['value']
            if value.lower() == 'auto': converted_value = 'auto'
            elif value.lower() in ('true', 'false'): converted_value = value.lower() == 'true'
            else:
                try: converted_value = float(value) if '.' in value else int(value)
                except ValueError: converted_value = value
            if section in config: config[section][param] = converted_value
    return config

# ============================================================================
# JSON I/O Utilities
# ============================================================================

def load_json(path: str) -> Dict[str, Any]:
    """Load JSON file and return as dictionary."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: Dict[str, Any]) -> None:
    """Write dictionary to JSON file with automatic directory creation."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def read_timestamps(path: str) -> list:
    """Read timestamps CSV (single column 'time_s') and return list of floats."""
    with open(path, "r") as f:
        lines = [l.strip() for l in f if l.strip()]
    # skip header if it starts with a letter
    return [float(l) for l in lines if not l[0].isalpha()]


# ============================================================================
# Configuration Builders
# ============================================================================

def build_limits_from_django(
        django_json_path: str,
        scale: float,
        doc_out_max: float,
        theta_min: float = 5.0,
        theta_max: float = 60,
) -> Dict[str, float]:
    """
    Generate optimization bounds from baseline design values.

    Reads baseline design parameters from django_outputs.json and expands
    them into min/max bounds using the specified scale factor.

    Args:
        django_json_path: Path to django outputs JSON
        scale: Scaling factor for bounds (±scale × baseline)
        doc_out_max: Maximum effluent DOC [mg/L]

    Returns:
        Dictionary of process limits

    Raises:
        KeyError: If expected fields are missing from django JSON
    """
    data = load_json(django_json_path)

    # Django outputs are nested under "Process_outputs"
    base = data.get("Process_outputs", data)

    try:
        # Extract GAC parameters
        gac_surf = float(base["gac_surface"]["value"])
        gac_depth = float(base["gac_depth"]["value"])
    except Exception as e:
        raise KeyError(f"Missing expected fields in {django_json_path}: {e}")

    return {
        # Filter surface area bounds [m²]
        "surf_min_m2": gac_surf / scale,
        "surf_max_m2": gac_surf * scale,
        # Bed height (depth) bounds [m]
        "lbed_min_m": gac_depth / scale,
        "lbed_max_m": gac_depth * scale,
        # Residence time constraints [min]  # new
        "theta_min": theta_min,
        "theta_max": theta_max,
        # Effluent quality constraint
        "doc_out_max": doc_out_max,
    }


def read_wq_params(json_path: str) -> Dict[str, Any]:
    """
    Read inlet water quality parameters from JSON.

    Extracts and remaps WQ parameters for downstream processing.
    Converts keys to lowercase/snake_case for consistency.

    Args:
        json_path: Path to water quality parameters JSON

    Returns:
        Dictionary with remapped WQ parameter keys
    """
    data = load_json(json_path)
    wp = data["WQ_parameters"]

    return {
        "flow": wp["flow"],
        "temperature": wp["temperature"],
        "doc": wp["DOC"],  # DOC → doc
    }


def assemble_config(
        limits: Dict[str, Any],
        initials: Dict[str, Any],
        params: Dict[str, Any],
        wq_params: Dict[str, Any],
        backwash_freq_h: float,
        weights: Dict[str, Any] = None,
        algo: Dict[str, Any] = None,
        timestamps: list = None,
) -> Dict[str, Any]:
    """
    Assemble final configuration JSON structure.

    Combines all configuration components into the structure expected
    by gac_optim.py.

    Args:
        limits: Process limits dictionary
        initials: Initial states dictionary
        params: Process parameters dictionary
        wq_params: Water quality parameters dictionary
        backwash_freq_h: Backwash frequency [hours]
        weights: Penalty weights dictionary (optional, uses defaults if not provided)
        algo: Algorithm parameters dictionary (optional, uses defaults if not provided)

    Returns:
        Complete configuration dictionary ready for JSON export
    """
    # Use defaults if not provided
    if weights is None:
        weights = DEFAULT_WEIGHTS
    if algo is None:
        algo = DEFAULT_ALGO
    
    # Build bounds list for documentation
    bounds_list = [
        {
            "name": "surf_m2",
            "min": limits["surf_min_m2"],
            "max": limits["surf_max_m2"],
            "units": "m2"
        },
        {
            "name": "lbed_m",
            "min": limits["lbed_min_m"],
            "max": limits["lbed_max_m"],
            "units": "m"
        },
    ]

    return {
        "process": "gac-filtration",
        "inputs": {
            "timestamps": timestamps if timestamps is not None else [1, 3600],
            "wq_parameters": wq_params,
        },
        "limits": limits,
        "initials": initials,
        "weights": weights,
        "params": params,
        "algorithm": algo,
        "backwash_freq_h": backwash_freq_h,
        "bounds": bounds_list,
        "notes": {
            "source": "auto-generated from django_outputs.json",
            "wq_csv_format": (
                "semicolon-delimited; headers: "
                "timestamp;flow;temperature;doc"
            ),
            "scaling": (
                f"bounds derived using ±{BOUNDS_SCALE}× from django base values"
            )
        }
    }


def generate_config_from_csv(csv_path: str, wq_json_path: str):
    """
    Generate GAC configuration JSON from CSV file.
    
    Produces output matching the exact structure of gac_config.json.
    
    Args:
        csv_path: Path to CSV configuration file
        wq_json_path: Path to water quality parameters JSON
    """
    # Load CSV configuration
    csv_config = load_config_from_csv(csv_path)
    
    # Validate required sections
    required_sections = ['decision_variables', 'constraints']
    missing = [s for s in required_sections if s not in csv_config]
    if missing:
        raise ValueError(f"Missing required CSV sections: {missing}")
    
    # Read water quality parameters
    wq_params = read_wq_params(wq_json_path)
    
    # Get constraint values from CSV
    constraints = csv_config.get('constraints', {})
    doc_max = constraints.get('doc_max', 0.5)
    theta_min = constraints.get('theta_min', 5.0)  # ADD
    theta_max = constraints.get('theta_max', 60.0)  # ADD
    
    # Determine whether to use auto-calculated bounds
    dv = csv_config.get('decision_variables', {})
    use_auto = dv.get('use_auto_bounds', True)
    
    # Build limits dictionary
    if use_auto:
        # Use auto-calculated bounds from django_outputs.json
        print(f"Using auto-calculated bounds (scale={BOUNDS_SCALE}x)")
        final_limits = build_limits_from_django(
            DJANGO_JSON_PATH,
            BOUNDS_SCALE,
            doc_max,
            theta_min,
            theta_max
        )
    else:
        # Start with auto-calculated as baseline
        auto_limits = build_limits_from_django(
            DJANGO_JSON_PATH,
            BOUNDS_SCALE,
            doc_max,
            theta_min,
            theta_max
        )
        final_limits = dict(auto_limits)
        
        # Override with CSV values if provided and not "auto"
        print("Using manual bounds from CSV")
        for key in ['surf_min_m2', 'surf_max_m2', 'lbed_min_m', 'lbed_max_m']:
            if key in dv:
                val = dv[key]
                if val != 'auto':
                    final_limits[key] = float(val)
                    print(f"  {key} = {val} (from CSV)")
    
    # Ensure doc_out_max is in limits (it's a constraint, not a bound)
    final_limits['doc_out_max'] = doc_max
    final_limits['theta_min'] = theta_min
    final_limits['theta_max'] = theta_max
    
    # Build initials dictionary
    initials = {
        "doc_initial": float(constraints.get('doc_initial', 0.0)),
        "accum_initial": float(constraints.get('accum_initial', 0.0))
    }
    
    # Build params dictionary (merge defaults with CSV)
    params = dict(DEFAULT_PARAMS)
    csv_params = csv_config.get('model_parameters', {})
    for key, val in csv_params.items():
        if key in params:
            # Ensure integer parameters remain integers
            if key in ("numcel", "n_years"):
                params[key] = int(val)
            else:
                params[key] = float(val)

    # Override plant-wide economic parameters from the shared plant-design file
    if os.path.exists(PLANT_DESIGN_CSV_PATH):
        plant = read_plant_design(PLANT_DESIGN_CSV_PATH)
        params["n_years"] = plant["n_years"]
        params["r_nom"] = plant["r_nom"]
        params["infl"] = plant["infl"]
    
    # Build weights dictionary (merge defaults with CSV)
    weights = dict(DEFAULT_WEIGHTS)
    csv_weights = csv_config.get('penalties', {})
    for key, val in csv_weights.items():
        if key in weights:
            weights[key] = float(val)
    
    # Build algorithm dictionary (merge defaults with CSV)
    algo = dict(DEFAULT_ALGO)
    csv_algo = csv_config.get('optimization', {})
    for key, val in csv_algo.items():
        if key in algo:
            # Ensure integer parameters remain integers
            if key in ("maxiter", "popsize", "workers", "seed"):
                algo[key] = int(val)
            else:
                algo[key] = float(val)
    
    # Get backwash frequency (default 0.0 if not in CSV)
    backwash_freq_h = float(constraints.get('backwash_freq_h', 0.0))

    timestamps = read_timestamps(TIMESTAMPS_CSV_PATH)

    # Assemble final configuration
    config = assemble_config(
        limits=final_limits,
        initials=initials,
        params=params,
        wq_params=wq_params,
        backwash_freq_h=backwash_freq_h,
        weights=weights,
        algo=algo,
        timestamps=timestamps,
    )
    
    # Write output JSON
    write_json(OUT_JSON_PATH, config)
    
    # Display summary
    print(f"\nConfiguration saved to: {OUT_JSON_PATH}")
    print("\nDecision variable bounds:")
    print(f"  Surface: {final_limits['surf_min_m2']:.6g} – "
          f"{final_limits['surf_max_m2']:.6g} m²")
    print(f"  Bed height: {final_limits['lbed_min_m']:.6g} – "
          f"{final_limits['lbed_max_m']:.6g} m")
    print("\nEffluent constraints:")
    print(f"  DOC max: {final_limits['doc_out_max']} mg/L")
    print(f"\nBackwash frequency: {backwash_freq_h} hours")
    print(f"\nInitial states:")
    print(f"  DOC initial: {initials['doc_initial']} mg/L")
    print(f"  Accumulation initial: {initials['accum_initial']}")
    # ADD THIS LINE:
    print(f"   Theta: min={final_limits['theta_min']}, max={final_limits['theta_max']}")
    print("\nConfiguration complete!")

# ============================================================================
# Entry Point
# ============================================================================

def main(argv=None) -> None:
    """CLI entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="Prepare GAC optimization configuration.")
    parser.add_argument("--in_wq_params", required=True)
    parser.add_argument("--csv_config", default="inputs/config_gac.csv")
    args = parser.parse_args(argv)

    WQ_JSON_PATH = args.in_wq_params
    if not os.path.exists(WQ_JSON_PATH):
        sys.exit(f"Error: WQ parameters file not found at {WQ_JSON_PATH}")
    if not os.path.exists(args.csv_config):
        sys.exit(f"Error: CSV config file not found at {args.csv_config}")

    print(f"Loaded WQ parameters from: {WQ_JSON_PATH}")
    generate_config_from_csv(args.csv_config, WQ_JSON_PATH)


if __name__ == "__main__":
    main()
