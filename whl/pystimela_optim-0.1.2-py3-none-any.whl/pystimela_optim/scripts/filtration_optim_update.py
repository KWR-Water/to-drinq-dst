"""
Water Quality Parameter Update Tool for Filtration

This module propagates filtration optimization results to water quality
configuration files. It reads filtration optimization outputs and updates
the inlet water quality parameters JSON for downstream process optimization.

This enables sequential optimization of multi-stage treatment processes.
"""

import json
import argparse
import os
import sys
from typing import Dict, Any


# ============================================================================
# JSON I/O Utilities
# ============================================================================

def load_json(path: str) -> Dict[str, Any]:
    """
    Load JSON file with error handling.

    Args:
        path: File path to JSON

    Returns:
        Parsed JSON as dictionary

    Raises:
        FileNotFoundError: If file doesn't exist
        json.JSONDecodeError: If file is not valid JSON
    """
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: str, data: Dict[str, Any]) -> None:
    """
    Save dictionary to JSON file with automatic directory creation.

    Args:
        path: Output file path
        data: Dictionary to save
    """
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


# ============================================================================
# Water Quality Update Logic
# ============================================================================

def update_wq_from_results(
        wq_json_path: str,
        results_json_path: str,
        out_json_path: str = None
) -> None:
    """
    Update water quality parameters JSON from filtration optimization results.

    This function:
    1. Reads the current WQ parameters JSON
    2. Reads the filtration optimization results JSON
    3. Maps output keys to WQ parameter keys
    4. Updates values in the WQ JSON
    5. Saves the updated WQ JSON

    Args:
        wq_json_path: Path to water quality parameters JSON (input)
        results_json_path: Path to optimization results JSON
        out_json_path: Optional output path (defaults to wq_json_path)

    Raises:
        SystemExit: If required files are missing or invalid
    """
    # Validate input files exist
    if not os.path.exists(wq_json_path):
        print(f"❌ WQ JSON not found: {wq_json_path}")
        sys.exit(1)
    if not os.path.exists(results_json_path):
        print(f"❌ Results JSON not found: {results_json_path}")
        sys.exit(1)

    # Load data
    wq_data = load_json(wq_json_path)
    results = load_json(results_json_path)

    # Validate WQ JSON structure
    if "WQ_parameters" not in wq_data:
        print("❌ Invalid WQ JSON: Missing 'WQ_parameters' section.")
        sys.exit(1)

    wq_params = wq_data["WQ_parameters"]
    outputs = results.get("outputs", {})

    # Define mapping between optimization outputs and WQ parameter keys
    # Format: {optimization_output_key: wq_parameter_key}
    mapping = {
        "TSS_out_mgL": "suspended_solids",
    }

    print("🔄 Updating WQ parameters based on filtration optimization outputs...\n")

    # Update or add parameters
    for out_key, wq_key in mapping.items():
        if out_key not in outputs:
            continue

        new_val = float(outputs[out_key])

        if wq_key in wq_params:
            # Update existing parameter
            old_val = wq_params[wq_key]["value"]
            wq_params[wq_key]["value"] = new_val
            print(f"  {wq_key:<20s}: {old_val:.3f} → {new_val:.3f}")
        else:
            # Add new parameter (with generic units)
            wq_params[wq_key] = {"units": "mg/L", "value": new_val}
            print(f"  + Added new WQ param '{wq_key}' = {new_val:.3f}")

    # Save updated WQ JSON
    out_path = out_json_path or wq_json_path
    save_json(out_path, wq_data)
    print(f"\n✅ Updated WQ JSON saved to: {out_path}")


# ============================================================================
# Command-Line Interface
# ============================================================================

def main():
    """
    Main entry point for command-line execution.

    Provides CLI for updating WQ parameters from filtration optimization results.
    """
    parser = argparse.ArgumentParser(
        description="Update WQ parameters from filtration optimization results"
    )
    parser.add_argument(
        "--wq_json",
        type=str,
        default= None,
        required=True,
        help="Path to the WQ parameters JSON (input)"
    )
    parser.add_argument(
        "--results_json",
        type=str,
        default=None,
        required=True,
        help="Path to the filtration optimization results JSON"
    )
    parser.add_argument(
        "--out_json",
        type=str,
        default=None,
        required=False,
        help="Optional output path for updated WQ JSON (defaults to --wq_json)"
    )
    args = parser.parse_args()

    update_wq_from_results(args.wq_json, args.results_json, args.out_json)


if __name__ == "__main__":
    main()