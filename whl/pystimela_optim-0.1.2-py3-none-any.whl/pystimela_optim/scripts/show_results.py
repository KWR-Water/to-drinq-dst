import json
from pathlib import Path
from IPython.display import display, HTML

name_map = {
    "coag_floc_results":       "Coagulation & Flocculation",
    "filtration_results":      "Sand Filtration",
    "dual_filtration_results": "Dual Filtration",
    "gac_results":             "GAC Filtration",
    "chlorination_results":    "Chlorination",
    "ozonation_results":       "Ozonation",
}

unit_map = {
    "mgL": "mg/L", "ugL": "µg/L", "m3": "m³", "m2": "m²",
    "min": "min", "cfu100mL": "CFU/100mL", "m": "m",
    "mmolL": "mmol/L", "eur": "€",
}

def fmt_key(k):
    parts = k.split("_")
    unit = ""
    for u, label in unit_map.items():
        if parts[-1] == u:
            unit = f" ({label})"
            parts = parts[:-1]
            break
    name = " ".join(p.capitalize() for p in parts)
    name = name.replace(" Out", "").replace(" In", "").replace(" Year", "/yr")
    return name + unit

def section(title):
    return (
        f'<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.05em;'
        f'color:#888;margin:10px 0 4px">{title}</div>'
    )

def rows_html(d, decimals=True):
    html = ""
    for k, v in d.items():
        label = fmt_key(k)
        if isinstance(v, float):
            val = f"{v:,.3g}" if decimals else f"{v:,.0f}"
        else:
            val = str(v)
        html += (
            f'<tr style="border-bottom:1px solid #f5f5f5">'
            f'<td style="color:#444;padding:4px 12px 4px 0">{label}</td>'
            f'<td style="font-weight:600;text-align:right;padding:4px 0">{val}</td>'
            f'</tr>'
        )
    return html

def build_card(key, data):
    name = name_map.get(key, key.replace("_results", "").replace("_", " ").title())
    cost = data.get("fun", "—")
    cost_str = f"€{cost:,.0f} / yr" if isinstance(cost, (int, float)) else str(cost)
    ok = "✅" if data.get("success", True) else "❌"

    x_opt = data.get("x_opt", data.get("optimal variables", {}))
    outputs = data.get("outputs", {})

    body = ""
    body += section("Optimal Design")
    body += f'<table style="width:100%;border-collapse:collapse;font-size:13px">{rows_html(x_opt)}</table>'
    body += section("Effluent Quality")
    body += f'<table style="width:100%;border-collapse:collapse;font-size:13px">{rows_html(outputs)}</table>'

    # Chlorination extras
    if key == "chlorination_results":
        derived = data.get("derived", {})
        if "cl2_kg_per_d" in derived:
            dosing = {"cl2_kg_per_d": derived["cl2_kg_per_d"]}
            body += section("Dosing")
            body += f'<table style="width:100%;border-collapse:collapse;font-size:13px">{rows_html(dosing)}</table>'

        costs = {k: v for k, v in data.get("costs_breakdown", {}).items()
                 if k not in ("penalty_added_unitless", "obj_fun_value")}
        if costs:
            body += section("Cost Breakdown")
            body += f'<table style="width:100%;border-collapse:collapse;font-size:13px">{rows_html(costs, decimals=False)}</table>'

    return f"""
    <div style="background:#fff;border:1px solid #e0e0e0;border-radius:10px;
                padding:16px;min-width:270px;max-width:330px;
                box-shadow:0 2px 6px rgba(0,0,0,0.08);font-family:sans-serif">
        <div style="font-size:15px;font-weight:bold;color:#1a237e;
                    border-bottom:2px solid #e8eaf6;padding-bottom:8px;margin-bottom:10px">
            {ok} {name}
            <span style="float:right;color:#2e7d32;font-weight:bold">{cost_str}</span>
        </div>
        {body}
    </div>
    """

def show_results():
    folders = sorted([f for f in Path("outputs").iterdir()
                      if f.is_dir() and f.name[0].isdigit()])
    latest = folders[-1]

    results = {}
    for f in sorted(latest.glob("*_results.json")):
        with open(f) as fp:
            results[f.stem] = json.load(fp)

    cards = "".join(build_card(key, data) for key, data in results.items())

    display(HTML(f"""
    <div style="font-family:sans-serif;margin:12px 0">
      <h3 style="color:#1a237e;margin-bottom:12px">
        Optimization Results &nbsp;·&nbsp;
        <span style="font-weight:normal;font-size:14px;color:#555">{latest.name}</span>
      </h3>
      <div style="display:flex;flex-wrap:wrap;gap:16px;align-items:flex-start">{cards}</div>
    </div>
    """))

show_results()
