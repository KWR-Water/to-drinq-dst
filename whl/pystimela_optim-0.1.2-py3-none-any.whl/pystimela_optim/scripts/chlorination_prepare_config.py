"""
Configuration Preparation Tool for Chlorination Optimization

This module builds the optimization configuration from a CSV file. It:
- Reads baseline design from django_outputs.json
- Automatically generates process bounds with configurable scaling
- Allows manual override of all parameters
- Validates inputs and generates final JSON configuration

The generated configuration is consumed by chlorination_optim.py.
"""

import json
import os
import sys
from typing import Dict, Any
import csv

# ============================================================================
# Constants and Defaults
# ============================================================================

# Fixed scaling factor for bounds: ±10 baseline values
BOUNDS_SCALE = 10.0

# Default penalty weights for constraint violations
DEFAULT_WEIGHTS = {
    "lam_residual": 1e6,
    "lam_tthms": 1e5,
    "lam_haas": 1e5,
    "lam_theta": 1e6,  # Added: penalty for residence time violations
}

# Default differential evolution algorithm parameters
DEFAULT_ALGO = {
    "seed": 42,
    "maxiter": 300,
    "popsize": 20,
    "tol": 1e-3,
}

# Default process model parameters
DEFAULT_PARAMS = {
    # Chlorination parameters
    "baffling_factor": 1.0,
    # Chemical cost parameters
    "price_per_kg": 0.51,
    "solution": 0.15,
    # Financial parameters
    "n_years": 40,
    "r_nom": 0.05,
    "infl": 0.031,
}

# Fixed file paths
DJANGO_JSON_PATH = "configs/django_outputs.json"
OUT_JSON_PATH = "configs/chlorination_config.json"
WQ_JSON_PATH = "configs/in_wq_params.json"
TIMESTAMPS_CSV_PATH = "inputs/timestamps/chlorination.csv"
PLANT_DESIGN_CSV_PATH = "inputs/django_plant_design.csv"


def read_plant_design(path: str) -> Dict[str, Any]:
    """Read plant-wide economic parameters (n_years, r_nom, infl) from CSV."""
    values = {}
    with open(path, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter=";"):
            values[row["parameters"].strip()] = row["value"].strip()
    return {
        "n_years": int(values["n_years"]),
        "r_nom": float(values["r_nom"]),
        "infl": float(values["infl"]),
    }

# ============================================================================
# Load configurations from csv
# ============================================================================

def load_config_from_csv(csv_path: str):
    config = {'decision_variables': {}, 'constraints': {}, 'initials': {}, 'model_parameters': {},
              'penalties': {}, 'optimization': {}, 'simulation': {}}
    with open(csv_path, 'r') as f:
        # Read a sample of the file to detect the delimiter automatically
        sample = f.read(2048)
        f.seek(0)

        # Try to guess the delimiter (usually ',' or ';' or '\t')
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample)
        except csv.Error:
            # fallback if detection fails (e.g., single-line CSV)
            dialect = csv.get_dialect('excel')
            dialect.delimiter = ','
        reader = csv.DictReader(f, dialect=dialect)
        reader.fieldnames = [name.strip().lstrip('\ufeff') for name in reader.fieldnames]
        for row in reader:
            section = row['section'].lower().replace('-', '_')
            param, value = row['parameter'], row['value']
            if value.lower() == 'auto': converted_value = 'auto'
            elif value.lower() in ('true', 'false'): converted_value = value.lower() == 'true'
            else:
                try: converted_value = float(value) if '.' in value else int(value)
                except ValueError: converted_value = value
            if section in config: config[section][param] = converted_value
    return config

# ============================================================================
# JSON I/O Utilities
# ============================================================================

def load_json(path: str) -> Dict[str, Any]:
    """Load JSON file and return as dictionary."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: Dict[str, Any]) -> None:
    """Write dictionary to JSON file with automatic directory creation."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def read_timestamps(path: str) -> list:
    """Read timestamps CSV (single column 'time_s') and return list of floats."""
    with open(path, "r") as f:
        lines = [l.strip() for l in f if l.strip()]
    # skip header if it starts with a letter
    return [float(l) for l in lines if not l[0].isalpha()]


# ============================================================================
# Configuration Builders
# ============================================================================

def build_limits_from_django(
        django_json_path: str,
        scale: float,
        residual_min: float,
        tthms_max: float,
        haas_max: float,
        theta_min: float = 5.0,   # ADD THIS LINE
        theta_max: float = 60.0   # ADD THIS LINE
) -> Dict[str, float]:
    """
    Generate optimization bounds from baseline design values.

    Reads baseline design parameters from django_outputs.json and expands
    them into min/max bounds using the specified scale factor.

    Args:
        django_json_path: Path to django outputs JSON
        scale: Scaling factor for bounds (±scale —> baseline)
        residual_min: Minimum residual chlorine [mg/L]
        tthms_max: Maximum TTHMs [Âµg/L]
        haas_max: Maximum HAAs [Âµg/L]

    Returns:
        Dictionary of process limits

    Raises:
        KeyError: If expected fields are missing from django JSON
    """
    data = load_json(django_json_path)

    # Django outputs are nested under "Process_outputs"
    base = data.get("Process_outputs", data)

    try:
        # Extract chlorination parameters
        chlor_vol = float(base["chlorination_volume"]["value"])
        chlor_dose = float(base["chlorination_chemical_dose"]["value"])
    except Exception as e:
        raise KeyError(f"Missing expected fields in {django_json_path}: {e}")

    return {
        # Chlorine dose bounds [mg/L]
        "chlorine_dose_min": chlor_dose / scale,
        "chlorine_dose_max": chlor_dose * scale,
        # Volume bounds [m³]
        "volume_min": chlor_vol / scale,
        "volume_max": chlor_vol * scale,
        # Residence time constraints [min]
        "theta_min": theta_min,  # ADD THIS LINE
        "theta_max": theta_max,  # ADD THIS LINE
        # Effluent quality constraints
        "residual_min": residual_min,
        "tthms_max": tthms_max,
        "haas_max": haas_max,
    }


def read_wq_params(json_path: str) -> Dict[str, Any]:
    """
    Read inlet water quality parameters from JSON.

    Extracts and remaps WQ parameters for downstream processing.
    Converts keys to lowercase/snake_case for consistency.

    Args:
        json_path: Path to water quality parameters JSON

    Returns:
        Dictionary with remapped WQ parameter keys
    """
    data = load_json(json_path)
    wp = data["WQ_parameters"]

    return {
        "flow": wp["flow"],
        "temperature": wp["temperature"],
        "DOC": wp["DOC"],
        "ammonia": wp["ammonia"],
        "pH": wp["pH"],
        "uv254": wp["uv254"],
        "bromide": wp["bromide"],
        "ecoli": wp.get("ecoli", {"value": 0}),
    }


def assemble_config(
        limits: Dict[str, Any],
        initials: Dict[str, Any],
        params: Dict[str, Any],
        wq_params: Dict[str, Any],
        weights: Dict[str, Any] = None,
        algo: Dict[str, Any] = None,
        timestamps: list = None,
) -> Dict[str, Any]:
    """
    Assemble final configuration JSON structure.

    Combines all configuration components into the structure expected
    by chlorination_optim.py.

    Args:
        limits: Process limits dictionary
        initials: Initial states dictionary
        params: Process parameters dictionary
        wq_params: Water quality parameters dictionary
        weights: Penalty weights dictionary (optional, uses defaults if not provided)
        algo: Algorithm parameters dictionary (optional, uses defaults if not provided)

    Returns:
        Complete configuration dictionary ready for JSON export
    """
    # Use defaults if not provided
    if weights is None:
        weights = DEFAULT_WEIGHTS
    if algo is None:
        algo = DEFAULT_ALGO
    
    # Build bounds list for documentation
    bounds_list = [
        {
            "name": "chlorine_dose_mgL",
            "min": limits["chlorine_dose_min"],
            "max": limits["chlorine_dose_max"],
            "units": "mg/L"
        },
        {
            "name": "volume_m3",
            "min": limits["volume_min"],
            "max": limits["volume_max"],
            "units": "m3"
        },
    ]

    return {
        "process": "chlorination",
        "inputs": {
            "timestamps": timestamps if timestamps is not None else [1, 3600],
            "wq_parameters": wq_params,
        },
        "limits": limits,
        "initials": initials,
        "weights": weights,
        "params": params,
        "algorithm": algo,
        "bounds": bounds_list,
        "notes": {
            "source": "auto-generated from django_outputs.json",
            "wq_csv_format": (
                "semicolon-delimited; headers: "
                "timestamp;flow;temperature;doc;ammonia;ph;uv254;bromide"
            ),
            "scaling": (
                f"bounds derived using ±{BOUNDS_SCALE}— from django base values"
            )
        }
    }


def generate_config_from_csv(csv_path: str, wq_json_path: str):
    """
    Generate chlorination configuration JSON from CSV file.
    
    Produces output matching the exact structure of chlorination_config.json.
    
    Args:
        csv_path: Path to CSV configuration file
        wq_json_path: Path to water quality parameters JSON
    """
    # Load CSV configuration
    csv_config = load_config_from_csv(csv_path)
    
    # Validate required sections
    required_sections = ['decision_variables', 'constraints']
    missing = [s for s in required_sections if s not in csv_config]
    if missing:
        raise ValueError(f"Missing required CSV sections: {missing}")
    
    # Read water quality parameters
    wq_params = read_wq_params(wq_json_path)
    
    # Get constraint values from CSV
    constraints = csv_config.get('constraints', {})
    residual_min = constraints.get('residual_min', 0.4)
    tthms_max = constraints.get('tthms_max', 80.0)
    haas_max = constraints.get('haas_max', 60.0)
    theta_min = constraints.get('theta_min', 5.0)  # New: residence time min
    theta_max = constraints.get('theta_max', 60.0)  # New: residence time max

    
    # Determine whether to use auto-calculated bounds
    dv = csv_config.get('decision_variables', {})
    use_auto = dv.get('use_auto_bounds', True)
    
    # Build limits dictionary
    if use_auto:
        # Use auto-calculated bounds from django_outputs.json
        print(f"Using auto-calculated bounds (scale={BOUNDS_SCALE}x)")
        final_limits = build_limits_from_django(
            DJANGO_JSON_PATH,
            BOUNDS_SCALE,
            residual_min,
            tthms_max,
            haas_max,
            theta_min,
            theta_max
        )
    else:
        # Start with auto-calculated as baseline
        auto_limits = build_limits_from_django(
            DJANGO_JSON_PATH,
            BOUNDS_SCALE,
            residual_min,
            tthms_max,
            haas_max,
            theta_min,
            theta_max
        )
        final_limits = dict(auto_limits)
        
        # Override with CSV values if provided and not "auto"
        print("Using manual bounds from CSV")
        for key in ['chlorine_dose_min', 'chlorine_dose_max', 'volume_min', 'volume_max']:
            if key in dv:
                val = dv[key]
                if val != 'auto':
                    final_limits[key] = float(val)
                    print(f"  {key} = {val} (from CSV)")
    
    # Ensure constraints are in limits
    final_limits['residual_min'] = residual_min
    final_limits['tthms_max'] = tthms_max
    final_limits['haas_max'] = haas_max
    final_limits['theta_min'] = theta_min
    final_limits['theta_max'] = theta_max
    
    # Build initials dictionary
    # Try INITIALS section first, fall back to CONSTRAINTS section, then use defaults
    initials_section = csv_config.get('initials', {})
    initials = {
        "reschl_initial": float(
            initials_section.get('reschl_initial', 
            constraints.get('reschl_initial', 0.001))
        ),
        "tthms_initial": float(
            initials_section.get('tthms_initial',
            constraints.get('tthms_initial', 0.0))
        ),
        "haas_initial": float(
            initials_section.get('haas_initial',
            constraints.get('haas_initial', 0.0))
        )
    }
    
    # Build params dictionary (merge defaults with CSV)
    params = dict(DEFAULT_PARAMS)
    csv_params = csv_config.get('model_parameters', {})
    for key, val in csv_params.items():
        if key in params:
            # Ensure integer parameters remain integers
            if key in ("n_years",):
                params[key] = int(val)
            else:
                params[key] = float(val)

    # Override plant-wide economic parameters from the shared plant-design file
    if os.path.exists(PLANT_DESIGN_CSV_PATH):
        plant = read_plant_design(PLANT_DESIGN_CSV_PATH)
        params["n_years"] = plant["n_years"]
        params["r_nom"] = plant["r_nom"]
        params["infl"] = plant["infl"]
    
    # Build weights dictionary (merge defaults with CSV)
    weights = dict(DEFAULT_WEIGHTS)
    csv_weights = csv_config.get('penalties', {})
    for key, val in csv_weights.items():
        if key in weights:
            weights[key] = float(val)
    
    # Build algorithm dictionary (merge defaults with CSV)
    algo = dict(DEFAULT_ALGO)
    csv_algo = csv_config.get('optimization', {})
    for key, val in csv_algo.items():
        if key in algo:
            # Ensure integer parameters remain integers
            if key in ("maxiter", "popsize", "seed"):
                algo[key] = int(val)
            else:
                algo[key] = float(val)
    
    timestamps = read_timestamps(TIMESTAMPS_CSV_PATH)

    # Assemble final configuration
    config = assemble_config(
        limits=final_limits,
        initials=initials,
        params=params,
        wq_params=wq_params,
        weights=weights,
        algo=algo,
        timestamps=timestamps,
    )
    
    # Write output JSON
    write_json(OUT_JSON_PATH, config)
    
    # Display summary
    print(f"\nConfiguration saved to: {OUT_JSON_PATH}")
    print("\nDecision variable bounds:")
    print(f"  Chlorine dose: {final_limits['chlorine_dose_min']:.6g} – "
          f"{final_limits['chlorine_dose_max']:.6g} mg/L")
    print(f"  Contact volume: {final_limits['volume_min']:.6g} – "
          f"{final_limits['volume_max']:.6g} m³")
    print("\nResidence time constraints:")
    print(f"  Theta min: {final_limits['theta_min']} min")
    print(f"  Theta max: {final_limits['theta_max']} min")
    print("\nEffluent constraints:")
    print(f"  Residual min: {final_limits['residual_min']} mg/L")
    print(f"  TTHMs max: {final_limits['tthms_max']} µg/L")
    print(f"  HAAs max: {final_limits['haas_max']} µg/L")
    print(f"\nInitial states:")
    print(f"  Residual chlorine initial: {initials['reschl_initial']} mg/L")
    print(f"  TTHMs initial: {initials['tthms_initial']} µg/L")
    print(f"  HAAs initial: {initials['haas_initial']} µg/L")
    print("\nConfiguration complete!")


# ============================================================================
# Entry Point
# ============================================================================

def main(argv=None) -> None:
    """CLI entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="Prepare chlorination optimization configuration.")
    parser.add_argument("--in_wq_params", required=True)
    parser.add_argument("--csv_config", default="inputs/config_chlorination.csv")
    args = parser.parse_args(argv)

    WQ_JSON_PATH = args.in_wq_params
    if not os.path.exists(WQ_JSON_PATH):
        sys.exit(f"Error: WQ parameters file not found at {WQ_JSON_PATH}")
    if not os.path.exists(args.csv_config):
        sys.exit(f"Error: CSV config file not found at {args.csv_config}")

    print(f"Loaded WQ parameters from: {WQ_JSON_PATH}")
    generate_config_from_csv(args.csv_config, WQ_JSON_PATH)


if __name__ == "__main__":
    main()
