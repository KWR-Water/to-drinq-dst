"""Top-level package for pyStimela optimization workflows.

Use modules under ``pystimela_optim.scripts`` for runtime imports.
Use ``pystimela_optim.api`` for parser-free programmatic callbacks.
"""

from __future__ import annotations

from . import api

__all__ = ["api", "scripts"]
