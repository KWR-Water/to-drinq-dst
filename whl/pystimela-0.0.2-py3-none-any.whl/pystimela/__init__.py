from pystimela.logging_config import setup_logging

__version__ = "0.0.2"

setup_logging()
