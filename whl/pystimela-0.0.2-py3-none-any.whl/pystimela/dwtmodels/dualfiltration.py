# Filtration process (Dual filter) - March 2025
# It updates the following water quality parameters: Suspended.solids

# Check: It was not possible to replicate the results of Stimella. The function returns the same results with matlab according to GPT.

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Rapid_filtration/Susp_Solids_Dual_media_filter/dubfil_s.m

# The model requires as (water quality) inputs:
# temperature [degree C]
# flow [m3/h]
# Suspended.solids [mg/l]

import logging
from typing import List
from numpy.typing import NDArray
from copy import deepcopy
import numpy as np
from scipy.integrate import solve_ivp


from pystimela.datatypes import (
    DualFiltrationParams,
    DualFiltrationState,
    ListWaterQualityParams,
    BackWashData,
)

from pystimela.helpers.common import find_interval
from pystimela.toolbox import waterparams as wpf

logger = logging.getLogger(__name__)


class DualFiltration(object):
    def __init__(self, params: DualFiltrationParams):
        self.params = params

        self.ss2_start_idx = 2 * self.params.numcel1
        self.ss2_end_idx = 2 * self.params.numcel1 + self.params.numcel2
        self.ss1_end_idx = self.params.numcel1
        self.acc1_start_idx = self.params.numcel1
        self.acc1_end_idx = 2 * self.params.numcel1
        self.acc2_start_idx = 2 * self.params.numcel1 + self.params.numcel2

    def model(
        self,
        time: float,
        y: NDArray[np.float64],
        bw_mat: BackWashData,
        in_wp: ListWaterQualityParams,
    ) -> List[float]:

        # Process parameters
        num_cel1 = self.params.numcel1  # Number of control volumes (upper)
        num_cel2 = self.params.numcel2  # Number of control volumes (lower)
        surf = self.params.surf  # Filter surface area
        diam1 = self.params.diam1 / 1000  # Grain size (m) (upper)
        diam2 = self.params.diam2 / 1000  # Grain size (m) (lower)
        rho_d = self.params.rhod  # Density of deposited solids (kg/m3)
        fil_por01 = self.params.filporo1 / 100  # Initial filter porosity (upper)
        fil_por02 = self.params.filporo2 / 100  # Initial filter porosity (lower)
        lambda01 = self.params.lambda01  # Filtration resistance parameter (upper)
        lambda02 = self.params.lambda02  # Filtration resistance parameter (lower)
        n1 = self.params.n1  # Resistance accumulation parameter (upper)
        n2 = self.params.n2  # Resistance accumulation parameter (lower)
        dy1 = self.params.dy1  # Thickness of each cell/control volume (upper)
        dy2 = self.params.dy2  # Thickness of each cell/control volume (lower)
        k1 = 1 / n1
        k2 = 1 / n2

        # Input water quality parameters
        timesteps = in_wp.timestamps
        pos = find_interval(time, timesteps)

        susp = in_wp[pos].suspended_solids / 1000  # Suspended solids (kg/m3)
        temp = in_wp[pos].temperature  # Temperature (C)
        flow = in_wp[pos].flow  # Flow rate (m3/h)

        # Backwash parameters
        bw_pos = find_interval(time, bw_mat.timestamps)
        backwash = bw_mat.events[bw_pos]

        # Estimate parameters
        vel = flow / (surf * 3600)  # Velocity (m/s)
        nu = wpf.calc_kinimatic_viscosity(temp)  # Water viscosity (m2/s)

        lambda01 = 9e-18 / (nu * vel * diam1**3)
        lambda02 = 9e-18 / (nu * vel * diam2**3)

        # Unpack state variables
        ss1 = y[: self.ss1_end_idx]
        accumulation1 = y[self.acc1_start_idx : self.acc1_end_idx]
        ss2 = y[self.ss2_start_idx : self.ss2_end_idx]
        accumulation2 = y[self.acc2_start_idx :]
        # Calculate porosity reduction
        fil_por1 = fil_por01 - (accumulation1 / rho_d)
        fil_por2 = fil_por02 - (accumulation2 / rho_d)
        # Initiate derivatives
        d_ss1 = np.zeros(num_cel1)
        d_accumulation1 = np.zeros(num_cel1)
        d_ss2 = np.zeros(num_cel2)
        d_accumulation2 = np.zeros(num_cel2)

        if backwash == 1:
            d_ss1 = -(1 / 90) * ss1
            d_ss2 = -(1 / 90) * ss2
            d_accumulation1 = -(1 / 90) * accumulation1
            d_accumulation2 = -(1 / 90) * accumulation2
        else:
            # Compute derivatives

            mat_q1 = create_matrix(1, num_cel1)
            mat_q2 = create_matrix(1, num_cel2)

            # for Upper filter
            d_ss1 = ((vel / fil_por1) / dy1) * (
                mat_q1 @ np.concatenate([[susp], ss1])
            ) - (
                lambda01
                * (
                    1
                    + (accumulation1 / (k1 * rho_d))
                    - ((accumulation1 / rho_d) ** 2) / (k2 * fil_por1)
                )
            ) * ss1
            d_accumulation1 = (vel / dy1) * (mat_q1 @ np.concatenate([[susp], ss1]))

            # for Lower filter
            d_ss2 = ((vel / fil_por2) / dy2) * (
                mat_q2 @ np.concatenate([[ss1[-1]], ss2])
            ) - (
                lambda02
                * (
                    1
                    + (accumulation2 / (k1 * rho_d))
                    - ((accumulation2 / rho_d) ** 2) / (k2 * fil_por2)
                )
            ) * ss2
            d_accumulation2 = (vel / dy2) * (mat_q2 @ np.concatenate([[ss1[-1]], ss2]))

        return np.concatenate([d_ss1, d_accumulation1, d_ss2, d_accumulation2])

    def solve_ode(
        self,
        t_eval: List[float],
        initial_state,
        bw: BackWashData,
        in_wp: ListWaterQualityParams,
    ):
        "solves the ode."
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, bw, in_wp),
            t_span,
            initial_state,
            t_eval=t_eval,
            rtol=1e-5,
            atol=1e-5,
            method="BDF",
        )
        return solution

    def simulate(
        self,
        t_eval,
        init_state: DualFiltrationState,
        wq_params: ListWaterQualityParams,
        bw: BackWashData,
    ) -> dict:
        """Returns the water quality params with updated suspended solids,
        Flow resistance and acummulation in each cell volume.

        """
        num_cel1 = self.params.numcel1  # Number of control volumes (upper)
        num_cel2 = self.params.numcel2  # Number of control volumes (lower)
        out_wqps = []
        solution = self.solve_ode(
            t_eval=t_eval, initial_state=init_state.to_numpy(), bw=bw, in_wp=wq_params
        )
        timesteps = wq_params.timestamps

        last_ss_index = 2 * num_cel1 + num_cel2 - 1

        for i in t_eval:
            pos = find_interval(time=i, timesteps=timesteps)
            out_wqp = deepcopy(wq_params[pos])
            out_wqp.timestamp = i
            # take values from the last cell and convert units to mg/L
            out_wqp.suspended_solids = solution.y[last_ss_index][pos] * 1000
            out_wqps.append(out_wqp)

        # Process parameters
        surf = self.params.surf  # Filter surface area
        diam1 = self.params.diam1 / 1000  # Grain size (m) (upper)
        diam2 = self.params.diam2 / 1000  # Grain size (m) (lower)
        rho_d = self.params.rhod  # Density of deposited solids (kg/m3)
        fil_por01 = self.params.filporo1 / 100  # Initial filter porosity (upper)
        fil_por02 = self.params.filporo2 / 100  # Initial filter porosity (lower)
        dy1 = self.params.dy1  # Thickness of each cell/control volume (upper)
        dy2 = self.params.dy2  # Thickness of each cell/control volume (lower)

        # Estimate parameters
        flow = wq_params[0].flow  # Flow
        temp = wq_params[0].temperature  # Temperature
        vel = flow / (surf * 3600)  # Velocity / surface loading (Q/A)
        nu = wpf.calc_kinimatic_viscosity(temp)  # Water viscosity (m2/s)
        i01 = (180 * nu * ((1 - fil_por01) ** 2) * vel) / (
            9.81 * (fil_por01**3) * (diam1**2)
        )  # initial hydraulic resistance parameter - depends on viscosity ( Head loss factor)
        i02 = (180 * nu * ((1 - fil_por02) ** 2) * vel) / (
            9.81 * (fil_por02**3) * (diam2**2)
        )  # initial hydraulic resistance parameter - depends on viscosity ( Head loss factor)

        # Upper filter resistance
        accum1 = solution.y[num_cel1 : 2 * num_cel1].T
        # Update flow resistance at each cell
        flow_res1 = np.array(
            [
                np.cumsum(
                    dy1 - i01 * dy1 * (fil_por01 / (fil_por01 - (acc / rho_d))) ** 2
                )
                for acc in accum1
            ]
        )

        # Lower filter resistance
        accum2 = solution.y[2 * num_cel1 + num_cel2 :].T
        # Update flow resistance at each cell
        flow_res2 = np.array(
            [
                np.cumsum(
                    dy2 - i02 * dy2 * (fil_por02 / (fil_por02 - (acc / rho_d))) ** 2
                )
                for acc in accum2
            ]
        )

        # convert the units for Suspended solids to mg/L
        solution.y[: self.ss1_end_idx, :] = solution.y[: self.ss1_end_idx, :] * 1000
        solution.y[self.ss2_start_idx : self.ss2_end_idx, :] = (
            solution.y[self.ss2_start_idx : self.ss2_end_idx, :] * 1000
        )

        output_wq_parmas = ListWaterQualityParams(
            timestamps=timesteps, wqparams=out_wqps
        )
        return {
            "out_wqparams": output_wq_parmas,
            "sysout": solution.y.T,
            "flowres_u": flow_res1,
            "flowres_l": flow_res2,
        }


def create_matrix(t, n):
    """Matrix for filtration cells"""
    a = 1 / t
    mat = np.zeros((n, n + 1))

    for i in range(n):
        mat[i, i] = a
        if i + 1 < n + 1:
            mat[i, i + 1] = -a

    return mat
