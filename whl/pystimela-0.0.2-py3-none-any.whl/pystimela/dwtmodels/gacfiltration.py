# Granular Activated Carbon (GAC) Filtration process (Single filter) - March 2025
# removing organic contaminants, taste and odor compounds, and certain inorganic species through adsorption and biological degradation.

# It updates the following water quality parameters: DOC

# No results are provided in github so it is not possible to check the functions. The function returns the same results with matlab according to GPT.

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Adsorption_activated_carbon/GAC_filtration/koofil_s.m


# The model requires as (water quality) inputs:
# temperature [degree C]
# flow [m3/h]
# DOC (dissolved organic carbon) [mg/l]

import logging
from typing import List
from numpy.typing import NDArray
from copy import deepcopy
import numpy as np
from scipy.integrate import solve_ivp


from pystimela.datatypes import (
    GACFiltrationParams,
    WaterQualityParams,
    BackWashData,
    ListWaterQualityParams,
)
from pystimela.helpers.common import create_matrix2, find_interval


logger = logging.getLogger(__name__)


class GACFiltration(object):
    def __init__(self, params: GACFiltrationParams):
        self.params = params

    def model(
        self,
        time: float,
        y: NDArray[np.float64],
        bw_mat: BackWashData,
        in_wp: ListWaterQualityParams,
    ) -> List[float]:

        # Process parameters
        num_cel = self.params.numcel  # Number of control volumes
        fsurf_area = self.params.f_area  # Filter surface area
        diam = self.params.diam / 1000  # Grain size/ diamter of GAC particles (m)
        lbed = self.params.lbed  # Total depth of the filter bed.
        rho_k = self.params.rho_k  # Density of deposited solids (kg/m3)
        fil_por0 = self.params.filporo / 100  # Initial filter porosity
        freund_n = self.params.freund_n  # Freundlich adsorption coefficient.
        freund_k = self.params.freund_k  # Freundlich adsorption coefficient.
        mass_k2 = self.params.mass_tr_coef_k2 / 3600  # Mass transfer coefficient.
        dy = (
            lbed / num_cel
        )  # thickness of each cell/control volume (Spatial discretization step.)

        # Input water quality parameters
        timesteps = in_wp.timestamps
        pos = find_interval(time, timesteps)

        co_doc = in_wp[pos].doc  # mg/l
        temp = in_wp[pos].temperature  # Temperature (C)
        flow = in_wp[pos].flow  # Flow rate (m3/h)

        # Backwash parameters
        bw_pos = find_interval(time, bw_mat.timestamps)
        backwash = bw_mat.events[bw_pos]

        # Estimate parameters
        vel = flow / (fsurf_area * 3600)  # Velocity (m/s)
        vel_real = vel / fil_por0  # real velocity accounting for porosity.

        # Unpack state variables
        ss = y[:num_cel]  # DOC concentration in liquid phase (mg/L) per cell
        accumulation = y[num_cel:]  # Adsorbed DOC mass on GAC (mg/kg) per cell.

        if backwash == 1:
            d_ss = -(1 / 90) * ss
            d_accumulation = -(1 / 90) * accumulation
        else:
            # Compute derivatives
            mat_q1 = create_matrix2(dy=dy, n=num_cel)

            # DOC concentration in liquid phase (mg/L) per cell

            # prepend the inlet concentration
            momentary = np.hstack(([co_doc], ss))
            # advection
            advec = vel_real * (mat_q1 @ momentary)
            # adsorption/desorption term
            rxn = (
                ((1 - fil_por0) / fil_por0)
                * (rho_k * mass_k2)
                * (freund_k * np.sign(ss) * np.abs(ss) ** freund_n - accumulation)
            )

            d_ss = advec - rxn
            d_accumulation = mass_k2 * (
                freund_k * np.sign(ss) * np.abs(ss) ** freund_n - accumulation
            )

        # return as a single vector for use with scipy.integrate.solve_ivp, etc.
        return np.concatenate((d_ss, d_accumulation))

    def solve_ode(
        self,
        t_eval: List[float],
        initial_state,
        bw: BackWashData,
        in_wp: ListWaterQualityParams,
    ):
        "solves the ode."
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, bw, in_wp),
            t_span,
            initial_state,
            method="BDF",
            t_eval=t_eval,
            rtol=1e-5,
            atol=1e-5,
        )
        return solution

    def simulate(
        self, t_eval, init_state, wq_params: ListWaterQualityParams, bw: BackWashData
    ) -> dict:
        """Returns the water quality params with updated suspended solids,
        Flow resistance and acummulation in each cell volume.

        """
        out_wqps = []
        solution = self.solve_ode(
            t_eval=t_eval, initial_state=init_state, bw=bw, in_wp=wq_params
        )
        timesteps = [d.timestamp for d in wq_params]

        for i in t_eval:
            pos = find_interval(time=i, timesteps=timesteps)
            out_wqp = deepcopy(wq_params[pos])
            out_wqp.timestamp = i
            # take values from the last cell and convert units to mg/L
            out_wqp.doc = solution.y[self.params.numcel - 1, pos]
            out_wqps.append(out_wqp)

        # Additional results
        add_res_list = []

        for i, wqparam in enumerate(wq_params):
            co_doc = wqparam.doc
            add_res1 = [co_doc] + list(solution.y[1 : (1 + self.params.numcel), i])
            add_res2 = [0] + list(
                solution.y[(1 + self.params.numcel) : (1 + 2 * self.params.numcel), i]
            )

            allres = add_res1 + add_res2
            add_res_list.append(allres)

        add_res = np.array(add_res_list).T
        add_res = np.vstack([np.array([wqp.to_numpy() for wqp in wq_params]).T, add_res])
        output_wq_params = ListWaterQualityParams(
            timestamps=timesteps, wqparams=out_wqps
        )
        return {
            "out_wqparams": output_wq_params,
            "sysout": solution,
            "add_results": add_res,
        }
