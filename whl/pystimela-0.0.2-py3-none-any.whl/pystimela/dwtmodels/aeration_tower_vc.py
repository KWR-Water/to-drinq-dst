# Packed tower aeration (torbsc_s) - April 2025

# Comparison with Stimela outputs: matlab outputs are the same
# The code has been checked for MeeTe=1, according to Matlab example.

# It updates the following water quality parameters:  Volatile.compound

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Aeration/Tower_aerator/torbsc_s.m

# The model requires as (water quality) inputs:
# temperature [degree C] #
# flow [m3/h] #
# influent Volatile.compound [mg/l]

# It requires as process parameters:
# 'Hoogte',  '2.6',    0,     [], 'm',    'Heigth of the packed bed'
# 'Diam',      '1',        0,  [], 'm',    'Diameter of the packed bed'
# 'QgTot',  '2000',    0,  [], 'm^3/h',    'Total air flow'
# 'QgRec',  '0.4',    0,  [], 'm^3/h',    'Recirculation air flow'
# 'MeeTe',     '0',    {'Cocurrent','Countercurrent','Completely mixed air'},   {'1','0','2'}, '-', 'Flow direction','select'
# 'k2',     '0.05',    0,  [], '1/s',    'Gas transfer coëfficiënt (k_2)'
# 'kD',  '0.05',    0,  [], '-',    'Distribution coëfficiënt (kD)'
# 'NumCel',    '5',    0,  [], '-',    'Number of completely mixed reactors'


import logging
from copy import deepcopy
from typing import List, Dict
from numpy.typing import NDArray
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

from pystimela.datatypes import (
    AerationTowerVCParams,
    ListWaterQualityParams,
    AerationTowerVCState,
    AerationTowerVCCellConcentrations,
)
from pystimela.helpers.common import (
    find_interval,
    create_flow_mixing_matrix,
)
from pystimela.toolbox import carbacideq as cbe
from pystimela.toolbox import constants_library as cl
from pystimela.toolbox import aeration_functions as af

logger = logging.getLogger(__name__)


class AerationTowerVC(object):
    def __init__(self, params: AerationTowerVCParams):
        if params.meetee not in ["cocurrent", "countercurrent"]:
            raise ValueError(
                "meetee processparameter must be " "either cocurrent or countercurrent"
            )
        self.params = params
        num_cel = self.params.numcel
        self.s_idxs = {
            "liquid": {"start": 0, "end": num_cel},
            "gas": {"start": num_cel, "end": 2 * num_cel},
        }
        self.ode_idx = self.s_idxs

    def model(
        self, time: float, y: NDArray[np.float64], in_wp: ListWaterQualityParams
    ) -> List[float]:
        """
        Simulates a tower aeration system for water treatment

        Args:
            time: Current simulation time
            y: Current system state vector
            process_params: Dictionary of process parameters
            input_water_quality: Dictionary of input water quality measurements

        Returns:
            numpy array with derivatives for the state variables
        """

        operation_mode = self.params.meetee  # Operation mode selector

        # Input water quality parameters with time interpolation
        timesteps = in_wp.timestamps
        time_index = find_interval(time, timesteps)

        # air_water_ratio = total_air_flow / water_flow_m3s  # [-]

        cell_residence_time = self.__calculate_cell_residence_time(time_index, in_wp)
        state_vars = self.__unpack_state_variables(y)

        num_cells = self.params.numcel
        gas_transfer_coeff = self.params.k2  # Gas transfer coefficient
        gas_distritubion_coeff = self.params.kd
        total_air_flow = self.params.qg_tot / 3600  # Total airflow [m³/s]
        recirculation_air_flow = (
            self.params.qg_rec / 3600
        )  # Recirculation airflow [m³/s]
        vented_air_flow = self.params.qg_vers / 3600  # Vented airflow [m³/s]

        # Extract water quality parameters with descriptive names
        water_flow = in_wp[time_index].flow  # [m³/h]
        water_flow_m3s = water_flow / 3600  # Convert from m³/h to m³/s
        influent_vc = in_wp[
            time_index
        ].volatile_compound  # influent concentration [mg/l]
        air_water_ratio = total_air_flow / water_flow_m3s  # [-]

        # Gas concentrations in the air
        gas_concentrations = 0
        liquid_mixing_matrix = create_flow_mixing_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )

        reverse_matrix = np.fliplr(
            np.eye(num_cells)
        )  # Matrix for reversing flow direction

        # Calculate derivatives
        match operation_mode:
            case "cocurrent":  # default - open system
                # The cascade operates as an open system with continuous air flow
                # (no accumulation of gases in a headspace)

                # Volatile compound equations
                dvc_liquid = (
                    liquid_mixing_matrix
                    @ np.concatenate(([influent_vc], state_vars["liquid"]))
                    + gas_distritubion_coeff
                    * gas_distritubion_coeff
                    * state_vars["gas"]
                    - gas_transfer_coeff * state_vars["liquid"]
                )

                dvc_gas = (
                    liquid_mixing_matrix
                    @ np.concatenate(
                        (
                            [
                                gas_concentrations * (vented_air_flow / total_air_flow)
                                + state_vars["gas"][-1]
                                * (recirculation_air_flow / total_air_flow)
                            ],
                            state_vars["gas"],
                        )
                    )
                    - ((gas_transfer_coeff * gas_distritubion_coeff) / air_water_ratio)
                    * state_vars["gas"]
                    + (gas_transfer_coeff / air_water_ratio) * state_vars["liquid"]
                )

                derivatives = np.concatenate((dvc_liquid, dvc_gas))

            case "countercurrent":
                dvc_liquid = (
                    liquid_mixing_matrix
                    @ np.concatenate(([influent_vc], state_vars["liquid"]))
                    + gas_transfer_coeff
                    * gas_distritubion_coeff
                    * (reverse_matrix @ state_vars["gas"])
                    - gas_transfer_coeff * state_vars["liquid"]
                )

                dvc_gas = (
                    liquid_mixing_matrix
                    @ np.concatenate(
                        (
                            [
                                gas_concentrations * (vented_air_flow / total_air_flow)
                                + state_vars["gas"][-1]
                                * (recirculation_air_flow / total_air_flow)
                            ],
                            state_vars["gas"],
                        )
                    )
                    - ((gas_transfer_coeff * gas_distritubion_coeff) / air_water_ratio)
                    * state_vars["gas"]
                    + (gas_transfer_coeff / air_water_ratio)
                    * (reverse_matrix @ state_vars["liquid"])
                )

                derivatives = np.concatenate((dvc_liquid, dvc_gas))

        return derivatives.tolist()

    def solve_ode(
        self, t_eval: List[float], initial_state, in_wp: ListWaterQualityParams
    ):
        """Solves the ode."""
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, in_wp),
            t_span,
            initial_state,
            method="BDF",
            t_eval=t_eval,
            rtol=1e-6,
            atol=1e-9,
        )
        return solution

    def convert_model_output_to_df(self, model_output: List[float]):
        new_columns = self.__create_ode_column_names()
        df = pd.DataFrame(
            [model_output], columns=new_columns[1:]
        )  # remove timestamp column
        return df

    def simulate(
        self,
        t_eval,
        init_state: AerationTowerVCState,
        wq_params: ListWaterQualityParams,
    ) -> dict:
        """
        Simulates a cascaded aeration system over time

        Args:
            time_steps: Array of time points for simulation
            initial_state: Initial state vector for the system
            wq_params: List of input water quality measurements

        Returns:
            Dictionary containing simulation results and additional outputs
        """
        # Prepare output water quality empty list
        out_wqps = []
        timesteps = wq_params.timestamps

        # Solve the ODE system
        solution = self.solve_ode(t_eval, init_state.to_numpy(), wq_params)
        # self.__test_ode_indexing(solution.y)
        ode_df = pd.DataFrame(
            np.concatenate([solution.t.reshape(-1, 1), solution.y.T], axis=1)
        )
        ode_df.columns = pd.Index(self.__create_ode_column_names())

        # Extract process parameters with descriptive names
        num_cells = self.params.numcel  # Number of completely mixed reactors
        operation_mode = self.params.meetee
        gas_distritubion_coeff = self.params.kd
        total_air_flow = self.params.qg_tot / 3600  # Total airflow [m³/s]
        recirculation_air_flow = (
            self.params.qg_rec / 3600
        )  # Recirculation airflow [m³/s]
        vented_air_flow = self.params.qg_vers / 3600  # Vented airflow [m³/s]

        # Extract water quality parameters with descriptive names

        # Gas concentrations in the air
        gas_concentrations = 0

        reverse_matrix = np.fliplr(
            np.eye(num_cells)
        )  # Matrix for reversing flow direction

        liquid_con_per_cell = []
        gas_con_per_cell = []
        equil_per_cell = []

        for i, in_wp in enumerate(wq_params):
            # Calculate output Water Quality parameters
            out_wqp = deepcopy(in_wp)
            # take the liquid concentration of the last cell as output volatile compound
            out_wqp.volatile_compound = solution.y[self.s_idxs["liquid"]["end"] - 1, i]
            out_wqps.append(out_wqp)

            # start calculating additional data
            current_vc = in_wp.volatile_compound

            # Concentrations in each cell (including influent) [mg/l]
            cell_liquid_conc_i = np.concatenate(
                (
                    [current_vc],
                    solution.y[
                        self.ode_idx["liquid"]["start"] : self.ode_idx["liquid"]["end"],
                        i,
                    ],
                )
            )

            # Concentrations in the air phase for each cell [mg/l]
            match operation_mode:
                case "cocurrent":

                    cell_gas_conc_i = np.concatenate(
                        (
                            [
                                gas_concentrations * (vented_air_flow / total_air_flow)
                                + solution.y[self.ode_idx["gas"]["end"] - 1, i]
                                * (recirculation_air_flow / total_air_flow)
                            ],
                            solution.y[
                                self.ode_idx["gas"]["start"] : self.ode_idx["gas"][
                                    "end"
                                ],
                                i,
                            ],
                        )
                    )
                case "countercurrent":
                    mixed_gas_i = (
                        reverse_matrix
                        @ solution.y[
                            self.ode_idx["gas"]["start"] : self.ode_idx["gas"]["end"], i
                        ]
                    )
                    cell_gas_conc_i = np.concatenate(
                        (
                            mixed_gas_i,
                            [
                                gas_concentrations * (vented_air_flow / total_air_flow)
                                + solution.y[self.ode_idx["gas"]["end"] - 1, i]
                                * (recirculation_air_flow / total_air_flow)
                            ],
                        )
                    )

            # Saturation concentrations (equilibrium) for each cell
            cell_equilibrium_i = gas_distritubion_coeff * cell_gas_conc_i

            liquid_con_per_cell.append(cell_liquid_conc_i)
            gas_con_per_cell.append(cell_gas_conc_i)
            equil_per_cell.append(cell_equilibrium_i)

        cell_concentrations = AerationTowerVCCellConcentrations(
            numcel=num_cells,
            timestamps=timesteps,
            liquid=np.concatenate([liquid_con_per_cell]),
            gas=np.concatenate([gas_con_per_cell]),
            equilibrium=np.concatenate([equil_per_cell]),
        )

        output_wq_params = ListWaterQualityParams(
            timestamps=timesteps, wqparams=out_wqps
        )

        return {
            "out_wqparams": output_wq_params,
            "ode_solution": solution,
            "ode_df": ode_df,
            "add_results": cell_concentrations,
            # "input_water_quality": input_water_quality_matrix,
            # "process_parameters": process_parameters,
            # "initial_states": initial_states,
        }

    def __unpack_state_variables(self, y: NDArray[np.float64]) -> dict:
        """Returns state variables in a dictionary.

        Returns:
        dict: {
            'liquid': list
            'gas': list
        }
        """
        state_vars = {
            stype: y[self.s_idxs[stype]["start"] : self.s_idxs[stype]["end"]]
            for stype in self.s_idxs.keys()
        }
        return state_vars

    def __create_ode_column_names(self) -> List[str]:
        """Returns column names for ode solution."""
        states = ["liquid", "gas"]
        column_names = []
        for state in states:
            for cell in range(self.params.numcel):
                column_names.append(f"{state}_{cell}")

        return ["timestamp"] + column_names

    def __calculate_cell_residence_time(
        self, time_index: int, in_wp: ListWaterQualityParams
    ) -> float:
        """Returns the cell residence time in seconds"""
        num_cells = self.params.numcel
        tower_height = self.params.hoogte  # Tower height [m]
        tower_diameter = self.params.diam  # Tower diameter [m]
        water_flow = in_wp[time_index].flow  # [m³/h]

        # System configuration and calculations
        water_flow_m3s = water_flow / 3600  # Convert from m³/h to m³/s
        tower_cross_section = 0.25 * np.pi * (tower_diameter**2)  # [m²]
        total_residence_time = tower_height / (
            water_flow_m3s / tower_cross_section
        )  # [s]
        cell_residence_time = total_residence_time / num_cells  # [s]

        return cell_residence_time
