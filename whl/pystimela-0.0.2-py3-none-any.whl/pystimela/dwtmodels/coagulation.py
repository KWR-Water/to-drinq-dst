"""Coagulation process - December 2024
 It updates the following water quality parameters: Suspended.solids, DOC, UV254, Conductivity, pH, Mnumber
"""
# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Sedimentation_and_flotation/Coagulation/coagul_s.m
import logging
import math
from typing import List
from copy import deepcopy


from pystimela.datatypes import (
    CoagulationParams,
    WaterQualityParams,
    CoagulationDosage,
    ListWaterQualityParams,
)
from pystimela.toolbox import carbacideq as ce
from pystimela.toolbox import waterparams as wpf

logger = logging.getLogger(__name__)


class Coagulation(object):
    """Class for simulating the Coagulation process in a Drinking Water
    Treatment plant. The main implamentation is based on Stimela Software.
    """

    def __init__(self, params: CoagulationParams):
        self.params = params

    def simulate(
        self, dosage: List[CoagulationDosage], in_wp: ListWaterQualityParams
    ) -> ListWaterQualityParams:
        """Returns the output water parameters downstream of the coagulation process.
        :param dosage: The dosages of the coagulants used
        :param in_wp: Input water quality parameters
        """
        output_wq: List[WaterQualityParams] = []
        for i, wq in enumerate(in_wp):
            _out = self.model(dosage=dosage[i], in_wp=wq)
            output_wq.append(_out)
        return ListWaterQualityParams(timestamps=in_wp.timestamps, wqparams=output_wq)

    def model(
        self, dosage: CoagulationDosage, in_wp: WaterQualityParams
    ) -> WaterQualityParams:
        """Returns the output water parameters downstream of the coagulation process.
        :param dosage: The dosages of the coagulants used
        :param in_wp: Input water quality parameters
        """
        out_wp = deepcopy(in_wp)
        # setup of initial values
        ph_in = in_wp.ph
        conductivity_in = in_wp.conductivity
        mnumber_in = in_wp.mnumber
        ionic_strenth_in = wpf.calc_ionic_strenght(conductivity=conductivity_in)
        # Shear Rate and Mixing
        shear_rate = wpf.calc_shear_rate(in_wp.temperature, self.params.g10)

        activity = ce.calc_activity(ionic_strength=ionic_strenth_in)
        kvalues = ce.calc_k_values(temp=in_wp.temperature)

        # co2_in = ce.ce_phm_co2(ph=ph_in, mn=mnumber_in, kv=kvalues, activity=activity)
        co3_in = ce.ce_phm_co3(ph=ph_in, mn=mnumber_in, kv=kvalues, activity=activity)
        hco3_in = ce.ce_phm_hco3(ph=ph_in, mn=mnumber_in, kv=kvalues, activity=activity)
        pn_in = ce.ce_phm_p(ph=ph_in, mn=mnumber_in, kv=kvalues, activity=activity)
        h3o_in = ce.ce_h3o(ph=ph_in, activity=activity)
        oh_in = kvalues.kw / (activity**2 * h3o_in)
        ib_in = ionic_strenth_in - (hco3_in / 2 + 2 * co3_in + h3o_in / 2 + oh_in / 2)

        # calculate parameters of the next step
        ib_out = ib_in + 6 * dosage.fecl3 + 15 * dosage.fe2so43 + 15 * dosage.al2so43
        pn_out = pn_in - 3 * dosage.fecl3 - 3 * dosage.fe2so43 - 3 * dosage.al2so43
        mnumber_out = self.__give_output_mnumber(
            dosage=dosage, initial_mnumber=mnumber_in
        )
        ph_mid = ce.ce_mp_ph(
            m=mnumber_out, p=pn_out, kv=kvalues, activity=activity, ph0=7
        )
        # co2_mid = ce.ce_phm_co2(
        #    ph=ph_mid, mn=mnumber_out, kv=kvalues, activity=activity
        # )
        co3_mid = ce.ce_phm_co3(
            ph=ph_mid, mn=mnumber_out, kv=kvalues, activity=activity
        )
        hco3_mid = ce.ce_phm_hco3(
            ph=ph_mid, mn=mnumber_out, kv=kvalues, activity=activity
        )
        h3o_mid = ce.ce_h3o(ph=ph_mid, activity=activity)
        oh_mid = kvalues.kw / (activity**2 * h3o_mid)
        ionic_strenth_mid = ib_out + (
            2 * co3_mid + hco3_mid / 2 + h3o_mid / 2 + oh_mid / 2
        )

        activity_out = ce.calc_activity(ionic_strength=ionic_strenth_mid)

        ph_out = ce.ce_mp_ph(
            m=mnumber_out, p=pn_out, kv=kvalues, activity=activity_out, ph0=7
        )
        # co2_out = ce.ce_phm_co2(
        #    ph=ph_out, mn=mnumber_out, kv=kvalues, activity=activity_out
        # )
        co3_out = ce.ce_phm_co3(
            ph=ph_out, mn=mnumber_out, kv=kvalues, activity=activity_out
        )
        hco3_out = ce.ce_phm_hco3(
            ph=ph_out, mn=mnumber_out, kv=kvalues, activity=activity_out
        )
        h3o_out = ce.ce_h3o(ph=ph_out, activity=activity_out)
        oh_out = kvalues.kw / (activity_out**2 * h3o_out)
        ionic_strenth_out = ib_out + (
            2 * co3_out + hco3_out / 2 + h3o_out / 2 + oh_out / 2
        )

        out_wp.conductivity = wpf.calc_conductivity(ionic_strenght=ionic_strenth_out)

        out_wp.suspended_solids = self.__give_output_suspended_solids(
            suspended_solids=in_wp.suspended_solids,
            dosage=dosage,
            shear_rate=shear_rate,
            flow=in_wp.flow,
        )
        out_wp.doc = self.__give_output_doc(in_wp=in_wp, dosage=dosage, ph=ph_out)
        out_wp.uv254 = (out_wp.doc / in_wp.doc) * in_wp.uv254
        out_wp.ph = ph_out
        out_wp.mnumber = mnumber_out

        return out_wp

    def __give_output_suspended_solids(
        self,
        suspended_solids: float,
        dosage: CoagulationDosage,
        shear_rate: float,
        flow: float,
    ) -> float:
        """Return the suspended solids of output water from the coagulation process."""
        flow_per_min = flow / 3600
        return (
            (
                1
                + dosage.total_dosage
                * self.params.kb
                * shear_rate**2
                * (self.params.volume / flow_per_min)
            )
            / (
                1
                + dosage.total_dosage
                * self.params.ka
                * shear_rate
                * (self.params.volume / flow_per_min)
            )
        ) * suspended_solids

    def __give_output_mnumber(
        self, dosage: CoagulationDosage, initial_mnumber: float
    ) -> float:
        """Return the M Alcalinity of output water from the coagulation process."""
        return (
            initial_mnumber - 3 * dosage.fecl3 - 3 * dosage.fe2so43 - 3 * dosage.al2so43
        )

    def __give_output_doc(
        self,
        in_wp: WaterQualityParams,
        dosage: CoagulationDosage,
        ph=float,
    ) -> float:
        """Return the DOC in output water from coagulation process"""
        suv_in = in_wp.uv254 / in_wp.doc
        fn_in = self.params.k1 * suv_in + self.params.k2
        doc_ads_out = (1 - fn_in) * in_wp.doc

        a = self.params.calc_a(ph=ph)
        c1 = 1 - self.params.b * doc_ads_out + dosage.total_dosage * a * self.params.b
        c2 = c1**2 + 4 * self.params.b * doc_ads_out
        c3 = math.sqrt(c2)
        ceq = (c1 - c3) / (-2 * self.params.b)
        return ceq + fn_in * in_wp.doc


class CoagulationSimplified(object):
    """A simplified Class for simulating the Coagulation process in a Drinking Water
    Treatment plant but only the Suspended solids are taken into account.
    The main implamentation is based on Stimela Software.
    """

    def __init__(self, params: CoagulationParams):
        self.params = params

    def simulate(
        self, dosage: List[CoagulationDosage], in_wp: ListWaterQualityParams
    ) -> ListWaterQualityParams:
        """Returns the output water parameters downstream of the coagulation process.
        :param dosage: The dosages of the coagulants used
        :param in_wp: Input water quality parameters
        """
        output_wq: List[WaterQualityParams] = []
        for i, wq in enumerate(in_wp):
            _out = self.model(dosage=dosage[i], in_wp=wq)
            output_wq.append(_out)
        return ListWaterQualityParams(timestamps=in_wp.timestamps, wqparams=output_wq)

    def model(
        self, dosage: CoagulationDosage, in_wp: WaterQualityParams
    ) -> WaterQualityParams:
        """Returns the output water parameters downstream of the coagulation process.
        :param dosage: The dosages of the coagulants used
        :param in_wp: Input water quality parameters
        """
        out_wp = deepcopy(in_wp)
        # setup of initial values
        # Shear Rate and Mixing
        shear_rate = wpf.calc_shear_rate(in_wp.temperature, self.params.g10)

        out_wp.suspended_solids = self.__give_output_suspended_solids(
            suspended_solids=in_wp.suspended_solids,
            dosage=dosage,
            shear_rate=shear_rate,
            flow=in_wp.flow,
        )

        return out_wp

    def __give_output_suspended_solids(
        self,
        suspended_solids: float,
        dosage: CoagulationDosage,
        shear_rate: float,
        flow: float,
    ) -> float:
        """Return the suspended solids of output water from the coagulation process."""
        flow_per_min = flow / 3600
        return (
            (
                1
                + dosage.total_dosage
                * self.params.kb
                * shear_rate**2
                * (self.params.volume / flow_per_min)
            )
            / (
                1
                + dosage.total_dosage
                * self.params.ka
                * shear_rate
                * (self.params.volume / flow_per_min)
            )
        ) * suspended_solids
