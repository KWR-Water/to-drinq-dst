# Packed tower aeration (torbk2) - April 2025

# Comparison with Stimela outputs: all matlab outputs are smoother, but lead to the same result.    I checked the function with George and we produce the same with matlab.
# The code has been checked for MeeTe=0.

# It updates the following water quality parameters: Oxygen, Methane, Dissolved carbon dioxide (CO₂), M-number/alkalinity, pH, Dissolved nitrogen (N₂,), Dissolved hydrogen sulfide (H₂S)

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Aeration/Tower_aerator/torbk2_d.m

# The model requires as (water quality) inputs:
# temperature [degree C] #
# flow [m3/h] #
# influent concentration O2    [mg/l]
# influent concentration CH4   [mg/l]
# influent concentration HCO3  [mg/l]
# influent pH [-] #
# influent Conductivity [mS/m] #
# influent concentratie Fe2+  [mg/l]
# influent concentratie Fe3+  [mg/l]
# influent concentratie Ca2+  [mg/l]
# influent concentration N2    [mg/l]
# influent concentration H2S   [mg/l]

# It requires as process parameters:
# 'Hoogte',  '2.6',    0,     [], 'm',    'Heigth of the packed bed'
# 'Diam',      '1',        0,  [], 'm',    'Diameter of the packed bed'
# 'QgTot',  '2000',    0,  [], 'm^3/h',    'Total air flow'
# 'MeeTe',     '0',    {'Cocurrent','Countercurrent','Completely mixed air'},   {'1','0','2'}, '-', 'Flow direction','select'
# 'k2',     '0.05',    0,  [], '1/s',    'Gas transfer coëfficiënt (k_2) for methane'
# 'NumCel',    '5',    0,  [], '-',    'Number of completely mixed reactors'
# 'PercFe',    '4',    0,  [], '%',    'During aeration oxidated iron'
# 'PercCa',    '2',    0,  [], '%',    'During aeration converted calcium'


import logging
from copy import deepcopy
from typing import List, Dict
from numpy.typing import NDArray
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

from pystimela.datatypes import (
    AerationTowerParams,
    ListWaterQualityParams,
    AerationTowerState,
    AerationTowerCellConcentrations,
)
from pystimela.helpers.common import (
    find_interval,
    create_flow_mixing_matrix,
    create_percipitation_oxidation_matrix,
)
from pystimela.toolbox import carbacideq as cbe
from pystimela.toolbox import constants_library as cl
from pystimela.toolbox import aeration_functions as af

logger = logging.getLogger(__name__)


class AerationTower(object):
    def __init__(self, params: AerationTowerParams):
        self.params = params
        num_cel = self.params.numcel
        flow_direction = self.params.meetee
        self.liquids: List = ["O2", "CH4", "CO2", "Mn", "N2", "H2S"]
        self.gases: List = ["O2", "CH4", "CO2", "N2", "H2S"]
        # lookup dict for the state indexes
        if flow_direction in ["cocurrent", "countercurrent"]:
            self.s_idxs: Dict = {
                "liquid": {
                    "O2": {"start": 0, "end": num_cel},
                    "CH4": {"start": 2 * num_cel, "end": 3 * num_cel},
                    "CO2": {"start": 4 * num_cel, "end": 5 * num_cel},
                    "N2": {"start": 12 * num_cel, "end": 13 * num_cel},
                    "H2S": {"start": 14 * num_cel, "end": 15 * num_cel},
                },
                "gas": {
                    "O2": {"start": num_cel, "end": 2 * num_cel},
                    "CH4": {"start": 3 * num_cel, "end": 4 * num_cel},
                    "CO2": {"start": 5 * num_cel, "end": 6 * num_cel},
                    "N2": {"start": 13 * num_cel, "end": 14 * num_cel},
                    "H2S": {"start": 15 * num_cel, "end": 16 * num_cel},
                },
                "other": {
                    "HCO3": {"start": 7 * num_cel, "end": 8 * num_cel},
                    "Fe3": {"start": 9 * num_cel, "end": 10 * num_cel},
                    "CaCO3": {"start": 11 * num_cel, "end": 12 * num_cel},
                    "cStap_1": {"start": 6 * num_cel, "end": 7 * num_cel},
                    "FDT": {
                        "start": 8 * num_cel,
                        "end": 9 * num_cel,
                    },  # Fast Decay Term for iron
                    "FDT1": {
                        "start": 10 * num_cel,
                        "end": 11 * num_cel,
                    },  # Fast Decay Term for Calcium
                },
            }
            self.ode_idx = self.s_idxs
        else:
            self.s_idxs = {
                "liquid": {
                    "O2": {"start": 0, "end": num_cel},
                    "CH4": {"start": num_cel, "end": 2 * num_cel},
                    "CO2": {"start": 2 * num_cel, "end": 3 * num_cel},
                    "N2": {"start": 3 * num_cel, "end": 4 * num_cel},
                    "H2S": {"start": 4 * num_cel, "end": 5 * num_cel},
                },
                "gas": {
                    "O2": {"start": 5 * num_cel, "end": 5 * num_cel + 1},
                    "CH4": {"start": 5 * num_cel + 1, "end": 5 * num_cel + 2},
                    "CO2": {"start": 5 * num_cel + 2, "end": 5 * num_cel + 3},
                    "N2": {"start": 5 * num_cel + 3, "end": 5 * num_cel + 4},
                    "H2S": {"start": 5 * num_cel + 4, "end": 5 * num_cel + 5},
                },
                "other": {
                    "HCO3": {"start": 6 * num_cel + 5, "end": 7 * num_cel + 5},
                    "Fe3": {"start": 8 * num_cel + 5, "end": 9 * num_cel + 5},
                    "CaCO3": {"start": 10 * num_cel + 5, "end": 11 * num_cel + 5},
                    "cStap_1": {"start": 5 * num_cel + 5, "end": 6 * num_cel + 5},
                    "FDT": {
                        "start": 7 * num_cel + 5,
                        "end": 8 * num_cel + 5,
                    },  # Fast Decay Term for Iron
                    "FDT1": {
                        "start": 9 * num_cel + 5,
                        "end": 10 * num_cel + 5,
                    },  # Fast Decay Term for Calcium
                },
            }
            self.ode_idx = self.s_idxs
            # self.ode_idx = {
            #     "liquid": {
            #         "O2": {"start": 0, "end": num_cel},
            #         "CH4": {"start": num_cel + 1, "end": 2 * num_cel + 1},
            #         "CO2": {"start": 2 * num_cel + 2, "end": 3 * num_cel + 2},
            #         "N2": {"start": 9 * num_cel + 3, "end": 10 * num_cel + 3},
            #         "H2S": {"start": 10 * num_cel + 4, "end": 11 * num_cel + 4},
            #     },
            #     "gas": {
            #         "O2": {"start": num_cel, "end": num_cel + 1},
            #         "CH4": {"start": 2 * num_cel + 1, "end": 2 * num_cel + 2},
            #         "CO2": {"start": 3 * num_cel + 2, "end": 3 * num_cel + 3},
            #         "N2": {"start": 10 * num_cel + 3, "end": 10 * num_cel + 4},
            #         "H2S": {"start": 11 * num_cel + 4, "end": 11 * num_cel + 5},
            #     },
            #     "other": {
            #         "HCO3": {"start": 4 * num_cel + 3, "end": 5 * num_cel + 3},
            #         "Fe3": {"start": 6 * num_cel + 3, "end": 7 * num_cel + 3},
            #         "CaCO3": {"start": 8 * num_cel + 3, "end": 9 * num_cel + 3},
            #         "cStap_1": {"start": 3 * num_cel + 3, "end": 4 * num_cel + 3},
            #         "FDT": {
            #             "start": 5 * num_cel + 3,
            #             "end": 6 * num_cel + 3,
            #         },  # Fast Decay Term for Iron
            #         "FDT1": {
            #             "start": 7 * num_cel + 3,
            #             "end": 8 * num_cel + 3,
            #         },  # Fast Decay Term for Calcium
            #     },
            # }

    def model(
        self, time: float, y: NDArray[np.float64], in_wp: ListWaterQualityParams
    ) -> List[float]:
        """
        Simulates a cascaded aeration system for water treatment

        Args:
            time: Current simulation time
            y: Current system state vector
            process_params: Dictionary of process parameters
            input_water_quality: Dictionary of input water quality measurements

        Returns:
            numpy array with derivatives for the state variables
        """

        operation_mode = self.params.meetee  # Operation mode selector

        # Input water quality parameters with time interpolation
        timesteps = in_wp.timestamps
        time_index = find_interval(time, timesteps)

        # air_water_ratio = total_air_flow / water_flow_m3s  # [-]

        cell_residence_time = self.__calculate_cell_residence_time(time_index, in_wp)
        state_vars = self.__unpack_state_variables(y)

        match operation_mode:
            case "cocurrent":
                return self.__calculate_derivatives_open_system(
                    state_vars=state_vars,
                    time_index=time_index,
                    cell_residence_time=cell_residence_time,
                    in_wp=in_wp,
                )
            case "countercurrent":
                return self.__calculate_derivatives_alt_config(
                    state_vars=state_vars,
                    time_index=time_index,
                    cell_residence_time=cell_residence_time,
                    in_wp=in_wp,
                )
            case "mixed_air":
                return self.__calculate_derivatives_simple_config(
                    state_vars=state_vars,
                    time_index=time_index,
                    cell_residence_time=cell_residence_time,
                    in_wp=in_wp,
                )

    def solve_ode(
        self, t_eval: List[float], initial_state, in_wp: ListWaterQualityParams
    ):
        """Solves the ode."""
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, in_wp),
            t_span,
            initial_state,
            method="BDF",
            t_eval=t_eval,
            rtol=1e-6,
            atol=1e-9,
        )
        return solution

    def convert_model_output_to_df(self, model_output: List[float]):
        new_columns = self.__create_ode_column_names()
        df = pd.DataFrame(
            [model_output], columns=new_columns[1:]
        )  # remove timestamp column
        return df

    def simulate(
        self,
        t_eval,
        init_state: AerationTowerState,
        wq_params: ListWaterQualityParams,
    ) -> dict:
        """
        Simulates a cascaded aeration system over time

        Args:
            time_steps: Array of time points for simulation
            initial_state: Initial state vector for the system
            wq_params: List of input water quality measurements

        Returns:
            Dictionary containing simulation results and additional outputs
        """
        # Prepare output water quality empty list
        out_wqps = []
        timesteps = wq_params.timestamps

        # Solve the ODE system
        solution = self.solve_ode(t_eval, init_state.to_numpy(), wq_params)
        # self.__test_ode_indexing(solution.y)
        ode_df = pd.DataFrame(
            np.concatenate([solution.t.reshape(-1, 1), solution.y.T], axis=1)
        )
        ode_df.columns = pd.Index(self.__create_ode_column_names())

        # Extract process parameters with descriptive names
        num_cells = self.params.numcel  # Number of completely mixed reactors
        iron_oxidation_fraction = self.params.perc_fe / 100  # Fraction of iron oxidized
        calcium_precip_fraction = (
            self.params.perc_ca / 100
        )  # Fraction of calcium precipitated

        total_air_flow = self.params.qg_tot / 3600
        recirculation_air_flow = (
            self.params.qg_rec / 3600
        )  # Recirculation airflow [m³/s]
        vented_air_flow = self.params.qg_vers / 3600  # Vented airflow [m³/s]

        # Extract initial water quality parameters
        initial_water_temp = wq_params[0].temperature  # [°C]
        initial_conductivity = wq_params[0].conductivity  # [mS/m]

        # Temperature and flow calculations
        air_temp = initial_water_temp  # Assume air temperature equals water temperature

        # Molecular weights [mg/mol]
        molecular_weight = cl.MOLECULAR_WEIGHTS_mg_mol

        # calc equalibrium value pk1 and activity coefficient for pH calculation.
        pk1 = af.calc_equalibrium_constants_pk1(initial_water_temp)
        initial_activity_coefficient = cbe.calculate_activity_coefficient(
            charge=1, ion_size=4, conductivity=initial_conductivity
        )

        # Initial concentrations in molar units [mol/m³]
        initial_molar_concentrations = self.__calculate_molar_concentrations(
            time_index=0, in_wp=wq_params
        )

        # Gas concentrations in air [mol/m³]? [mg/m3]? (temperature in Kelvin)
        initial_gas_concentration_in_air = af.calc_gas_concentration_in_air(
            air_temp=air_temp, water_vapor_lookup=True
        )
        # Gas concentrations in air [mol/m³]?
        initial_gas_concentration_in_air_mol = {
            gas: gas_con / cl.MOLECULAR_WEIGHTS_mg_mol[gas]
            for gas, gas_con in initial_gas_concentration_in_air.items()
        }

        # Temperature-dependent distribution coefficients
        initial_distribution_coefficient = (
            af.calc_distribution_coefficients_hendrys_law(water_temp=initial_water_temp)
        )
        initial_cell_residence_time = self.__calculate_cell_residence_time(
            0, in_wp=wq_params
        )
        mixing_matrix = create_flow_mixing_matrix(
            residence_time=initial_cell_residence_time, num_cells=num_cells + 1
        )
        reverse_matrix = np.fliplr(
            np.eye(num_cells)
        )  # Matrix for reversing flow direction

        # Ionic strength and activity coefficient calculation
        # ionic_strength = 0.183 * initial_conductivity
        # activity_coefficient = cbe.calc_activity(ionic_strength=ionic_strength)

        liquid_concentrations_per_cell: Dict[str, List] = {el: [] for el in self.gases}
        gas_concentrations_per_cell: Dict[str, List] = {el: [] for el in self.gases}
        equilibrium_per_cell: Dict[str, List] = {el: [] for el in self.gases}
        ph_per_cell = []
        hco3_per_cell = []
        cstap1_per_cell = []
        fe2_per_cell = []
        fe3_per_cell = []
        ca2_per_cell = []
        caco3_per_cell = []

        for i, in_wp in enumerate(wq_params):
            # Calculate output Water Quality parameters
            out_wqp = deepcopy(in_wp)
            # take values from the last cell and convert units to mg/lt
            out_wqp.oxygen = (
                solution.y[self.ode_idx["liquid"]["O2"]["end"] - 1, i]
                * molecular_weight["O2"]
            )
            out_wqp.methane = (
                solution.y[self.ode_idx["liquid"]["CH4"]["end"] - 1, i]
                * molecular_weight["CH4"]
            )
            out_wqp.carbon_dioxide = (
                solution.y[self.ode_idx["liquid"]["CO2"]["end"] - 1, i]
                * molecular_weight["CO2"]
            )
            out_wqp.bicarbonate = (
                solution.y[self.ode_idx["other"]["HCO3"]["end"] - 1, i]
                * molecular_weight["HCO3"]
            )

            out_wqp.nitrogen = (
                solution.y[self.ode_idx["liquid"]["N2"]["end"] - 1, i]
                * molecular_weight["N2"]
            )
            out_wqp.hydrogen_sulfide = (
                solution.y[self.ode_idx["liquid"]["H2S"]["end"] - 1, i]
                * molecular_weight["H2S"]
            )
            out_wqp.iron2 = (
                initial_molar_concentrations["Fe2"] * (1 - iron_oxidation_fraction)
                + solution.y[self.ode_idx["other"]["FDT"]["end"] - 1, i]
            ) * molecular_weight["Fe"]
            out_wqp.iron3 = (
                solution.y[self.ode_idx["other"]["Fe3"]["end"] - 1, i]
                * molecular_weight["Fe"]
            )
            out_wqp.calcium = (
                initial_molar_concentrations["Ca2"] * (1 - calcium_precip_fraction)
                + solution.y[self.ode_idx["other"]["FDT1"]["end"] - 1, i]
            ) * molecular_weight["Ca"]
            # Update pH values based on simulation results
            solution_co2 = solution.y[self.ode_idx["liquid"]["CO2"]["end"] - 1, i]
            solution_hco3 = solution.y[self.ode_idx["other"]["HCO3"]["end"] - 1, i]
            # print(f"solution_co2: {solution_co2}, solution_hco3: {solution_hco3}")
            out_wqp.ph = (
                pk1
                - np.log10(solution_co2)
                + np.log10(solution_hco3) * initial_activity_coefficient
            )
            out_wqps.append(out_wqp)

            # Extract current water quality parameters
            #  and Convert all concentrations to molar units [mol/m³]
            current_molar = self.__calculate_molar_concentrations(i, in_wp=wq_params)
            current_molar["CO2"] = initial_molar_concentrations["CO2"]
            # Calc Concentrations per cell
            liquid_conc_i = {
                el: molecular_weight[el]
                * np.concatenate(
                    [
                        [current_molar[el]],
                        solution.y[
                            self.ode_idx["liquid"][el]["start"] : self.ode_idx[
                                "liquid"
                            ][el]["end"],
                            i,
                        ],  # replace the value of the first cell
                    ],
                )
                for el in self.gases
            }
            match self.params.meetee:
                case "cocurrent":
                    gas_conc_i = {
                        el: molecular_weight[el]
                        * np.concatenate(
                            [
                                [
                                    initial_gas_concentration_in_air_mol[el]
                                    * (vented_air_flow / total_air_flow)
                                    + (recirculation_air_flow / total_air_flow)
                                    * solution.y[self.ode_idx["gas"][el]["end"] - 1, i]
                                ],  # transform the first cell value
                                solution.y[
                                    self.ode_idx["gas"][el]["start"] : self.ode_idx[
                                        "gas"
                                    ][el]["end"],
                                    i,
                                ],
                            ]
                        )
                        for el in self.gases
                    }

                case "countercurrent":
                    gas_conc_i = {
                        el: molecular_weight[el]
                        * np.concatenate(
                            [
                                reverse_matrix
                                @ solution.y[
                                    self.ode_idx["gas"][el]["start"] : self.ode_idx[
                                        "gas"
                                    ][el]["end"],
                                    i,
                                ],
                                [
                                    initial_gas_concentration_in_air_mol[el]
                                    * (vented_air_flow / total_air_flow)
                                    + solution.y[self.ode_idx["gas"][el]["end"] - 1, i]
                                    * (recirculation_air_flow / total_air_flow)
                                ],
                            ]
                        )
                        for el in self.gases
                    }
                case "mixed_air":
                    gas_conc_i = {
                        el: molecular_weight[el]
                        * np.concatenate(
                            [
                                [
                                    initial_gas_concentration_in_air_mol[el]
                                    * vented_air_flow
                                    / total_air_flow
                                    + recirculation_air_flow
                                    / total_air_flow
                                    * solution.y[
                                        self.ode_idx["gas"][el]["start"] - 1, i
                                    ]
                                ],  # transform the first cell value
                                np.ones(num_cells)
                                * solution.y[self.ode_idx["gas"][el]["start"] - 1, i],
                            ]
                        )
                        for el in self.gases
                    }

            equilbrium_i = {
                el: initial_distribution_coefficient[el] * gas_conc_i[el]
                for el in self.gases
            }

            # store the values of the i time index
            for el in self.gases:
                liquid_concentrations_per_cell[el].append(liquid_conc_i[el])
                gas_concentrations_per_cell[el].append(gas_conc_i[el])
                equilibrium_per_cell[el].append(equilbrium_i[el])

            # cStap calculations,  d make a pad
            # with size 1 at the end of the array with the same value as the last cell
            cstap1_i = mixing_matrix @ np.concatenate(
                [
                    [1.0],
                    solution.y[
                        self.ode_idx["other"]["cStap_1"]["start"] : self.ode_idx[
                            "other"
                        ]["cStap_1"]["end"],
                        i,
                    ],
                    [solution.y[self.ode_idx["other"]["cStap_1"]["end"] - 1, i]],
                ]
            )
            cstap1_per_cell.append(cstap1_i)
            # pH calc. In calculations we replace the value of the first cell with the current liquid CO2 molar concentration.
            ph_i = pk1 * np.ones(num_cells + 1) - np.log10(
                np.concatenate(
                    [
                        [current_molar["CO2"]],
                        solution.y[
                            self.ode_idx["liquid"]["CO2"]["start"] : self.ode_idx[
                                "liquid"
                            ]["CO2"]["end"],
                            i,
                        ],
                    ]
                )
                + np.log10(
                    np.concatenate(
                        [
                            [in_wp.bicarbonate],
                            solution.y[
                                self.ode_idx["other"]["HCO3"]["start"] : self.ode_idx[
                                    "other"
                                ]["HCO3"]["end"],
                                i,
                            ]
                            * cbe.calculate_activity_coefficient(
                                1, 4, in_wp.conductivity
                            ),
                        ]
                    )
                )
            )
            ph_per_cell.append(ph_i)

            # HCO3 calculations per cell, replace the value of the 1st cell
            # with current concentration
            hco3_i = molecular_weight["HCO3"] * np.concatenate(
                [
                    [in_wp.bicarbonate],
                    solution.y[
                        self.ode_idx["other"]["HCO3"]["start"] : self.ode_idx["other"][
                            "HCO3"
                        ]["end"],
                        i,
                    ],
                ]
            )
            hco3_per_cell.append(hco3_i)

            # Fe2 calcs
            fe2_i = molecular_weight["Fe"] * (
                np.concatenate(
                    [
                        initial_molar_concentrations["Fe"] * np.ones(num_cells + 1)
                        + in_wp.iron2
                        * (1 - iron_oxidation_fraction)
                        * np.ones(num_cells + 1)
                    ]
                )
                - np.concatenate(
                    [
                        [in_wp.iron3],
                        solution.y[
                            self.ode_idx["other"]["Fe3"]["start"] : self.ode_idx[
                                "other"
                            ]["Fe3"]["end"],
                            i,
                        ],
                    ]
                )
                + in_wp.iron3 * np.array(num_cells + 1)
            )
            fe2_per_cell.append(fe2_i)

            fe3_i = molecular_weight["Fe"] * np.concatenate(
                [
                    [in_wp.iron3],
                    solution.y[
                        self.ode_idx["other"]["Fe3"]["start"] : self.ode_idx["other"][
                            "Fe3"
                        ]["end"],
                        i,
                    ],
                ]
            )

            fe3_per_cell.append(fe3_i)

            # Ca and CaCO3
            ca_i = molecular_weight["Ca"] * (
                np.concatenate([in_wp.calcium * np.ones(num_cells + 1)])
                - np.concatenate(
                    [
                        [current_molar["CaCO3"]],
                        solution.y[
                            self.ode_idx["other"]["CaCO3"]["start"] : self.ode_idx[
                                "other"
                            ]["CaCO3"]["end"],
                            i,
                        ],
                    ]
                )
                + current_molar["CaCO3"] * np.ones(num_cells + 1)
            )
            ca2_per_cell.append(ca_i)

            caco3_i = molecular_weight["Ca"] * np.concatenate(
                [
                    [current_molar["CaCO3"]],
                    solution.y[
                        self.ode_idx["other"]["CaCO3"]["start"] : self.ode_idx["other"][
                            "CaCO3"
                        ]["end"],
                        i,
                    ],
                ]
            )
            caco3_per_cell.append(caco3_i)
        # Prepare final output structure
        cell_concentrations = AerationTowerCellConcentrations(
            numcel=self.params.numcel,
            timestamps=timesteps,
            o2_liquid=np.concatenate([liquid_concentrations_per_cell["O2"]]),
            ch4_liquid=np.concatenate([liquid_concentrations_per_cell["CH4"]]),
            co2_liquid=np.concatenate([liquid_concentrations_per_cell["CO2"]]),
            n2_liquid=np.concatenate([liquid_concentrations_per_cell["N2"]]),
            h2s_liquid=np.concatenate([liquid_concentrations_per_cell["H2S"]]),
            o2_gas=np.concatenate([gas_concentrations_per_cell["O2"]]),
            ch4_gas=np.concatenate([gas_concentrations_per_cell["CH4"]]),
            co2_gas=np.concatenate([gas_concentrations_per_cell["CO2"]]),
            n2_gas=np.concatenate([gas_concentrations_per_cell["N2"]]),
            h2s_gas=np.concatenate([gas_concentrations_per_cell["H2S"]]),
            o2_equilibrium=np.concatenate([equilibrium_per_cell["O2"]]),
            ch4_equilibrium=np.concatenate([equilibrium_per_cell["CH4"]]),
            co2_equilibrium=np.concatenate([equilibrium_per_cell["CO2"]]),
            n2_equilibrium=np.concatenate([equilibrium_per_cell["N2"]]),
            h2s_equilibrium=np.concatenate([equilibrium_per_cell["H2S"]]),
            ph=np.concatenate([ph_per_cell]),
            hco3=np.concatenate([hco3_per_cell]),
            cstap1=np.concatenate([cstap1_per_cell]),
            fe2=np.concatenate([fe2_per_cell]),
            fe3=np.concatenate([fe3_per_cell]),
            ca2=np.concatenate([ca2_per_cell]),
            caco3=np.concatenate([caco3_per_cell]),
        )

        output_wq_params = ListWaterQualityParams(
            timestamps=timesteps, wqparams=out_wqps
        )

        return {
            "out_wqparams": output_wq_params,
            "ode_solution": solution,
            "ode_df": ode_df,
            "add_results": cell_concentrations,
            # "input_water_quality": input_water_quality_matrix,
            # "process_parameters": process_parameters,
            # "initial_states": initial_states,
        }

    def __unpack_state_variables(self, y: NDArray[np.float64]) -> dict:
        """Returns state variables in a dictionary.

        Returns:
        dict: {
            'liquid': {'},
            'gas': Ca percipitation profile vector,
            'other': CaCO3 percipitation profile vector
        }
        """
        state_vars = {
            stype: {
                el: y[self.s_idxs[stype][el]["start"] : self.s_idxs[stype][el]["end"]]
                for el in self.s_idxs[stype].keys()
            }
            for stype in self.s_idxs.keys()
        }
        return state_vars

    def __create_ode_column_names(self) -> List[str]:
        """Returns column names for ode solution."""
        states = ["liquid", "gas"]
        first_elements = ["o2", "ch4", "co2"]
        second_elements = ["n2", "h2s"]
        other_elements = ["cstap", "hco3", "fdt", "fe3", "fdt1", "caco3"]
        column_names: List[str] = []
        if self.params.meetee in ["cocurrent", "countercurrent"]:
            for el in first_elements:
                for state in states:
                    for cell in range(1, self.params.numcel + 1):
                        column_names.append(f"{el}_{state}_{cell}")
            for other in other_elements:
                for cell in range(1, self.params.numcel + 1):
                    column_names.append(f"{other}_{cell}")
            for el in second_elements:
                for state in states:
                    for cell in range(1, self.params.numcel + 1):
                        column_names.append(f"{el}_{state}_{cell}")
        else:
            # simply case/ mixed air
            for el in self.gases:
                for state in states:
                    for cell in range(1, self.params.numcel + 1):
                        column_names.append(f"{el.lower()}_{state}_{cell}")
            for other in other_elements:
                for cell in range(1, self.params.numcel + 1):
                    column_names.append(f"{other}_{cell}")

        return ["timestamp"] + column_names

    def __calculate_cell_residence_time(
        self, time_index: int, in_wp: ListWaterQualityParams
    ) -> float:
        """Returns the cell residence time in seconds"""
        num_cells = self.params.numcel
        tower_height = self.params.hoogte  # Tower height [m]
        tower_diameter = self.params.diam  # Tower diameter [m]
        water_flow = in_wp[time_index].flow  # [m³/h]

        # System configuration and calculations
        water_flow_m3s = water_flow / 3600  # Convert from m³/h to m³/s
        tower_cross_section = 0.25 * np.pi * (tower_diameter**2)  # [m²]
        total_residence_time = tower_height / (
            water_flow_m3s / tower_cross_section
        )  # [s]
        cell_residence_time = total_residence_time / num_cells  # [s]

        return cell_residence_time

    def __calculate_molar_concentrations(
        self, time_index: int, in_wp: ListWaterQualityParams
    ) -> dict:
        """Returns the molar concentrations in dict.

        Returns:
            dict: {
            "HCO3": ,
            "CO2": ,
            "CO3": ,
            "O2": ,
            "CH4": ,
            "N2": ,
            "H2S": ,
            "Fe3": ,
            "Fe2": ,
            "Fe": ,
            "Ca2": ,
            "Ca": ,
            "CaCO3": ,
        }
        """
        iron_oxidation_fraction = self.params.perc_fe / 100  # Fraction of iron oxidized
        calcium_precip_fraction = (
            self.params.perc_ca / 100
        )  # Fraction of calcium precipitated
        water_temp = in_wp[time_index].temperature  # [°C]
        influent_iron2 = in_wp[time_index].iron2  # Fe²⁺ [mg/l]
        influent_iron3 = in_wp[time_index].iron3  # Fe³⁺ [mg/l]
        influent_calcium = in_wp[time_index].calcium  # Ca²⁺ [mg/l]
        influent_nitrogen = in_wp[time_index].nitrogen  # N₂ [mg/l]
        influent_hydrogen_sulfide = in_wp[time_index].hydrogen_sulfide  # H₂S [mg/l]
        influent_oxygen = in_wp[time_index].oxygen  # [mg/l]
        influent_methane = in_wp[time_index].methane  # [mg/l]
        influent_bicarbonate = in_wp[time_index].bicarbonate  # [mg/l]
        influent_conductivity = in_wp[time_index].conductivity  # [mS/m]
        influent_ph = in_wp[time_index].ph  # [-]
        molecular_weight = cl.MOLECULAR_WEIGHTS_mg_mol
        if influent_bicarbonate == 0:
            raise ValueError(
                "The hydrogen carbonate (HCO3) concentration should be greater than 0"
            )

        activity_coefficient = cbe.calculate_activity_coefficient(
            charge=1, ion_size=4, conductivity=influent_conductivity
        )

        # Equilibrium constants
        pk1 = af.calc_equalibrium_constants_pk1(water_temp)
        pk2 = af.calc_equalibrium_constants_pk2(water_temp)

        molar_concentration_hco3 = (
            influent_bicarbonate / molecular_weight["HCO3"]
        ) * activity_coefficient
        molar_concentrations = {
            "HCO3": molar_concentration_hco3 / activity_coefficient,
            "CO2": 10 ** (pk1 - influent_ph + np.log10(molar_concentration_hco3)),
            "CO3": 10 ** (-pk2 + influent_ph + np.log10(molar_concentration_hco3)),
            "O2": influent_oxygen / molecular_weight["O2"],
            "CH4": influent_methane / molecular_weight["CH4"],
            "N2": influent_nitrogen / molecular_weight["N2"],
            "H2S": influent_hydrogen_sulfide / molecular_weight["H2S"],
            "Fe2": influent_iron2 / molecular_weight["Fe"],
            "Fe3": influent_iron3 / molecular_weight["Fe"],
            "Fe": iron_oxidation_fraction * (influent_iron2 / molecular_weight["Fe"]),
            "Ca2": influent_calcium / molecular_weight["Ca"],
            "Ca": calcium_precip_fraction * (influent_calcium / molecular_weight["Ca"]),
            "CaCO3": 0 / molecular_weight["Ca"],  # Assuming initial CaCO3 is 0
        }
        return molar_concentrations

    def __calculate_derivatives_open_system(
        self,
        state_vars: dict,
        time_index: int,
        cell_residence_time: float,
        in_wp=ListWaterQualityParams,
    ) -> List[float]:
        """
        Calculate derivatives for open system operation mode (cocurrent)
        The cascade operates as an open system with continuous air flow (no accumulation of gases in a headspace)
        the cascade is directly exposed to the atmosphere (typical in most aerators).
        """
        num_cells = self.params.numcel
        methane_transfer_coeff = (
            self.params.k2_ch4  # Gas transfer coefficient for methane
        )
        total_air_flow = self.params.qg_tot / 3600  # Total airflow [m³/s]
        recirculation_air_flow = (
            self.params.qg_rec / 3600
        )  # Recirculation airflow [m³/s]
        vented_air_flow = self.params.qg_vers / 3600  # Vented airflow [m³/s]

        # Extract water quality parameters with descriptive names
        water_temp = in_wp[time_index].temperature  # [°C]
        air_temp = round(water_temp)  # Rounded air temperature [°C]
        water_flow = in_wp[time_index].flow  # [m³/h]
        water_flow_m3s = water_flow / 3600  # Convert from m³/h to m³/s
        air_water_ratio = total_air_flow / water_flow_m3s  # [-]

        # Convert concentrations to molar units [mol/m³]
        molar_concentrations = self.__calculate_molar_concentrations(
            time_index=time_index, in_wp=in_wp
        )

        # Gas concentrations in air [mol/m³]? [mg/m3]? (temperature in Kelvin)
        gas_concentration_in_air = af.calc_gas_concentration_in_air(
            air_temp=air_temp, water_vapor_lookup=True
        )
        # Gas concentrations in air [mol/m³]?
        gas_concentration_in_air_mol = {
            gas: gas_con / cl.MOLECULAR_WEIGHTS_mg_mol[gas]
            for gas, gas_con in gas_concentration_in_air.items()
        }

        # Temperature-dependent distribution coefficients
        # by intermediate temperatures by linear interpolation['gas']
        distribution_coefficient = af.calc_distribution_coefficients_hendrys_law(
            water_temp=water_temp
        )

        # Gas transfer coefficients based on methane coefficient for O2, CO2, H2S, N2
        gas_transfer_coefficient = af.calc_gas_transfer_coefficient(
            water_temp=water_temp, methane_transfer_coeff=methane_transfer_coeff
        )

        liquid_mixing_matrix = create_flow_mixing_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )
        iron_oxidation_matrix = create_percipitation_oxidation_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )
        calcium_precip_matrix = create_percipitation_oxidation_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )

        # Prepare iron oxidation and calcium precipitation profiles
        iron_profile = af.create_iron_oxidation_profile(
            num_cells=num_cells,
            iron_concentration=molar_concentrations["Fe"],
            iron3_concentration=molar_concentrations["Fe3"],
            oxidation_rate=3,
        )
        calcium_profile = af.create_calcium_percipitation_profile(
            num_cells=num_cells,
            ca_concentration=molar_concentrations["Ca"],
            caco3_concentration=molar_concentrations["CaCO3"],
            softening_rate=3,
        )
        # Oxygen derivatives
        dO2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate([[molar_concentrations["O2"]], state_vars["liquid"]["O2"]])
            + gas_transfer_coefficient["O2"]
            * distribution_coefficient["O2"]
            * state_vars["gas"]["O2"]
            - gas_transfer_coefficient["O2"] * state_vars["liquid"]["O2"]
            - 0.25
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
        )

        dO2_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["O2"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["O2"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["O2"],
                ]
            )
            - (
                gas_transfer_coefficient["O2"]
                * distribution_coefficient["O2"]
                / air_water_ratio
            )
            * state_vars["gas"]["O2"]
            + (gas_transfer_coefficient["O2"] / air_water_ratio)
            * state_vars["liquid"]["O2"]
        )

        # Methane derivatives
        dCH4_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["CH4"]], state_vars["liquid"]["CH4"]]
            )
            + methane_transfer_coeff
            * distribution_coefficient["CH4"]
            * state_vars["gas"]["CH4"]
            - methane_transfer_coeff * state_vars["liquid"]["CH4"]
        )

        dCH4_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["CH4"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["CH4"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["CH4"],
                ]
            )
            - (
                methane_transfer_coeff
                * distribution_coefficient["CH4"]
                / air_water_ratio
            )
            * state_vars["gas"]["CH4"]
            + (methane_transfer_coeff / air_water_ratio) * state_vars["liquid"]["CH4"]
        )

        # CO2 derivatives['liquid']
        dCO2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["CO2"]], state_vars["liquid"]["CO2"]]
            )
            + gas_transfer_coefficient["CO2"]
            * distribution_coefficient["CO2"]
            * state_vars["gas"]["CO2"]
            - gas_transfer_coefficient["CO2"] * state_vars["liquid"]["CO2"]
            + 2
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
            + calcium_precip_matrix
            @ np.concatenate([calcium_profile["Ca"], state_vars["other"]["FDT1"]])
        )

        dCO2_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["CO2"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["CO2"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["CO2"],
                ]
            )
            - (
                gas_transfer_coefficient["CO2"]
                * distribution_coefficient["CO2"]
                / air_water_ratio
            )
            * state_vars["gas"]["CO2"]
            + (gas_transfer_coefficient["CO2"] / air_water_ratio)
            * state_vars["liquid"]["CO2"]
        )

        # Passive tracer
        dcStap = liquid_mixing_matrix @ np.concatenate(
            [[1], state_vars["other"]["cStap_1"]]
        )

        # Bicarbonate and pH
        dHCO3 = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["HCO3"]], state_vars["other"]["HCO3"]]
            )
            - 2
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
            - 2
            * calcium_precip_matrix
            @ np.concatenate([calcium_profile["Ca"], state_vars["other"]["FDT1"]])
        )

        # Iron oxidation terms
        dFDT = -10 * state_vars["other"]["FDT"]  # Fast decay term

        dFe3 = liquid_mixing_matrix @ np.concatenate(
            [[molar_concentrations["Fe3"]], state_vars["other"]["Fe3"]]
        ) + iron_oxidation_matrix @ np.concatenate(
            [
                self.params.perc_fe / 100 * iron_profile["Fe"],
                state_vars["other"]["FDT"],
            ]
        )

        # Calcium precipitation terms
        dFDT1 = -10 * state_vars["other"]["FDT1"]  # Fast decay term

        dCaCO3 = liquid_mixing_matrix @ np.concatenate(
            [[molar_concentrations["CaCO3"]], state_vars["other"]["CaCO3"]]
        ) + calcium_precip_matrix @ np.concatenate(
            [
                calcium_profile["Ca_precipitated"],
                state_vars["other"]["FDT1"],
            ]
        )

        # Nitrogen derivatives
        dN2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate([[molar_concentrations["N2"]], state_vars["liquid"]["N2"]])
            + gas_transfer_coefficient["N2"]
            * distribution_coefficient["N2"]
            * state_vars["gas"]["N2"]
            - gas_transfer_coefficient["N2"] * state_vars["liquid"]["N2"]
        )

        dN2_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["N2"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["N2"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["N2"],
                ]
            )
            - (
                gas_transfer_coefficient["N2"]
                * distribution_coefficient["N2"]
                / air_water_ratio
            )
            * state_vars["gas"]["N2"]
            + (gas_transfer_coefficient["N2"] / air_water_ratio)
            * state_vars["liquid"]["N2"]
        )

        # Hydrogen sulfide derivatives
        dH2S_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["H2S"]], state_vars["liquid"]["H2S"]]
            )
            + gas_transfer_coefficient["H2S"]
            * distribution_coefficient["H2S"]
            * state_vars["gas"]["H2S"]
            - gas_transfer_coefficient["H2S"] * state_vars["liquid"]["H2S"]
        )

        dH2S_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["H2S"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["H2S"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["H2S"],
                ]
            )
            - (
                gas_transfer_coefficient["H2S"]
                * distribution_coefficient["H2S"]
                / air_water_ratio
            )
            * state_vars["gas"]["H2S"]
            + (gas_transfer_coefficient["H2S"] / air_water_ratio)
            * state_vars["liquid"]["H2S"]
        )

        # Combine all derivatives
        derivatives = np.concatenate(
            [
                dO2_liquid,
                dO2_gas,
                dCH4_liquid,
                dCH4_gas,
                dCO2_liquid,
                dCO2_gas,
                dcStap,
                dHCO3,
                dFDT,
                dFe3,
                dFDT1,
                dCaCO3,
                dN2_liquid,
                dN2_gas,
                dH2S_liquid,
                dH2S_gas,
            ],
        )

        return derivatives.tolist()

    def __calculate_derivatives_simple_config(
        self,
        state_vars: dict,
        time_index: int,
        cell_residence_time: float,
        in_wp=ListWaterQualityParams,
    ) -> List[float]:
        """
        Calculate derivatives for simple configuration co-current (MeeTe=1)
        """
        num_cells = self.params.numcel
        methane_transfer_coeff = (
            self.params.k2_ch4  # Gas transfer coefficient for methane
        )
        total_air_flow = self.params.qg_tot / 3600  # Total airflow [m³/s]
        recirculation_air_flow = (
            self.params.qg_rec / 3600
        )  # Recirculation airflow [m³/s]
        vented_air_flow = (
            total_air_flow - recirculation_air_flow
        )  # Vented airflow [m³/s]

        # Extract water quality parameters with descriptive names
        water_temp = in_wp[time_index].temperature  # [°C]
        air_temp = round(water_temp)  # Rounded air temperature [°C]
        water_flow = in_wp[time_index].flow  # [m³/h]
        water_flow_m3s = water_flow / 3600  # Convert from m³/h to m³/s
        air_water_ratio = total_air_flow / water_flow_m3s  # [-]

        # Convert concentrations to molar units [mol/m³]
        molar_concentrations = self.__calculate_molar_concentrations(
            time_index=time_index, in_wp=in_wp
        )

        # Gas concentrations in air [mol/m³]? [mg/m3]? (temperature in Kelvin)
        gas_concentration_in_air = af.calc_gas_concentration_in_air(
            air_temp=air_temp, water_vapor_lookup=True
        )
        # Gas concentrations in air [mol/m³]?
        gas_concentration_in_air_mol = {
            gas: gas_con / cl.MOLECULAR_WEIGHTS_mg_mol[gas]
            for gas, gas_con in gas_concentration_in_air.items()
        }
        # Temperature-dependent distribution coefficients
        # by intermediate temperatures by linear interpolation['gas']
        distribution_coefficient = af.calc_distribution_coefficients_hendrys_law(
            water_temp=water_temp
        )

        # Gas transfer coefficients based on methane coefficient for O2, CO2, H2S, N2
        gas_transfer_coefficient = af.calc_gas_transfer_coefficient(
            water_temp=water_temp, methane_transfer_coeff=methane_transfer_coeff
        )

        liquid_mixing_matrix = create_flow_mixing_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )
        gas_mixing_matrix = create_flow_mixing_matrix(
            residence_time=cell_residence_time, num_cells=1
        )
        iron_oxidation_matrix = create_percipitation_oxidation_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )
        calcium_precip_matrix = create_percipitation_oxidation_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )

        # Prepare iron oxidation and calcium precipitation profiles
        iron_profile = af.create_iron_oxidation_profile(
            num_cells=num_cells,
            iron_concentration=molar_concentrations["Fe"],
            iron3_concentration=molar_concentrations["Fe3"],
            oxidation_rate=3,
        )
        calcium_profile = af.create_calcium_percipitation_profile(
            num_cells=num_cells,
            ca_concentration=molar_concentrations["Ca"],
            caco3_concentration=molar_concentrations["CaCO3"],
            softening_rate=3,
        )

        # Initialize gas transfer terms array (for O2, CH4, CO2, N2, H2S)
        gas_transfer_terms = np.zeros(5 * num_cells)

        # Calculate gas transfer terms for each cell and component
        for cell in range(num_cells):
            for gas in self.gases:
                if gas == "CH4":
                    gas_transfer_coeff = methane_transfer_coeff
                else:
                    gas_transfer_coeff = gas_transfer_coefficient[gas]

                gas_transfer_terms[cell * num_cells + cell] = (
                    -(
                        gas_transfer_coeff
                        * distribution_coefficient[gas]
                        / air_water_ratio
                    )
                    * state_vars["gas"][gas][0]
                    + (gas_transfer_coeff / air_water_ratio)
                    * state_vars["liquid"][gas][cell]
                )

        # Oxygen liquid phase derivative
        dO2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate([[molar_concentrations["O2"]], state_vars["liquid"]["O2"]])
            + gas_transfer_coefficient["O2"]
            * distribution_coefficient["O2"]
            * state_vars["gas"]["O2"][0]
            - gas_transfer_coefficient["O2"] * state_vars["liquid"]["O2"]
            - 0.25
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
        )

        # Methane liquid phase derivative
        dCH4_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["CH4"]], state_vars["liquid"]["CH4"]]
            )
            + methane_transfer_coeff
            * distribution_coefficient["CH4"]
            * state_vars["gas"]["CH4"][0]
            - methane_transfer_coeff * state_vars["liquid"]["CH4"]
        )

        # CO2 liquid phase derivative (includes iron oxidation and calcium precipitation terms)
        dCO2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["CO2"]], state_vars["liquid"]["CO2"]]
            )
            + gas_transfer_coefficient["CO2"]
            * distribution_coefficient["CO2"]
            * state_vars["gas"]["CO2"][0]
            - gas_transfer_coefficient["CO2"] * state_vars["liquid"]["CO2"]
            + 2
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
            + calcium_precip_matrix
            @ np.concatenate([calcium_profile["Ca"], state_vars["other"]["FDT1"]])
        )

        # Nitrogen liquid phase derivative
        dN2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate([[molar_concentrations["N2"]], state_vars["liquid"]["N2"]])
            + gas_transfer_coefficient["N2"]
            * distribution_coefficient["N2"]
            * state_vars["gas"]["N2"][0]
            - gas_transfer_coefficient["N2"] * state_vars["liquid"]["N2"]
        )

        # Hydrogen sulfide liquid phase derivative
        dH2S_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["H2S"]], state_vars["liquid"]["H2S"]]
            )
            + gas_transfer_coefficient["H2S"]
            * distribution_coefficient["H2S"]
            * state_vars["gas"]["H2S"][0]
            - gas_transfer_coefficient["H2S"] * state_vars["liquid"]["H2S"]
        )

        # Gas phase derivatives (single value for each gas component)
        dO2_gas = gas_mixing_matrix @ np.concatenate(
            [
                [
                    gas_concentration_in_air_mol["O2"]
                    * (vented_air_flow / total_air_flow)
                    + state_vars["gas"]["O2"][0]
                    * (recirculation_air_flow / total_air_flow)
                ],
                state_vars["gas"]["O2"],
            ]
        ) + np.sum(gas_transfer_terms[:num_cells])

        dCH4_gas = gas_mixing_matrix @ np.concatenate(
            [
                [
                    gas_concentration_in_air_mol["CH4"]
                    * (vented_air_flow / total_air_flow)
                    + state_vars["gas"]["CH4"][0]
                    * (recirculation_air_flow / total_air_flow)
                ],
                state_vars["gas"]["CH4"],
            ]
        ) + np.sum(gas_transfer_terms[num_cells : 2 * num_cells])

        dCO2_gas = gas_mixing_matrix @ np.concatenate(
            [
                [
                    gas_concentration_in_air_mol["CO2"]
                    * (vented_air_flow / total_air_flow)
                    + state_vars["gas"]["CO2"][0]
                    * (recirculation_air_flow / total_air_flow)
                ],
                state_vars["gas"]["CO2"],
            ]
        ) + np.sum(gas_transfer_terms[2 * num_cells : 3 * num_cells])

        dN2_gas = gas_mixing_matrix @ np.concatenate(
            [
                [
                    gas_concentration_in_air_mol["N2"]
                    * (vented_air_flow / total_air_flow)
                    + state_vars["gas"]["N2"][0]
                    * (recirculation_air_flow / total_air_flow)
                ],
                state_vars["gas"]["N2"],
            ]
        ) + np.sum(gas_transfer_terms[3 * num_cells : 4 * num_cells])

        dH2S_gas = gas_mixing_matrix @ np.concatenate(
            [
                [
                    gas_concentration_in_air_mol["H2S"]
                    * (vented_air_flow / total_air_flow)
                    + state_vars["gas"]["H2S"][0]
                    * (recirculation_air_flow / total_air_flow)
                ],
                state_vars["gas"]["H2S"],
            ]
        ) + np.sum(gas_transfer_terms[4 * num_cells : 5 * num_cells])

        # Passive tracer derivative
        dcStap = liquid_mixing_matrix @ np.concatenate(
            [[1], state_vars["other"]["cStap_1"]]
        )

        # Bicarbonate and pH derivative
        dHCO3 = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["HCO3"]], state_vars["other"]["HCO3"]]
            )
            - 2
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
            - 2
            * calcium_precip_matrix
            @ np.concatenate([calcium_profile["Ca"], state_vars["other"]["FDT1"]])
        )

        # Iron oxidation terms
        dFDT = -10 * state_vars["other"]["FDT"]  # Fast decay term for iron
        dFe3 = liquid_mixing_matrix @ np.concatenate(
            [[molar_concentrations["Fe3"]], state_vars["other"]["Fe3"]]
        ) + iron_oxidation_matrix @ np.concatenate(
            [iron_profile["Fe"], state_vars["other"]["FDT"]]
        )

        # Calcium precipitation terms
        dFDT1 = -10 * state_vars["other"]["FDT1"]  # Fast decay term for calcium
        dCaCO3 = liquid_mixing_matrix @ np.concatenate(
            [[molar_concentrations["CaCO3"]], state_vars["other"]["CaCO3"]]
        ) + calcium_precip_matrix @ np.concatenate(
            [
                calcium_profile["Ca"],
                state_vars["other"]["FDT1"],
            ]
        )

        # Combine all derivatives into a single array
        derivatives = np.concatenate(
            [
                dO2_liquid,
                dO2_gas,
                dCH4_liquid,
                dCH4_gas,
                dCO2_liquid,
                dCO2_gas,
                dcStap,
                dHCO3,
                dFDT,
                dFe3,
                dFDT1,
                dCaCO3,
                dN2_liquid,
                dN2_gas,
                dH2S_liquid,
                dH2S_gas,
            ],
        )

        return derivatives.tolist()

    def __calculate_derivatives_alt_config(
        self,
        state_vars: dict,
        time_index: int,
        cell_residence_time: float,
        in_wp=ListWaterQualityParams,
    ) -> List[float]:
        """
        Calculate derivatives for alternative configuration counter-current(MeeTe=0)
        """
        num_cells = self.params.numcel
        methane_transfer_coeff = (
            self.params.k2_ch4  # Gas transfer coefficient for methane
        )
        total_air_flow = self.params.qg_tot / 3600  # Total airflow [m³/s]
        recirculation_air_flow = (
            self.params.qg_rec / 3600
        )  # Recirculation airflow [m³/s]
        vented_air_flow = (
            total_air_flow - recirculation_air_flow
        )  # Vented airflow [m³/s]

        # Extract water quality parameters with descriptive names
        water_temp = in_wp[time_index].temperature  # [°C]
        air_temp = round(water_temp)  # Rounded air temperature [°C]
        water_flow = in_wp[time_index].flow  # [m³/h]
        water_flow_m3s = water_flow / 3600  # Convert from m³/h to m³/s
        air_water_ratio = total_air_flow / water_flow_m3s  # [-]

        # Convert concentrations to molar units [mol/m³]
        molar_concentrations = self.__calculate_molar_concentrations(
            time_index=time_index, in_wp=in_wp
        )

        # Gas concentrations in air [mol/m³]? [mg/m3]? (temperature in Kelvin)
        gas_concentration_in_air = af.calc_gas_concentration_in_air(
            air_temp=air_temp, water_vapor_lookup=True
        )
        # Gas concentrations in air [mol/m³]?
        gas_concentration_in_air_mol = {
            gas: gas_con / cl.MOLECULAR_WEIGHTS_mg_mol[gas]
            for gas, gas_con in gas_concentration_in_air.items()
        }
        # Temperature-dependent distribution coefficients
        # by intermediate temperatures by linear interpolation['gas']
        distribution_coefficient = af.calc_distribution_coefficients_hendrys_law(
            water_temp=water_temp
        )

        # Gas transfer coefficients based on methane coefficient for O2, CO2, H2S, N2
        gas_transfer_coefficient = af.calc_gas_transfer_coefficient(
            water_temp=water_temp, methane_transfer_coeff=methane_transfer_coeff
        )

        liquid_mixing_matrix = create_flow_mixing_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )
        reverse_matrix = np.fliplr(
            np.eye(num_cells)
        )  # Matrix for reversing flow direction
        iron_oxidation_matrix = create_percipitation_oxidation_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )
        calcium_precip_matrix = create_percipitation_oxidation_matrix(
            residence_time=cell_residence_time, num_cells=num_cells
        )

        # Prepare iron oxidation and calcium precipitation profiles
        iron_profile = af.create_iron_oxidation_profile(
            num_cells=num_cells,
            iron_concentration=molar_concentrations["Fe"],
            iron3_concentration=molar_concentrations["Fe3"],
            oxidation_rate=3,
        )
        calcium_profile = af.create_calcium_percipitation_profile(
            num_cells=num_cells,
            ca_concentration=molar_concentrations["Ca"],
            caco3_concentration=molar_concentrations["CaCO3"],
            softening_rate=3,
        )

        # Oxygen derivatives
        dO2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate([[molar_concentrations["O2"]], state_vars["liquid"]["O2"]])
            + gas_transfer_coefficient["O2"]
            * distribution_coefficient["O2"]
            * (reverse_matrix @ state_vars["gas"]["O2"])
            - gas_transfer_coefficient["O2"] * state_vars["liquid"]["O2"]
            - 0.25
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
        )

        dO2_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["O2"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["O2"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["O2"],
                ]
            )
            - (
                gas_transfer_coefficient["O2"]
                * distribution_coefficient["O2"]
                / air_water_ratio
            )
            * state_vars["gas"]["O2"]
            + (gas_transfer_coefficient["O2"] / air_water_ratio)
            * (reverse_matrix @ state_vars["liquid"]["O2"])
        )

        # Methane derivatives
        dCH4_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["CH4"]], state_vars["liquid"]["CH4"]]
            )
            + methane_transfer_coeff
            * distribution_coefficient["CH4"]
            * (reverse_matrix @ state_vars["gas"]["CH4"])
            - methane_transfer_coeff * state_vars["liquid"]["CH4"]
        )

        dCH4_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["CH4"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["CH4"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["CH4"],
                ]
            )
            - (
                methane_transfer_coeff
                * distribution_coefficient["CH4"]
                / air_water_ratio
            )
            * state_vars["gas"]["CH4"]
            + (methane_transfer_coeff / air_water_ratio)
            * (reverse_matrix @ state_vars["liquid"]["CH4"])
        )

        # CO2 derivatives['liquid']
        dCO2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["CO2"]], state_vars["liquid"]["CO2"]]
            )
            + gas_transfer_coefficient["CO2"]
            * distribution_coefficient["CO2"]
            * (reverse_matrix @ state_vars["gas"]["CO2"])
            - gas_transfer_coefficient["CO2"] * state_vars["liquid"]["CO2"]
            + 2
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
            + calcium_precip_matrix
            @ np.concatenate([calcium_profile["Ca"], state_vars["other"]["FDT1"]])
        )

        dCO2_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["CO2"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["CO2"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["CO2"],
                ]
            )
            - (
                gas_transfer_coefficient["CO2"]
                * distribution_coefficient["CO2"]
                / air_water_ratio
            )
            * state_vars["gas"]["CO2"]
            + (gas_transfer_coefficient["CO2"] / air_water_ratio)
            * (reverse_matrix @ state_vars["liquid"]["CO2"])
        )

        # Passive tracer
        dcStap = liquid_mixing_matrix @ np.concatenate(
            [[1], state_vars["other"]["cStap_1"]]
        )

        # Bicarbonate and pH
        dHCO3 = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["HCO3"]], state_vars["other"]["HCO3"]]
            )
            - 2
            * iron_oxidation_matrix
            @ np.concatenate([iron_profile["Fe"], state_vars["other"]["FDT"]])
            - 2
            * calcium_precip_matrix
            @ np.concatenate([calcium_profile["Ca"], state_vars["other"]["FDT1"]])
        )

        # Iron oxidation terms
        dFDT = -10 * state_vars["other"]["FDT"]  # Fast decay term

        dFe3 = liquid_mixing_matrix @ np.concatenate(
            [[molar_concentrations["Fe3"]], state_vars["other"]["Fe3"]]
        ) + iron_oxidation_matrix @ np.concatenate(
            [
                self.params.perc_fe / 100 * iron_profile["Fe"],
                state_vars["other"]["FDT"],
            ]
        )

        # Calcium precipitation terms
        dFDT1 = -10 * state_vars["other"]["FDT1"]  # Fast decay term

        dCaCO3 = liquid_mixing_matrix @ np.concatenate(
            [[molar_concentrations["CaCO3"]], state_vars["other"]["CaCO3"]]
        ) + calcium_precip_matrix @ np.concatenate(
            [
                calcium_profile["Ca"],
                state_vars["other"]["FDT1"],
            ]
        )

        # Nitrogen derivatives
        dN2_liquid = (
            liquid_mixing_matrix
            @ np.concatenate([[molar_concentrations["N2"]], state_vars["liquid"]["N2"]])
            + gas_transfer_coefficient["N2"]
            * distribution_coefficient["N2"]
            * (reverse_matrix @ state_vars["gas"]["N2"])
            - gas_transfer_coefficient["N2"] * state_vars["liquid"]["N2"]
        )

        dN2_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["N2"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["N2"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["N2"],
                ]
            )
            - (
                gas_transfer_coefficient["N2"]
                * distribution_coefficient["N2"]
                / air_water_ratio
            )
            * state_vars["gas"]["N2"]
            + (gas_transfer_coefficient["N2"] / air_water_ratio)
            * (reverse_matrix @ state_vars["liquid"]["N2"])
        )

        # Hydrogen sulfide derivatives
        dH2S_liquid = (
            liquid_mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["H2S"]], state_vars["liquid"]["H2S"]]
            )
            + gas_transfer_coefficient["H2S"]
            * distribution_coefficient["H2S"]
            * (reverse_matrix @ state_vars["gas"]["H2S"])
            - gas_transfer_coefficient["H2S"] * state_vars["liquid"]["H2S"]
        )

        dH2S_gas = (
            liquid_mixing_matrix
            @ np.concatenate(
                [
                    [
                        gas_concentration_in_air_mol["H2S"]
                        * (vented_air_flow / total_air_flow)
                        + state_vars["gas"]["H2S"][-1]
                        * (recirculation_air_flow / total_air_flow)
                    ],
                    state_vars["gas"]["H2S"],
                ]
            )
            - (
                gas_transfer_coefficient["H2S"]
                * distribution_coefficient["H2S"]
                / air_water_ratio
            )
            * state_vars["gas"]["H2S"]
            + (gas_transfer_coefficient["H2S"] / air_water_ratio)
            * (reverse_matrix @ state_vars["liquid"]["H2S"])
        )

        # Combine all derivatives
        derivatives = np.concatenate(
            [
                dO2_liquid,
                dO2_gas,
                dCH4_liquid,
                dCH4_gas,
                dCO2_liquid,
                dCO2_gas,
                dcStap,
                dHCO3,
                dFDT,
                dFe3,
                dFDT1,
                dCaCO3,
                dN2_liquid,
                dN2_gas,
                dH2S_liquid,
                dH2S_gas,
            ],
        )

        return derivatives.tolist()

    def __test_ode_indexing(self, ode):
        for state, sub_idx in self.ode_idx.items():
            for el, idxs in sub_idx.items():
                values = ode[idxs["start"] : idxs["end"], 0]
                logger.debug(f"{state}_{el}: {values}")
