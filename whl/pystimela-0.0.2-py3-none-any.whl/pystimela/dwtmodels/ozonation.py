# Ozonation - April 2025

# ozonox_s.m and ozoncc_s.m scripts are the same. The ozodo1_s.m concerns the dosing.

# Comparison with Stimela outputs:
# For example 1 (BC in the given files - for "MeeTee"=0), the script produces the same results with Stimella (a little lower the O3)
# For example 2 (CC in the given files - for "MeeTee"=1), the script produces the same results with Stimella


# It updates the following water quality parameters: Ozone, UV254, Bromate, Ecoli, AOC, Ozone_dosed, Ozone_dos_kUV

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Oxidation_desinfection/Ozone_Contact/ozoncc_s.m

# The model requires as (water quality) inputs:
# temperature [degree C]
# flow [m3/h]
# influent O3 concentration    [mg/l]
# influent DOC concentration   [mg/l]
# influent UV value          [1/m]
# influent Bromate concentration     [ug/l]
# Ozone.dosed hoeveelheid gedoseerde ozon
# Ozone.dos.kUV hoeveelheid gedoseerde ozon voor kUV
# influent E.coli concentration
# influent pH                   [pH]
# influent bromide concentration [ug/l]
# influent AOC concentration   [ug/l]
# gas flow                [m3/h]
# ozone concentration in gas  [g/Nm3]

import logging
from copy import deepcopy
from typing import List
from numpy.typing import NDArray
import numpy as np
from scipy.integrate import solve_ivp

from pystimela.datatypes import (
    OzonationParams,
    OzonationState,
    OzonationCellConcentrations,
    ListWaterQualityParams,
)
from pystimela.helpers.common import create_banded_matrix, find_interval
from pystimela.toolbox import waterparams as wpf

logger = logging.getLogger(__name__)


class Ozonation(object):
    def __init__(self, params: OzonationParams):
        self.params = params

    def model(
        self, time: float, y: NDArray[np.float64], in_wp: ListWaterQualityParams
    ) -> NDArray[np.float64]:
        num_cells = self.params.numcel
        reactor_height = self.params.hreact  # Height of the reactor [m]
        reactor_area = self.params.areact  # Surface area ozone reactor [m2]
        flow_direction = self.params.meetee  # 1=co-current and 0=counter-current
        bubble_diameter = self.params.db0 / 1000  # initial bubble diameter [m]
        uv_decay_select = (
            self.params.kuv_sel
        )  # 1=kUV is given manual and 0=kUV is determined by the model
        uv_decay_rate = self.params.kuv  # UVA254 decay rate [1/s]
        yield_factor = (
            self.params.y_factor
        )  # Yield factor for ozone use per UVA decrease [(mg/L)/(1/m)]
        ozone_decay_select = (
            self.params.kafbo3_sel
        )  # 1=kO3 is given manual and 0=kO3 is determined by the model
        ozone_decay_rate = self.params.kafbo3  # slow decay rate O3 [1/s]
        uva_select = (
            self.params.ceuva254_sel
        )  # 1=UVAo is given manual and 0=UVAo is determined by the model
        uva_final = self.params.ceuva254  # stable UVA254 value after ozonation
        kl_factor = self.params.factor_klo3  # variable in Hughmark equation
        bromate_init_factor = (
            self.params.f_bro3init
        )  # constant for initial bromate formation
        bromate_rate_select = (
            self.params.kct_bro3_sel
        )  # 1=kBrO3 is given manual and 0=kBrO3 is determined by the model
        bromate_rate = self.params.ktc_bro3 / 60  # bromate formation rate constant
        aoc_select = (
            self.params.f_aoc_sel
        )  # 1=FACO is given manual and 0=FAOC is determined by the model
        aoc_factor = (
            self.params.f_aoc
        )  # constant for AOC formation [(ug-C/l)/(mg-O3/l)]
        ecoli_select = (
            self.params.kec_sel
        )  # 1=kEc is given manual and 0=kEc is determined by the model
        ecoli_rate = self.params.kec / 60  # k inactivation rate for E.coli

        cell_height = reactor_height / num_cells  # height per CSTR (num_cells) [m]

        # input water quality parameters
        timesteps = in_wp.timestamps
        pos = find_interval(time, timesteps)

        temp_water = in_wp[pos].temperature  # water temperature [Celsius]
        flow_water = in_wp[pos].flow  # water flow [m3/h]
        ozone_in = in_wp[pos].ozone  # influent O3 concentration [mg/l]
        doc_in = in_wp[pos].doc  # influent DOC concentration [mg/l]
        uva_in = in_wp[pos].uv254  # influent UV value [1/m]
        bromate_in = in_wp[pos].bromate  # influent Bromate concentration [ug/l]
        ozone_dosed = in_wp[pos].ozone_dosed  # amount of dosed ozone
        ozone_dosed_uv = in_wp[pos].ozone_dos_kuv  # amount of dosed ozone for kUV
        ecoli_in = in_wp[pos].ecoli  # influent E.coli concentration
        ph_in = in_wp[pos].ph  # influent pH [pH]
        bromide_in = in_wp[pos].bromide  # influent bromide concentration [ug/l]
        aoc_in = in_wp[pos].aoc  # influent AOC concentration [ug/l]
        flow_gas = in_wp[pos].gas_flow  # gas flow [m3/h]
        ozone_gas_in = in_wp[pos].cgo_o3  # ozone concentration in gas [g/Nm3]
        ct_in = 0  # The initial Ct
        inhibition_coeff = 0.0001  # Inhibition coefficient Monod constant mg-O3/l

        # Rounding air temperature to integers
        temp_gas = temp_water  # Air temperature in degrees Celsius
        viscosity = wpf.calc_kinimatic_viscosity(
            temp=temp_water
        )  # kinematic viscosity m2/s for 0oC to 35oC
        density = 1000  # water density kg/m3
        surface_tension = (
            -1.47e-4 * temp_water + 7.56e-2
        )  # Surface tension for 0oC to 30oC

        # Determine required quantities related to flow rates and residence times
        flow_water = flow_water / 3600  # m3/h -> m3/s
        flow_gas = flow_gas / 3600  # m3/h -> m3/s
        rq_value = flow_gas / flow_water  # RQ value

        water_velocity = flow_water / reactor_area

        bubble_velocity = (
            0.0135 * ((20000 * surface_tension) / (density * bubble_diameter)) ** 0.5
        )  # bubble raise velocity

        # Constants for calculating gas concentrations in air
        pressure = 101325
        water_vapor_pressure = 1070 * np.exp(0.04986 * temp_gas) - 525.1
        temp_standard = 273.15  # standard temperature K
        alpha_count = (
            (
                pressure
                + (np.arange(1, num_cells + 1) - 0.5) * cell_height * 10000
                - water_vapor_pressure
            )
            / pressure
        ) * (temp_standard / (temp_standard + temp_gas))
        alpha_oc = (
            (
                pressure
                + (reactor_height - (np.arange(1, num_cells + 1) - 0.5) * cell_height)
                * 10000
                - water_vapor_pressure
            )
            / pressure
        ) * (temp_standard / (temp_standard + temp_gas))

        kd_o3 = np.exp(-0.45 - 0.043 * temp_water)  # Langlais 1991

        # Equations for diffusion coefficient based on DO3=1.74e-9 for
        diffusion_o3 = 5.97e-15 * (temp_water + 273.15) / (viscosity * density)

        if kl_factor == 99:
            kl_o3 = 0
        else:
            kl_o3 = (diffusion_o3 / bubble_diameter) * (
                2
                + kl_factor
                * (
                    (bubble_velocity * bubble_diameter / viscosity) ** 0.48
                    * (viscosity / diffusion_o3) ** 0.34
                    * (bubble_diameter * (9.81) ** 0.33 / (diffusion_o3) ** 0.66)
                    ** 0.072
                )
                ** 1.61
            )

        ozone_dosage = (flow_gas * ozone_gas_in) / flow_water
        ozone_final_dosage = ozone_dosed + ozone_dosage
        ozone_dosage_uv = (flow_gas * ozone_gas_in) / flow_water

        if ozone_final_dosage != 0:  # In the first BC ozone is dosed
            if flow_gas != 0:
                ozone_dosed_uv = 0

            ozone_final_dosage_uv = ozone_dosed_uv + ozone_dosage_uv

            if not uv_decay_select:
                uv_decay_rate = 3.75 * np.exp(-3.443 * ozone_final_dosage_uv)

            if not ozone_decay_select:
                ozone_decay_rate_10 = 0.0011 * (doc_in / ozone_final_dosage) ** 2
                ozone_decay_rate = (
                    ozone_decay_rate_10
                    / (np.exp(-70000 / (8.314 * (temp_standard + 10))))
                ) * np.exp(-70000 / (8.314 * (temp_standard + temp_water)))

            if not uva_select:
                uva_final = uva_in - 0.914 * (ozone_final_dosage**0.5) * (uva_in**0.5)

            bromate_init = bromate_init_factor * ozone_final_dosage
            bromate_in = bromate_in + bromate_init

            if not bromate_rate_select:
                bromate_rate = (
                    2.74e-7
                    * (ph_in**5.82)
                    * (bromide_in**0.73)
                    * (1.035 ** (temp_water - 20))
                )  # (ug-BrO3/mg-O3)*1/min
                bromate_rate = bromate_rate * 1 / 60  # (ug-BrO3/mg-O3)*1/s

            if not aoc_select:
                aoc_factor = 3.55e15 * np.exp(
                    -80500 / (8.314 * (temp_standard + temp_water))
                )

            if flow_gas != 0:
                aoc_final = aoc_factor * ozone_dosage * doc_in + aoc_in
            else:
                aoc_final = aoc_in

            if not ecoli_select:
                ecoli_rate = 4.49 * np.exp(
                    3.305 * ozone_final_dosage
                )  # (l/mg-O3)*1/min*1/s
                ecoli_rate = ecoli_rate * 1 / 60  # (l/mg-O3)*1/s*1/s

        else:
            ozone_final_dosage_uv = 0
            uv_decay_rate = 0
            ozone_decay_rate = 0
            uva_final = uva_in
            # bromate_in = bromate_in
            bromate_rate = 0
            aoc_factor = 0
            aoc_final = aoc_in
            ecoli_rate = 0

        # Matrix1 function needs to be implemented separately
        matrix_q1 = create_banded_matrix(t=1, n=num_cells)

        # Hom empirical constants
        n = 1
        m = 2

        ## Unpack state variables ##
        ozone_water = y[:num_cells]
        ozone_gas = y[num_cells : 2 * num_cells]
        uva = y[2 * num_cells : 3 * num_cells]
        bromate = y[3 * num_cells : 4 * num_cells]
        ecoli = y[4 * num_cells : 5 * num_cells]
        ct = y[5 * num_cells : 6 * num_cells]

        ## Derivatives
        if flow_direction:  # co-current
            d_ozone_water = (
                (water_velocity / cell_height)
                * matrix_q1
                @ np.concatenate(([ozone_in], ozone_water))
                + kl_o3
                * rq_value
                * (water_velocity / (bubble_velocity + water_velocity))
                * (6 / bubble_diameter)
                * (alpha_oc * kd_o3 * ozone_gas - ozone_water)
                - ozone_decay_rate * ozone_water
                - uv_decay_rate
                * (uva - uva_final)
                * yield_factor
                * (ozone_water / (inhibition_coeff + ozone_water))
            )

            d_ozone_gas = (
                (bubble_velocity + water_velocity) / cell_height
            ) * matrix_q1 @ np.concatenate(([ozone_gas_in], ozone_gas)) - kl_o3 * (
                6 / bubble_diameter
            ) * (
                alpha_oc * kd_o3 * ozone_gas - ozone_water
            )

            d_uva = (water_velocity / cell_height) * matrix_q1 @ np.concatenate(
                ([uva_in], uva)
            ) - uv_decay_rate * (uva - uva_final) * (
                ozone_water / (inhibition_coeff + ozone_water)
            )

            d_bromate = (water_velocity / cell_height) * matrix_q1 @ np.concatenate(
                ([bromate_in], bromate)
            ) + bromate_rate * ozone_water

            d_ecoli = (water_velocity / cell_height) * matrix_q1 @ np.concatenate(
                ([ecoli_in], ecoli)
            ) - ecoli_rate * m * ecoli * (ozone_water**n) * (
                np.cumsum(cell_height / water_velocity)
            ) ** (
                m - 1
            )

            d_ct = (water_velocity / cell_height) * matrix_q1 @ np.concatenate(
                ([ct_in], ct)
            ) + ozone_water

            result = np.concatenate(
                (d_ozone_water, d_ozone_gas, d_uva, d_bromate, d_ecoli, d_ct)
            )

            return result

        else:  # counter-current
            d_ozone_water = (
                (water_velocity / cell_height)
                * matrix_q1
                @ np.concatenate(([ozone_in], ozone_water))
                + kl_o3
                * rq_value
                * (water_velocity / (bubble_velocity - water_velocity))
                * (6 / bubble_diameter)
                * (alpha_oc * kd_o3 * np.flip(ozone_gas) - ozone_water)
                - ozone_decay_rate * ozone_water
                - uv_decay_rate
                * (uva - uva_final)
                * yield_factor
                * (ozone_water / (inhibition_coeff + ozone_water))
            )

            d_ozone_gas = (
                (bubble_velocity - water_velocity) / cell_height
            ) * matrix_q1 @ np.concatenate(([ozone_gas_in], ozone_gas)) - kl_o3 * (
                6 / bubble_diameter
            ) * (
                alpha_oc * kd_o3 * ozone_gas - np.flip(ozone_water)
            )

            d_uva = (water_velocity / cell_height) * matrix_q1 @ np.concatenate(
                ([uva_in], uva)
            ) - uv_decay_rate * (uva - uva_final) * (
                ozone_water / (inhibition_coeff + ozone_water)
            )

            d_bromate = (water_velocity / cell_height) * matrix_q1 @ np.concatenate(
                ([bromate_in], bromate)
            ) + bromate_rate * ozone_water

            d_ecoli = (water_velocity / cell_height) * matrix_q1 @ np.concatenate(
                ([ecoli_in], ecoli)
            ) - ecoli_rate * m * ecoli * (ozone_water**n) * (
                np.cumsum(cell_height / water_velocity)
            ) ** (
                m - 1
            )

            d_ct = (water_velocity / cell_height) * matrix_q1 @ np.concatenate(
                ([ct_in], ct)
            ) + ozone_water

            result = np.concatenate(
                (d_ozone_water, d_ozone_gas, d_uva, d_bromate, d_ecoli, d_ct)
            )

            return result

    def solve_ode(
        self,
        t_eval: List[float],
        initial_state,
        in_wp: ListWaterQualityParams,
    ):
        "solves the ode."
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, in_wp),
            t_span,
            initial_state,
            method="LSODA",
            t_eval=t_eval,
            rtol=1e-6,
            atol=1e-9,
        )
        return solution

    def simulate(
        self, t_eval, init_state: OzonationState, wq_params: ListWaterQualityParams
    ) -> dict:
        """Returns the water quality params with updated."""
        # water quality parameters out
        out_wqps = []

        timesteps = wq_params.timestamps

        # Solve the ODE system
        solution = self.solve_ode(t_eval, init_state.to_numpy(), wq_params)

        # Process parameters
        num_cells = self.params.numcel
        bromate_init_factor = (
            self.params.f_bro3init
        )  # constant for initial bromate formation
        bromate_rate_select = (
            self.params.kct_bro3_sel
        )  # True kBrO3 is given manual and False kBrO3 is determined by the model
        bromate_rate = self.params.ktc_bro3 / 60  # bromate formation rate constant
        aoc_select = (
            self.params.f_aoc_sel
        )  # True FACO is given manual and False =FAOC is determined by the model
        aoc_factor = (
            self.params.f_aoc
        )  # constant for AOC formation [(ug-C/l)/(mg-O3/l)]
        ecoli_select = (
            self.params.kec_sel
        )  # True kEc is given manual and False kEc is determined by the model
        ecoli_rate = self.params.kec / 60  # k inactivation rate for E.coli

        # Input water quality parameters
        temp_water = wq_params[0].temperature  # water temperature [Celsius]
        flow_water = wq_params[0].flow  # water flow [m3/h]
        ozone_in = wq_params[0].ozone  # influent O3 concentration [mg/l]
        doc_in = wq_params[0].doc  # influent DOC concentration [mg/l]
        uva_in = wq_params[0].uv254  # influent UV value [1/m]
        bromate_in = wq_params[0].bromate  # influent Bromate concentration [ug/l]
        ozone_dosed = wq_params[0].ozone_dosed  # amount of dosed ozone
        ozone_dosed_uv = wq_params[0].ozone_dos_kuv  # amount of dosed ozone for kUV
        ecoli_in = wq_params[0].ecoli  # influent E.coli concentration
        ph_in = wq_params[0].ph  # influent pH [pH]
        bromide_in = wq_params[0].bromide  # influent bromide concentration [ug/l]
        aoc_in = wq_params[0].aoc  # influent AOC concentration [ug/l]
        flow_gas = wq_params[0].gas_flow  # gas flow [m3/h]
        ozone_gas_in = wq_params[0].cgo_o3  # ozone concentration in gas [g/Nm3]
        ct_in = 0  # The initial Ct

        # Determine required quantities related to flow rates and residence times
        flow_water = flow_water / 3600  # m3/h -> m3/s
        flow_gas = flow_gas / 3600  # m3/h -> m3/s

        temp_standard = 273.15  # standard temperature K

        ozone_dosage = (flow_gas * ozone_gas_in) / flow_water
        ozone_final_dosage = ozone_dosed + ozone_dosage
        ozone_dosage_uv = (flow_gas * ozone_gas_in) / flow_water

        if ozone_final_dosage != 0:  # In the first BC ozone is dosed
            if flow_gas != 0:
                ozone_dosed_uv = 0

            ozone_final_dosage_uv = ozone_dosed_uv + ozone_dosage_uv

            bromate_init = bromate_init_factor * ozone_final_dosage
            bromate_in = bromate_in + bromate_init

            if not bromate_rate_select:
                bromate_rate = (
                    2.74e-7
                    * ph_in**5.82
                    * bromide_in**0.73
                    * 1.035 ** (temp_water - 20)
                )
                bromate_rate = bromate_rate * 1 / 60

            if not aoc_select:
                aoc_factor = 3.55e15 * np.exp(
                    -80500 / (8.314 * (temp_standard + temp_water))
                )

            aoc_final = aoc_factor * ozone_final_dosage * doc_in + aoc_in

            if not ecoli_select:
                ecoli_rate = 4.49 * np.exp(3.305 * ozone_final_dosage)
                ecoli_rate = ecoli_rate * 1 / 60

        else:
            ozone_final_dosage_uv = 0
            # bromate_in = bromate_in
            bromate_rate = 0
            aoc_factor = 0
            aoc_final = aoc_in
            ecoli_rate = 0

        # update water quality parameters

        for i in t_eval:
            pos = find_interval(time=i, timesteps=timesteps)
            out_wqp = deepcopy(wq_params[pos])
            out_wqp.timestamp = i
            # take values from the last cell and convert units to mg/L
            out_wqp.ozone = solution.y[num_cells - 1, pos]  # O3 in last cell
            out_wqp.uv254 = solution.y[
                3 * self.params.numcel - 1, pos
            ]  # UVA254 in last cell
            out_wqp.bromate = solution.y[4 * num_cells - 1, pos]
            out_wqp.ecoli = solution.y[5 * num_cells - 1, pos]
            out_wqp.aoc = aoc_final
            out_wqp.ozone_dosed = ozone_final_dosage
            out_wqp.ozone_dos_kuv = ozone_dosage_uv
            out_wqps.append(out_wqp)
        # Calc additional results per cell
        o3_liquid_cons = []
        o3_gas_cons = []
        uav254_cons = []
        bro3_cons = []
        ecoli_cons = []
        ct_cons = []
        for pos, _ in enumerate(wq_params):

            cell_o3_liquid = [ozone_in] + list(
                solution.y[:num_cells, pos]
            )  # O3 in each cell
            cell_o3_gas = [ozone_gas_in] + list(
                solution.y[num_cells : 2 * num_cells, pos]
            )  # Gas O3 in each cell
            cell_uva254 = [uva_in] + list(
                solution.y[2 * num_cells : 3 * num_cells, pos]
            )  # UVA254 in each cell
            cell_bro3 = [bromate_in] + list(
                solution.y[3 * num_cells : 4 * num_cells, pos]
            )  # Bromate in each cell
            cell_ecoli = [ecoli_in] + list(
                solution.y[4 * num_cells : 5 * num_cells, pos]
            )  # E.coli in each cell
            cell_ct = [ct_in / 60] + list(
                solution.y[5 * num_cells : 6 * num_cells, pos] / 60
            )  # Ct in each cell

            o3_liquid_cons.append(cell_o3_liquid)
            o3_gas_cons.append(cell_o3_gas)
            uav254_cons.append(cell_uva254)
            bro3_cons.append(cell_bro3)
            ecoli_cons.append(cell_ecoli)
            ct_cons.append(cell_ct)
        kwqrgs: dict = {
            "o3_liquid": np.array(o3_liquid_cons),
            "o3_gas": np.array(o3_gas_cons),
            "uv254": np.array(uav254_cons),
            "bro3": np.array(bro3_cons),
            "ecoli": np.array(ecoli_cons),
            "ct": np.array(ct_cons),
        }
        kwqrgs["numcel"] = self.params.numcel
        kwqrgs["timestamps"] = timesteps
        cells_cons = OzonationCellConcentrations(**kwqrgs)

        # add_res = np.vstack((in_wq_mat.iloc[0, :], np.array(add_res).T))
        output_wq_params = ListWaterQualityParams(
            timestamps=timesteps, wqparams=out_wqps
        )
        return {
            "out_wqparams": output_wq_params,
            "sysout": solution,
            "add_results": cells_cons,
        }
