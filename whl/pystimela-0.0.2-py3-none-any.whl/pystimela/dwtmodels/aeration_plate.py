# Plate aeration - March 2025

# It updates the following water quality parameters: Oxygen, Methane, Dissolved carbon dioxide (CO₂), M-number/alkalinity, pH, Dissolved nitrogen (N₂,), Dissolved hydrogen sulfide (H₂S)

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Aeration/Plate_aerator/plaatb_s.m

# Comparison with Stimela outputs: all matlab outputs are smoother, but lead to the same result. There is significant deviation for Dissolved hydrogen sulfide (H₂S). Checke function with Moraitis.

# The model requires as (water quality) inputs:
# temperature [degree C]
# flow [m3/h]
# influent concentration O2 [mg/l]
# influent concentration CH4   [mg/l]
# influent concentration CO2   [mg/l]
# influent concentration H2S   [mg/l]
# influent concentration HCO3  [mg/l]
# influent concentration N2    [mg/l]
# Mnumber in [mol/l]
# influent pH [-]
# influent Conductivity [mS/m]

# It requires as process parameters:
# 'Lengte',  '4',    0,  [], 'm',     'Length of perforated plate'
# 'Breedte', '2',    0,  [], 'm',     'Width of perforated plate'
# 'Htot',    '0.35', 0,  [], 'm',     'Height of foam layer'
# 'PercWat', '50',   0, 100, '%',     'Water percentage in foam layer'
# 'QgTot',   '4000', 0,  [], 'Nm^3/h', 'Total airflow'
# 'QgRec',   '3600', 0,  [], 'Nm^3/h', 'Recirculation air flow'
# 'k2',      '0.1',  0,   1, '1/s',   'Gas transfer coefficient (k_2) for methane'
# 'NumCel',  '5',    1,  [], '-',     'Number of completely mixed reactors'

import logging
from copy import deepcopy
from typing import List, Dict
from numpy.typing import NDArray
import numpy as np
from scipy.integrate import solve_ivp

from pystimela.datatypes import (
    AerationPlateParams,
    ListWaterQualityParams,
    AerationPlateCellConcentrations,
)
from pystimela.helpers.common import (
    find_interval,
    create_banded_matrix,
    create_spdiag_matrix,
)
from pystimela.toolbox import carbacideq as cbe
from pystimela.toolbox import constants_library as cl
from pystimela.toolbox import aeration_functions as af

logger = logging.getLogger(__name__)


class AerationPlate(object):
    """Class for Aeration Plate processing"""

    def __init__(self, params: AerationPlateParams):
        self.params = params
        num_cel = self.params.numcel
        self.liquids: List = ["O2", "CH4", "CO2", "Mn", "N2", "H2S"]
        self.gases: List = ["O2", "CH4", "CO2", "N2", "H2S"]
        # lookup dict for the state indexes
        self.s_idxs: Dict = {
            "liquid": {
                "O2": {"start": 0, "end": num_cel},
                "CH4": {"start": 2 * num_cel, "end": 3 * num_cel},
                "CO2": {"start": 4 * num_cel, "end": 5 * num_cel},
                "Mn": {"start": 6 * num_cel, "end": 7 * num_cel},
                "N2": {"start": 7 * num_cel, "end": 8 * num_cel},
                "H2S": {"start": 9 * num_cel, "end": 10 * num_cel},
            },
            "gas": {
                "O2": {"start": num_cel, "end": 2 * num_cel},
                "CH4": {"start": 3 * num_cel, "end": 4 * num_cel},
                "CO2": {"start": 5 * num_cel, "end": 6 * num_cel},
                "N2": {"start": 8 * num_cel, "end": 9 * num_cel},
                "H2S": {"start": 10 * num_cel, "end": 11 * num_cel},
            },
        }

    def model(
        self, time: float, y: NDArray[np.float64], in_wp: ListWaterQualityParams
    ) -> NDArray[np.float64]:
        """
        Models a plate aerator system for water treatment with gas transfer

        Args:
            time: Current simulation time
            state: Current system state vector
            process_params: Dictionary of process parameters
            input_water_quality: Dictionary of input water quality measurements

        Returns:
            List of derivatives for the state variables
        """
        # Extract process parameters with descriptive names
        num_cells = self.params.numcel  # Number of completely mixed reactors
        methane_transfer_coeff = self.params.k2_ch4  # Base gas transfer coefficient
        total_air_flow = self.params.qg_tot / 3600  # Total airflow [m³/s]
        recirculation_air_flow = (
            self.params.qg_rec / 3600
        )  # Recirculation airflow [m³/s]
        vented_air_flow = (
            total_air_flow - recirculation_air_flow
        )  # Vented airflow [m³/s]
        plate_length = self.params.pl_length  # Length of perforated plate [m]
        plate_width = self.params.pl_width  # Width of perforated plate [m]
        plate_area = plate_length * plate_width  # Total plate area [m²]
        water_fraction = (
            self.params.water_perc_foam / 100
        )  # Water percentage in foam layer
        total_height = self.params.height_foam  # Total height of aerator [m]

        # Input water quality parameters with time interpolation
        timesteps = in_wp.timestamps
        time_index = find_interval(time, timesteps)

        # Extract water quality parameters with descriptive names
        water_temp = in_wp[time_index].temperature  # [°C]
        water_flow = in_wp[time_index].flow  # [m³/h]
        influent_oxygen = in_wp[time_index].oxygen  # [mg/l]
        influent_methane = in_wp[time_index].methane  # [mg/l]
        influent_hydrogen_sulfide = in_wp[time_index].hydrogen_sulfide  # [mg/l]
        influent_bicarbonate = in_wp[time_index].bicarbonate  # [mg/l]
        influent_nitrogen = in_wp[time_index].nitrogen  # [mg/l]
        influent_mnumber = in_wp[time_index].mnumber / 1000  # [mol/l]
        influent_ph = in_wp[time_index].ph  # [-]
        influent_conductivity = in_wp[time_index].conductivity  # [mS/m]

        # System configuration and calculations
        air_temp = water_temp  # Assume air temperature equals water temperature
        water_flow_m3s = water_flow / 3600  # Convert from m³/h to m³/s
        air_water_ratio = total_air_flow / water_flow_m3s  # Air-water ratio [-]
        water_volume = plate_area * (
            water_fraction * total_height
        )  # Water volume in bubble bed [m³]
        total_residence_time = (
            water_volume / water_flow_m3s
        )  # Avg residence time in aerator [s]
        cell_residence_time = (
            total_residence_time / num_cells
        )  # Residence time per cell [s]

        # Molecular weights [mg/mol]
        molecular_weight = cl.MOLECULAR_WEIGHTS_mg_mol

        # Convert bicarbonate concentration
        influent_bicarbonate_molar = influent_bicarbonate / molecular_weight["HCO3"]

        # Gas concentrations in air [mol/m³] (temperature in Kelvin)
        gas_concentration_in_air = af.calc_gas_concentration_in_air(air_temp=air_temp)
        # Temperature-dependent distribution coefficients
        # by intermediate temperatures by linear interpolation
        distribution_coefficient = af.calc_distribution_coefficients(
            water_temp=water_temp
        )

        # Diffusion coefficients [m²/s]
        # best fit at 10, 20 and 30 degrees Celsius, usable from 0-40 Celsius
        diffusion_coefficient = af.calc_diffusion_coefficients(water_temp=water_temp)

        # Gas transfer coefficients based on methane coefficient
        diffusion_power = 1

        gas_transfer_coefficient = {
            gas: methane_transfer_coeff
            * (diffusion_coefficient[gas] / diffusion_coefficient["CH4"])
            ** diffusion_power
            for gas in self.gases
        }

        # Create mixing matrices
        liquid_mixing_matrix = create_banded_matrix(cell_residence_time, num_cells)
        gas_mixing_matrix = create_spdiag_matrix(cell_residence_time, num_cells)

        # Ionic strength and activity coefficient calculation
        ionic_strength = 0.183 * influent_conductivity
        activity_coefficient = cbe.calc_activity(ionic_strength=ionic_strength)

        # Equilibrium constants
        equilibrium_constants = cbe.calc_k_values(temp=water_temp)

        influent_co2 = cbe.ce_phm_co2(
            ph=influent_ph,
            mn=influent_mnumber,
            kv=equilibrium_constants,
            activity=activity_coefficient,
        )

        # Convert all concentrations to molar units [mol/m³]
        molar_concentrations = {
            "liquid": {
                "O2": influent_oxygen / molecular_weight["O2"],
                "CH4": influent_methane / molecular_weight["CH4"],
                "H2S": influent_hydrogen_sulfide / molecular_weight["H2S"],
                "N2": influent_nitrogen / molecular_weight["N2"],
                "CO2": influent_co2,
                "Mn": influent_mnumber,
            },
            "gas": {
                "O2": gas_concentration_in_air["O2"] / molecular_weight["O2"],
                "CH4": gas_concentration_in_air["CH4"] / molecular_weight["CH4"],
                "CO2": gas_concentration_in_air["CO2"] / molecular_weight["CO2"],
                "N2": gas_concentration_in_air["N2"] / molecular_weight["N2"],
                "H2S": gas_concentration_in_air["H2S"] / molecular_weight["H2S"],
            },
        }

        # Unpack state variables with descriptive names
        state_vars = {
            "liquid": {
                liquid: y[
                    self.s_idxs["liquid"][liquid]["start"] : self.s_idxs["liquid"][
                        liquid
                    ]["end"]
                ]
                for liquid in self.liquids
            },
            "gas": {
                gas: y[
                    self.s_idxs["gas"][gas]["start"] : self.s_idxs["gas"][gas]["end"]
                ]
                for gas in self.gases
            },
        }

        # Calculate derivatives for each component, excepth Mn
        derivatives = []
        for elem in self.gases:
            d_liquid = (
                liquid_mixing_matrix
                @ np.concatenate(
                    [[molar_concentrations["liquid"][elem]], state_vars["liquid"][elem]]
                )
                + gas_transfer_coefficient[elem]
                * distribution_coefficient[elem]
                * state_vars["gas"][elem]
                - gas_transfer_coefficient[elem] * state_vars["liquid"][elem]
            )

            avg_gas = np.mean(state_vars["gas"][elem])
            d_gas = (
                gas_mixing_matrix
                @ np.concatenate(
                    [
                        [
                            molar_concentrations["gas"][elem]
                            * (vented_air_flow / total_air_flow)
                            + avg_gas * (recirculation_air_flow / total_air_flow)
                        ],
                        state_vars["gas"][elem],
                    ]
                )
                - (
                    gas_transfer_coefficient[elem]
                    * distribution_coefficient[elem]
                    / (air_water_ratio / num_cells)
                )
                * state_vars["gas"][elem]
                + (gas_transfer_coefficient[elem] / (air_water_ratio / num_cells))
                * state_vars["liquid"][elem]
            )

            derivatives.extend([d_liquid, d_gas])

        # M-number (Mn) derivative (only liquid phase)
        d_mn_liquid = liquid_mixing_matrix @ np.concatenate(
            [[molar_concentrations["liquid"]["Mn"]], state_vars["liquid"]["Mn"]]
        )
        derivatives.insert(6, d_mn_liquid)

        return np.concatenate(derivatives)

    def solve_ode(
        self, t_eval: List[float], initial_state, in_wp: ListWaterQualityParams
    ):
        """Solves the ode."""
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, in_wp),
            t_span,
            initial_state,
            method="LSODA",
            t_eval=t_eval,
            rtol=1e-6,
            atol=1e-9,
        )
        return solution

    def simulate(self, t_eval, init_state, wq_params: ListWaterQualityParams) -> dict:
        """
        Simulates a cascaded aeration system over time

        Args:
            t_eval: Array of time points for simulation
            initial_state: Initial state vector for the system
            wq_params:  input water quality measurements for the simulation timespan

        Returns:
            Dictionary containing simulation results and additional outputs
        """
        # Prepare output water quality empty list
        out_wqps = []
        timesteps = wq_params.timestamps

        # Solve the ODE system
        solution = self.solve_ode(t_eval, init_state.to_numpy(), wq_params)

        # Extract initial water quality parameters
        initial_water_temp = wq_params[0].temperature  # [°C]
        initial_conductivity = wq_params[0].conductivity  # [mS/m]
        initial_mnumber = wq_params[0].mnumber / 1000  # Mnumber in [mol/l]
        initial_ph = wq_params[0].ph

        # Ionic strength and activity coefficient calculation
        ionic_strength = 0.183 * initial_conductivity
        activity_coefficient = cbe.calc_activity(ionic_strength=ionic_strength)

        # Equilibrium constants adjusted for activity
        equilibrium_constants = cbe.calc_k_values(temp=initial_water_temp)
        initial_co2 = cbe.ce_phm_co2(
            ph=initial_ph,
            mn=initial_mnumber,
            kv=equilibrium_constants,
            activity=activity_coefficient,
        )

        # Temperature and flow calculations
        air_temp = initial_water_temp  # Assume air temperature equals water temperature

        # Molecular weights [mg/mol]
        molecular_weight = cl.MOLECULAR_WEIGHTS_mg_mol

        # Gas concentrations in air [mol/m³]
        gas_concentration_in_air = af.calc_gas_concentration_in_air(air_temp=air_temp)

        # Temperature-dependent distribution coefficients
        distribution_coefficient = af.calc_distribution_coefficients(
            water_temp=initial_water_temp
        )

        # Prepare additional results (concentrations per cell)
        liquid_concentrations_per_cell: Dict[str, List] = {el: [] for el in self.gases}
        gas_concentrations_per_cell: Dict[str, List] = {el: [] for el in self.gases}
        equilibrium_per_cell: Dict[str, List] = {el: [] for el in self.gases}
        for i, in_wp in enumerate(wq_params):
            out_wqp = deepcopy(in_wp)
            # take values from the last cell and convert units to mg/L
            out_wqp.oxygen = (
                solution.y[self.s_idxs["liquid"]["O2"]["end"] - 1, i]
                * molecular_weight["O2"]
            )
            out_wqp.methane = (
                solution.y[self.s_idxs["liquid"]["CH4"]["end"] - 1, i]
                * molecular_weight["CH4"]
            )
            out_wqp.carbon_dioxide = (
                solution.y[self.s_idxs["liquid"]["CO2"]["end"] - 1, i]
                * molecular_weight["CO2"]
            )
            out_wqp.mnumber = (
                solution.y[self.s_idxs["liquid"]["Mn"]["end"] - 1, i] * 1000
            )  # Convert back to mmol/l
            out_wqp.nitrogen = (
                solution.y[self.s_idxs["liquid"]["N2"]["end"] - 1, i]
                * molecular_weight["N2"]
            )
            out_wqp.hydrogen_sulfide = (
                solution.y[self.s_idxs["liquid"]["H2S"]["end"] - 1, i]
                * molecular_weight["H2S"]
            )
            # Update pH values based on simulation results
            current_co2 = solution.y[self.s_idxs["liquid"]["CO2"]["end"] - 1, i]
            current_mnumber = solution.y[self.s_idxs["liquid"]["Mn"]["end"] - 1, i]
            initial_ph_guess = out_wqp.ph
            new_ph = cbe.ce_co2m_ph(
                current_co2,
                current_mnumber,
                kv=equilibrium_constants,
                activity=activity_coefficient,
                ph0=initial_ph_guess,
            )
            out_wqp.ph = new_ph
            out_wqps.append(out_wqp)
            # Extract current water quality parameters
            #  and Convert all concentrations to molar units [mol/m³]
            current = {
                "O2": in_wp.oxygen / molecular_weight["O2"],
                "CH4": in_wp.methane / molecular_weight["CH4"],
                "CO2": initial_co2,
                "N2": in_wp.nitrogen / molecular_weight["N2"],
                "H2S": in_wp.hydrogen_sulfide / molecular_weight["H2S"],
            }
            # Calc Concentrations per cell
            liquid_conc_i = {
                el: molecular_weight[el]
                * np.concatenate(
                    [
                        [current[el]],
                        solution.y[
                            self.s_idxs["liquid"][el]["start"] : self.s_idxs["liquid"][
                                el
                            ]["end"],
                            i,  # replace the value of the first cell
                        ],
                    ]
                )
                for el in current.keys()
            }
            gas_conc_i = {
                el: molecular_weight[el]
                * np.concatenate(
                    [
                        [gas_concentration_in_air[el] / molecular_weight[el]],
                        solution.y[
                            self.s_idxs["gas"][el]["start"] : self.s_idxs["gas"][el][
                                "end"
                            ],
                            i,
                        ],
                    ]
                )
                for el in self.gases
            }
            equalbrium_i = {
                el: distribution_coefficient[el] * gas_conc_i[el] for el in self.gases
            }

            # store the values of the i time index
            for el in self.gases:
                liquid_concentrations_per_cell[el].append(liquid_conc_i[el])
                gas_concentrations_per_cell[el].append(gas_conc_i[el])
                equilibrium_per_cell[el].append(equalbrium_i[el])

        # Prepare final output structure
        cell_concentrations = AerationPlateCellConcentrations(
            numcel=self.params.numcel,
            timestamps=timesteps,
            o2_liquid=np.concatenate([liquid_concentrations_per_cell["O2"]]),
            ch4_liquid=np.concatenate([liquid_concentrations_per_cell["CH4"]]),
            co2_liquid=np.concatenate([liquid_concentrations_per_cell["CO2"]]),
            n2_liquid=np.concatenate([liquid_concentrations_per_cell["N2"]]),
            h2s_liquid=np.concatenate([liquid_concentrations_per_cell["H2S"]]),
            o2_gas=np.concatenate([gas_concentrations_per_cell["O2"]]),
            ch4_gas=np.concatenate([gas_concentrations_per_cell["CH4"]]),
            co2_gas=np.concatenate([gas_concentrations_per_cell["CO2"]]),
            n2_gas=np.concatenate([gas_concentrations_per_cell["N2"]]),
            h2s_gas=np.concatenate([gas_concentrations_per_cell["H2S"]]),
            o2_equilibrium=np.concatenate([equilibrium_per_cell["O2"]]),
            ch4_equilibrium=np.concatenate([equilibrium_per_cell["CH4"]]),
            co2_equilibrium=np.concatenate([equilibrium_per_cell["CO2"]]),
            n2_equilibrium=np.concatenate([equilibrium_per_cell["N2"]]),
            h2s_equilibrium=np.concatenate([equilibrium_per_cell["H2S"]]),
        )

        output_wq_params = ListWaterQualityParams(
            timestamps=timesteps, wqparams=out_wqps
        )

        return {
            "out_wqparams": output_wq_params,
            "ode_solution": solution,
            "add_results": cell_concentrations,
            # "input_water_quality": input_water_quality_matrix,
            # "process_parameters": process_parameters,
            # "initial_states": initial_states,
        }
