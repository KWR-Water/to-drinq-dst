# Flocculation process - January  2025
# It updates the following water quality parameters: Suspended.solids

#  https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Oxidation_desinfection/Chlorine/Chloro/chloro_s.m
import logging
from typing import List
from copy import deepcopy
import numpy as np
from numpy.typing import NDArray
from scipy.integrate import solve_ivp


from pystimela.datatypes import (
    FlocculationParams,
    FlocculationState,
    ListWaterQualityParams,
)

from pystimela.toolbox import waterparams as wpf
from pystimela.helpers.common import create_matrix, find_interval

logger = logging.getLogger(__name__)


class Flocculation(object):
    def __init__(self, params: FlocculationParams):
        self.params = params
        # Sparse matrix for flow calculations
        self.mat_q1 = create_matrix(self.params.numcel)
        self.dy = self.params.dy

    def model(
        self, t: float, y: NDArray[np.float64], in_wp: ListWaterQualityParams
    ) -> NDArray[np.float64]:
        """Returns the suspended solids in the floculation process.
        :param t: timestamp
        :param in_wp: Input water quality parameters
        """

        timesteps = in_wp.timestamps
        # find the corresponding water quality parameter index
        pos = find_interval(time=t, timesteps=timesteps)
        # calc
        velocity = in_wp[pos].flow / (self.params.surf * 3600)
        shear_rate = wpf.calc_shear_rate(
            temp=in_wp[pos].temperature, g10=self.params.g10
        )
        susp = in_wp[pos].suspended_solids / 1000  # kg/m3

        # Unpack inital state per cell

        # Calculate rate of change of suspended solids
        dss = (
            (velocity / self.dy) * self.mat_q1 @ np.hstack(([susp], y))
            - self.params.ka * shear_rate * y
            + self.params.kb * (shear_rate**2) * y
        )

        return np.array(dss)

    def simulate(
        self, t_eval, initial_state: FlocculationState, in_wp: ListWaterQualityParams
    ) -> dict:
        """Returns the output water parameters downstream of the coagulation process.

        :param in_wp: Input water quality parameters
        """
        out_wqps = []
        solution = self.solve_ode(
            t_eval=t_eval, inital_state=initial_state.to_numpy(), in_wp=in_wp
        )
        sysout = np.transpose(solution.y) * 1000  #  to mg/l
        for i in t_eval:
            pos = find_interval(time=i, timesteps=t_eval)
            out_wqp = deepcopy(in_wp[pos])
            out_wqp.timestamp = i
            # take values from the last cell and convert units to mg/L
            out_wqp.suspended_solids = np.transpose(solution.y)[pos][-1] * 1000  # mg/l
            out_wqps.append(out_wqp)
        output_wq_params = ListWaterQualityParams(
            timestamps=in_wp.timestamps, wqparams=out_wqps
        )

        return {"out_wqparams": output_wq_params, "sysout": sysout}

    def solve_ode(
        self, t_eval: List[float], inital_state: List, in_wp: ListWaterQualityParams
    ):
        """

        :param in_wp: Input water quality parameters
        """
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, in_wp),
            t_span,
            inital_state,
            t_eval=t_eval,
            rtol=1e-6,
            atol=1e-9,
        )
        # logger.debug(f"floculation ode solution is {solution.y[0]}")
        return solution
