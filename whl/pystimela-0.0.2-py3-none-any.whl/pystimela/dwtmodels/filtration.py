# Filtration process - January  2025
# It updates the following water quality parameters: Suspended.solids

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Rapid_filtration/Susp_Solids_Dual_media_filter/dubfil_s.m

# The model requires as (water quality) inputs:
# temperature [degree C]
# flow [m3/h]
# Suspended.solids [mg/l]

import logging
from typing import List
from numpy.typing import NDArray
from copy import deepcopy
import numpy as np
from scipy.integrate import solve_ivp


from pystimela.datatypes import (
    FiltrationParams,
    WaterQualityParams,
    ListWaterQualityParams,
    BackWashData,
    FiltrationState,
)

from pystimela.toolbox import waterparams as wpf
from pystimela.helpers.common import find_interval

logger = logging.getLogger(__name__)


class Filtration(object):
    def __init__(self, params: FiltrationParams):
        self.params = params

    def model(
        self,
        time: float,
        y: NDArray[np.float64],
        bw_mat: BackWashData,
        in_wp: ListWaterQualityParams,
    ) -> List[float]:

        # Process parameters
        num_cel = self.params.numcel  # Number of control volumes
        surf = self.params.surf  # Filter surface area
        diam = self.params.diam / 1000  # Grain size (m)
        nmax = self.params.nmax / 100
        rho_d = self.params.rhod  # Density of deposited solids (kg/m3)
        fil_por0 = self.params.filporo / 100  # Initial filter porosity
        l_water = self.params.lwater
        lambda0 = self.params.lambda0  # Filtration resistance parameter
        l_bed = self.params.lbed  # Total depth of the filter bed (m)
        n1 = self.params.n1  # Resistance accumulation parameter
        n2 = self.params.n2  # Resistance accumulation parameter
        dy = self.params.dy  # Thickness of each cell/control volume

        # Input water quality parameters
        timesteps = in_wp.timestamps
        pos = find_interval(time, timesteps)

        susp = in_wp[pos].suspended_solids / 1000  # Suspended solids (kg/m3)
        temp = in_wp[pos].temperature  # Temperature (C)
        flow = in_wp[pos].flow  # Flow rate (m3/h)

        # Backwash parameters
        bw_pos = find_interval(time, timesteps=bw_mat.timestamps)
        backwash = bw_mat.events[bw_pos]

        # Estimate parameters
        vel = flow / (surf * 3600)  # Velocity (m/s)
        nu = wpf.calc_kinimatic_viscosity(temp)  # Water viscosity (m2/s)
        i0 = (180 * nu * ((1 - fil_por0) ** 2) * vel) / (
            9.81 * (fil_por0**3) * (diam**2)
        )

        # Unpack state variables
        ss = y[:num_cel]
        accumulation = y[num_cel:]
        # Calculate porosity reduction
        fil_por = fil_por0 - (accumulation / rho_d)
        # Initiate derivatives
        d_ss = np.zeros(num_cel)
        d_accumulation = np.zeros(num_cel)

        if backwash == 1:
            d_ss = -(1 / 90) * ss
            d_accumulation = -(1 / 90) * accumulation
        else:
            # Compute derivatives
            mat_q1 = create_matrix(1, num_cel)
            d1 = vel / fil_por
            d2 = mat_q1 @ np.hstack(([susp], ss))
            d3 = accumulation * n1 / rho_d
            d4 = np.power(accumulation / rho_d, 2) * n2 / fil_por
            d_ss = (d1 / dy * d2) - d1 * lambda0 * (1 + d3 - d4) * ss

            d_accumulation = (
                vel
                * (
                    lambda0
                    * (
                        1
                        + (accumulation * n1 / rho_d)
                        - ((accumulation / rho_d) ** 2) * n2 / fil_por
                    )
                )
                * ss
            )
        return np.concatenate((d_ss, d_accumulation))

    def solve_ode(
        self,
        t_eval: List[float],
        initial_state,
        bw: BackWashData,
        in_wp: ListWaterQualityParams,
    ):
        "solves the ode."
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, bw, in_wp),
            t_span,
            initial_state,
            t_eval=t_eval,
            rtol=1e-6,
            atol=1e-9,
        )
        return solution

    def simulate(
        self,
        t_eval,
        init_state: FiltrationState,
        wq_params: ListWaterQualityParams,
        bw: BackWashData,
    ) -> dict:
        """Returns the water quality params with updated suspended solids,
        Flow resistance and acummulation in each cell volume.

        """
        out_wqps = []
        solution = self.solve_ode(
            t_eval=t_eval, initial_state=init_state.to_numpy(), bw=bw, in_wp=wq_params
        )
        timesteps = wq_params.timestamps

        for i in t_eval:
            pos = find_interval(time=i, timesteps=timesteps)
            out_wqp = deepcopy(wq_params[pos])
            out_wqp.timestamp = i
            # take values from the last cell and convert units to mg/L
            out_wqp.suspended_solids = solution.y[self.params.numcel - 1, pos] * 1000
            out_wqps.append(out_wqp)

        # Accumulation for each cell
        accum = solution.y[self.params.numcel :].T

        # Process parameters
        surf = self.params.surf  # Filter surface area
        diam = self.params.diam / 1000  # Grain size (m)
        rho_d = self.params.rhod  # Density of deposited solids (kg/m3)
        fil_por0 = self.params.filporo / 100  # Initial filter porosity
        dy = self.params.dy  # Thickness of each cell/control volume

        flow = wq_params[0].flow  # Flow
        temp = wq_params[0].temperature  # Temperature
        vel = flow / (surf * 3600)  # Velocity / surface loading (Q/A)
        nu = wpf.calc_kinimatic_viscosity(temp)  # Water viscosity (m2/s)
        i0 = (180 * nu * ((1 - fil_por0) ** 2) * vel) / (
            9.81 * (fil_por0**3) * (diam**2)
        )  # Initial hydraulic resistance parameter

        # Update flow resistance at each cell
        flow_res = np.array(
            [
                np.cumsum(dy - i0 * dy * (fil_por0 / (fil_por0 - (x / rho_d))) ** 2)
                for x in accum
            ]
        )
        # convert the units for Suspended solids to mg/L
        solution.y[: self.params.numcel, :] = solution.y[: self.params.numcel, :] * 1000
        output_wq_params = ListWaterQualityParams(
            timestamps=timesteps, wqparams=out_wqps
        )
        return {
            "out_wqparams": output_wq_params,
            "sysout": solution.y.T,
            "flow_res": flow_res,
        }


def create_matrix(t, n):
    """Matrix for filtration cells"""
    a = 1 / t
    mat = np.zeros((n, n + 1))

    for i in range(n):
        mat[i, i] = a
        if i + 1 < n + 1:
            mat[i, i + 1] = -a

    return mat
