# Chlorination model - December 2024
# It estimates residual chlorine concentration, TTHMs (trihalomethanes) and HAAs (haloacetic acids)
# and also inactivation of viruses (not implemented for the time being)

# There is no output results in Stimela for Chlorination. I checked the code with GPT and produce the same results.

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Oxidation_desinfection/Chlorine/Chloro/chloro_s.m

# The model requires as (water quality) inputs:
# temperature [degree C]
# flow [m3/h]
# pH [-]
# doc: dissolved organic carbon [mg/L]
# uv254: absorption of light in the UV part of the light spectrum at 254nm [1/m] https://smartstormgroup.com/wp-content/uploads/2021/11/Smart-Storm-UV254-Guide.pdf
# bromide: bromide ion concentration [mg/L]
# ammonia: ammonia concentration [mg/L]
# giardia # not used at the moment
# viruses # not used at the moment

# It requires as dosages:
# Chlorine dosage [g/h] ('2000', 0, inf)

# It requires as process parameters:
# Vol: Volume of contact tank  (0, inf, 'm3')
# BF: Baffling factor (0, inf, 'm3') - it is used only for the case of giardia and viruses

# It estimates:
# 1. chlorine concentration
# 2. TTHMs (trihalomethanes)
# 3. HAAs (haloacetic acids)

import logging
from typing import List
from copy import deepcopy
import numpy as np
from scipy.integrate import solve_ivp


from pystimela.datatypes import (
    ChlorinationParams,
    ListWaterQualityParams,
    ChlorinationState,
)
from pystimela.helpers.common import find_interval
import pystimela.toolbox.chlfunctions as clf


logger = logging.getLogger(__name__)


class Chlorination(object):
    """Class for modeling the stimela Chlorination process"""

    def __init__(self, params: ChlorinationParams):
        self.params = params

    def model(
        self,
        t: float,
        y: List[float],
        in_wp: ListWaterQualityParams,
        dosage: List[float],
    ) -> List[float]:
        """R.
        :param t: timestamp
        :param in_wp: Input water quality parameters
        """

        timesteps = in_wp.timestamps
        # find the corresponding water quality parameter index
        pos = find_interval(time=t, timesteps=timesteps)
        wparams = in_wp[pos]
        vol = self.params.volume
        # bf = self.params.baffling_factor

        cldose = dosage[pos]
        clconc = cldose / in_wp[pos].flow

        # State variables
        state = ChlorinationState(reschl=y[0], tthms=y[1], haas=y[2], ecoli=y[3])

        # Model equations

        a = clf.calc_a(s=state, wq=wparams)
        k1 = clf.calc_k1(s=state, wq=wparams)
        k2 = clf.calc_k2(s=state, wq=wparams)

        # By-product dynamics

        atthm = clf.calc_a_tthm(s=state, wq=wparams)
        btthm = clf.calc_b_tthm(s=state, wq=wparams)

        k1a = atthm / a * k1
        k1b = btthm / (1 - a) * k2

        ahaa6 = clf.calc_ahaa6(s=state, wq=wparams)
        bhaa6 = clf.calc_bhaa6(s=state, wq=wparams)

        k2a = ahaa6 / a * k1
        k2b = bhaa6 / (1 - a) * k2

        # Differential equations
        reschl = (
            (wparams.flow_per_sec / vol) * (clconc - state.reschl)
            - a * k1 * state.reschl
            - (1 - a) * k2 * state.reschl
        )
        tthms = (
            k1a * state.reschl
            + k2a * state.reschl
            - (wparams.flow_per_sec / vol) * state.tthms
        )
        haas = (
            k1b * state.reschl
            + k2b * state.reschl
            - (wparams.flow_per_sec / vol) * state.haas
        )

        # E.coli inactivation (Chick-Watson): rate proportional to residual chlorine.
        # kec is temperature-corrected and given in L/(mg*min); /60 -> L/(mg*s).
        kec = 6 * 1.072 ** (wparams.temperature - 20)  # L/(mg*min)
        ecoli = (
            (wparams.flow_per_sec / vol) * (wparams.ecoli - state.ecoli)
            - (kec / 60) * state.reschl * state.ecoli
        )

        return [reschl, tthms, haas, ecoli]

    def simulate(
        self,
        t_eval: List[float],
        init_state: ChlorinationState,
        wq_params: ListWaterQualityParams,
        dosage: List[float],
    ) -> dict:
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        try:
            solution = solve_ivp(
                lambda t, y: self.model(t, y, wq_params, dosage),
                t_span,
                init_state.to_numpy(),
                t_eval=t_eval,
                method="BDF",
                rtol=1e-3,
                atol=1e-6,
            )
        except ValueError as e:
            print(f"Dosage: {dosage}, init_state: {init_state.to_numpy()}")
            raise Exception(e)


        reschl = np.clip(solution.y[0], 0, None)  # residual chlorine cannot be negative
        ttmhms = np.clip(solution.y[1], 0, None)  # TTHMs cannot be negative
        haas = np.clip(solution.y[2], 0, None)  # HAAs cannot be negative
        ecoli = np.clip(solution.y[3], 0, None)  # E.coli cannot be negative

        return {"reschl": reschl, "ttmhms": ttmhms, "haas": haas, "ecoli": ecoli}
