# Cascade aeration - March 2025
# also known as weir aerator
# the case of closed system (Vair>0) has not been validated for CFD solution. But I checked the function with Moraitis and produces the same results.
# Comparison with Stimela outputs: all matlab outputs are the same with these functions, except from Carbon.dioxide (it is lower)

# It updates the following water quality parameters: Oxygen, Methane, Dissolved carbon dioxide (CO₂), M-number/alkalinity, pH, Dissolved nitrogen (N₂,), Dissolved hydrogen sulfide (H₂S)

# https://github.com/Stimela/Stimela/blob/master/Stimela/Standard_models/Aeration/Cascade_aerator/cascad_s.m

# The model requires as (water quality) inputs:
# temperature [degree C]
# flow [m3/h]
# influent concentration O2    [mg/l]
# influent concentration CH4   [mg/l]
# influent concentration CO2   [mg/l]
# influent concentration H2S   [mg/l]
# influent concentration HCO3  [mg/l]
# influent concentration N2    [mg/l]
# Mnumber in [mol/l]
# influent pH [-]
# influent Conductivity [mS/m]

# It requires as process parameters:

# 'NumCel',  '5',    1,  [], '-',     'Number of completely mixed reactors'
# 'VBak',    '0.5',    0,  [], 'm^3',  'Volume of one cascade chamber'
# 'RQeff',   '0.4', 0.3,  0.5, '-',    'Effective air to water ratio'
# 'k2CH4',  '0.04',  0,   1, '1/s',    'Gas transfer coëfficient (k_2) for methane'
# 'Vair',  '0',  0,   [], 'm^3',    'Air volume above cascade'

import logging
from copy import deepcopy
from typing import List, Dict
from numpy.typing import NDArray
import numpy as np
from scipy.integrate import solve_ivp

from pystimela.datatypes import (
    AerationCascadeParams,
    ListWaterQualityParams,
    AerationCascadeCellConcentrations,
)
from pystimela.helpers.common import find_interval, create_banded_matrix
from pystimela.toolbox import carbacideq as cbe
from pystimela.toolbox import constants_library as cl
from pystimela.toolbox import aeration_functions as af

logger = logging.getLogger(__name__)


class AerationCascade(object):
    def __init__(self, params: AerationCascadeParams):
        self.params = params
        num_cel = self.params.numcel
        self.liquids: List = ["O2", "CH4", "CO2", "Mn", "N2", "H2S"]
        self.gases: List = ["O2", "CH4", "CO2", "N2", "H2S"]
        # lookup dict for the state indexes
        self.s_idxs: Dict = {
            "liquid": {
                "O2": {"start": 0, "end": num_cel},
                "CH4": {"start": 2 * num_cel, "end": 3 * num_cel},
                "CO2": {"start": 4 * num_cel, "end": 5 * num_cel},
                "Mn": {"start": 6 * num_cel, "end": 7 * num_cel},
                "N2": {"start": 7 * num_cel, "end": 8 * num_cel},
                "H2S": {"start": 9 * num_cel, "end": 10 * num_cel},
            },
            "gas": {
                "O2": {"start": num_cel, "end": 2 * num_cel},
                "CH4": {"start": 3 * num_cel, "end": 4 * num_cel},
                "CO2": {"start": 5 * num_cel, "end": 6 * num_cel},
                "N2": {"start": 8 * num_cel, "end": 9 * num_cel},
                "H2S": {"start": 10 * num_cel, "end": 11 * num_cel},
            },
        }

        self.s_hd_idxs = {
            "O2": 11 * num_cel,
            "CH4": 11 * num_cel + 1,
            "CO2": 11 * num_cel + 2,
            "N2": 11 * num_cel + 3,
            "H2S": 11 * num_cel + 4,
        }

    def model(
        self, time: float, y: NDArray[np.float64], in_wp: ListWaterQualityParams
    ) -> NDArray[np.float64]:
        """
        Simulates a cascaded aeration system for water treatment

        Args:
            t: Current simulation time
            y: Current system state vector
            in_wp:  input water quality measurements for a given simulation timespan

        Returns:
            List of derivatives for the state variables
        """
        # Process parameters extraction with more descriptive names
        num_cells = self.params.numcel  # Number of completely mixed reactors
        methane_transfer_coeff = (
            self.params.k2_ch4
        )  # Gas transfer coefficient for methane
        air_flow_ratio = self.params.rq_eff  # Fresh air inflow ratio
        reactor_volume = self.params.v_bak  # Volume of the reactor
        headspace_volume = (
            self.params.v_air
        )  # Volume of air headspace (0 for open systems)

        # Input water quality parameters with time interpolation
        timesteps = in_wp.timestamps
        time_index = find_interval(time, timesteps)

        water_temp = in_wp[time_index].temperature  # [°C]
        water_flow = in_wp[time_index].flow  # [m³/h]
        influent_oxygen = in_wp[time_index].oxygen  # [mg/l]
        influent_methane = in_wp[time_index].methane  # [mg/l]
        influent_hydrogen_sulfide = in_wp[time_index].hydrogen_sulfide  # [mg/l]
        influent_nitrogen = in_wp[time_index].nitrogen  # [mg/l]
        influent_mnumber = in_wp[time_index].mnumber / 1000  # Convert to [mol/l]
        influent_ph = in_wp[time_index].ph  # [-]
        influent_conductivity = in_wp[time_index].conductivity  # [mS/m]
        # TODO: total gas flow is always 0
        total_gas_flow = 0  # [m³/s] u(U.Number+1)/3600

        # System configuration check
        is_closed_system = headspace_volume != 0
        if is_closed_system:
            total_gas_flow = 0  # [m³/s]

        # Unit conversions and calculations
        air_temp = water_temp  # Assume air temperature equals water temperature
        water_flow_m3s = water_flow / 3600  # Convert from m³/h to m³/s
        residence_time = (
            reactor_volume / water_flow_m3s
        )  # Average residence time per cell [s]

        # Molecular weights [mg/mol]
        molecular_weight = cl.MOLECULAR_WEIGHTS_mg_mol

        # Gas concentrations in air [mol/m³] (temperature in Kelvin)
        gas_concentration_in_air = af.calc_gas_concentration_in_air(air_temp=air_temp)
        # Temperature-dependent distribution coefficients
        # by intermediate temperatures by linear interpolation
        distribution_coefficient = af.calc_distribution_coefficients(
            water_temp=water_temp
        )

        # Diffusion coefficients [m²/s]
        # best fit at 10, 20 and 30 degrees Celsius, usable from 0-40 Celsius
        diffusion_coefficient = af.calc_diffusion_coefficients(water_temp=water_temp)

        # Gas transfer coefficients based on methane coefficient
        diffusion_power = 1

        gas_transfer_coefficient = {
            gas: methane_transfer_coeff
            * (diffusion_coefficient[gas] / diffusion_coefficient["CH4"])
            ** diffusion_power
            for gas in self.gases
        }

        # Create mixing matrix for the cascade
        mixing_matrix = create_banded_matrix(residence_time, num_cells)

        # Ionic strength and activity coefficient calculation
        ionic_strength = 0.183 * influent_conductivity
        activity_coefficient = cbe.calc_activity(ionic_strength=ionic_strength)

        # Equilibrium constants
        equilibrium_constants = cbe.calc_k_values(temp=water_temp)

        influent_co2 = cbe.ce_phm_co2(
            ph=influent_ph,
            mn=influent_mnumber,
            kv=equilibrium_constants,
            activity=activity_coefficient,
        )

        # Convert all concentrations to molar units [mol/m³]
        molar_concentrations = {
            "liquid": {
                "O2": influent_oxygen / molecular_weight["O2"],
                "CH4": influent_methane / molecular_weight["CH4"],
                "H2S": influent_hydrogen_sulfide / molecular_weight["H2S"],
                "N2": influent_nitrogen / molecular_weight["N2"],
                "CO2": influent_co2,
            },
            "gas": {
                "O2": gas_concentration_in_air["O2"] / molecular_weight["O2"],
                "CH4": gas_concentration_in_air["CH4"] / molecular_weight["CH4"],
                "CO2": gas_concentration_in_air["CO2"] / molecular_weight["CO2"],
                "N2": gas_concentration_in_air["N2"] / molecular_weight["N2"],
                "H2S": gas_concentration_in_air["H2S"] / molecular_weight["H2S"],
            },
        }

        # Unpack state variables with descriptive names
        state_vars = {
            "liquid": {
                liquid: y[
                    self.s_idxs["liquid"][liquid]["start"] : self.s_idxs["liquid"][
                        liquid
                    ]["end"]
                ]
                for liquid in self.liquids
            },
            "gas": {
                gas: y[
                    self.s_idxs["gas"][gas]["start"] : self.s_idxs["gas"][gas]["end"]
                ]
                for gas in self.gases
            },
        }

        # Calculate derivatives for liquids
        # Oxygen derivatives
        dO2_liquid = (
            mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["liquid"]["O2"]], state_vars["liquid"]["O2"]]
            )
            + gas_transfer_coefficient["O2"]
            * distribution_coefficient["O2"]
            * state_vars["gas"]["O2"]
            - gas_transfer_coefficient["O2"] * state_vars["liquid"]["O2"]
        )
        # Methane derivatives
        dCH4_liquid = (
            mixing_matrix
            @ np.concatenate(
                [
                    [molar_concentrations["liquid"]["CH4"]],
                    state_vars["liquid"]["CH4"],
                ]
            )
            + methane_transfer_coeff
            * distribution_coefficient["CH4"]
            * state_vars["gas"]["CH4"]
            - methane_transfer_coeff * state_vars["liquid"]["CH4"]
        )
        # CO2 derivatives
        dCO2_liquid = (
            mixing_matrix
            @ np.concatenate(
                [
                    [molar_concentrations["liquid"]["CO2"]],
                    state_vars["liquid"]["CO2"],
                ]
            )
            + gas_transfer_coefficient["CO2"]
            * distribution_coefficient["CO2"]
            * state_vars["gas"]["CO2"]
            - gas_transfer_coefficient["CO2"] * state_vars["liquid"]["CO2"]
        )
        # Manganese (Mn) derivative
        dMn_liquid = mixing_matrix @ np.concatenate(
            [[influent_mnumber], state_vars["liquid"]["Mn"]]
        )

        # Nitrogen derivatives
        dN2_liquid = (
            mixing_matrix
            @ np.concatenate(
                [[molar_concentrations["liquid"]["N2"]], state_vars["liquid"]["N2"]]
            )
            + gas_transfer_coefficient["N2"]
            * distribution_coefficient["N2"]
            * state_vars["gas"]["N2"]
            - gas_transfer_coefficient["N2"] * state_vars["liquid"]["N2"]
        )
        # Hydrogen sulfide derivatives
        dH2S_liquid = (
            mixing_matrix
            @ np.concatenate(
                [
                    [molar_concentrations["liquid"]["H2S"]],
                    state_vars["liquid"]["H2S"],
                ]
            )
            + gas_transfer_coefficient["H2S"]
            * distribution_coefficient["H2S"]
            * state_vars["gas"]["H2S"]
            - gas_transfer_coefficient["H2S"] * state_vars["liquid"]["H2S"]
        )

        # Calculate derivatives for gases
        if not is_closed_system:  # Open system
            # Oxygen derivatives
            dO2_gas = (
                (molar_concentrations["gas"]["O2"] - state_vars["gas"]["O2"])
                / residence_time
                - (
                    gas_transfer_coefficient["O2"]
                    * distribution_coefficient["O2"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["O2"]
                + (gas_transfer_coefficient["O2"] / air_flow_ratio)
                * state_vars["liquid"]["O2"]
            )

            # Methane derivatives
            dCH4_gas = (
                (molar_concentrations["gas"]["CH4"] - state_vars["gas"]["CH4"])
                / residence_time
                - (
                    methane_transfer_coeff
                    * distribution_coefficient["CH4"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["CH4"]
                + (methane_transfer_coeff / air_flow_ratio)
                * state_vars["liquid"]["CH4"]
            )

            # CO2 derivatives
            dCO2_gas = (
                (molar_concentrations["gas"]["CO2"] - state_vars["gas"]["CO2"])
                / residence_time
                - (
                    gas_transfer_coefficient["CO2"]
                    * distribution_coefficient["CO2"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["CO2"]
                + (gas_transfer_coefficient["CO2"] / air_flow_ratio)
                * state_vars["liquid"]["CO2"]
            )

            # Nitrogen derivatives
            dN2_gas = (
                (molar_concentrations["gas"]["N2"] - state_vars["gas"]["N2"])
                / residence_time
                - (
                    gas_transfer_coefficient["N2"]
                    * distribution_coefficient["N2"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["N2"]
                + (gas_transfer_coefficient["N2"] / air_flow_ratio)
                * state_vars["liquid"]["N2"]
            )

            # Hydrogen sulfide derivatives
            dH2S_gas = (
                (molar_concentrations["gas"]["H2S"] - state_vars["gas"]["H2S"])
                / residence_time
                - (
                    gas_transfer_coefficient["H2S"]
                    * distribution_coefficient["H2S"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["H2S"]
                + (gas_transfer_coefficient["H2S"] / air_flow_ratio)
                * state_vars["liquid"]["H2S"]
            )

            derivatives = [
                dO2_liquid,
                dO2_gas,
                dCH4_liquid,
                dCH4_gas,
                dCO2_liquid,
                dCO2_gas,
                dMn_liquid,
                dN2_liquid,
                dN2_gas,
                dH2S_liquid,
                dH2S_gas,
            ]

        else:  # Closed system (with headspace)
            # Similar derivative calculations as above but using headspace concentrations
            headspace_concentrations = {
                "O2": y[self.s_hd_idxs["O2"]],
                "CH4": y[self.s_hd_idxs["CH4"]],
                "CO2": y[self.s_hd_idxs["CO2"]],
                "N2": y[self.s_hd_idxs["N2"]],
                "H2S": y[self.s_hd_idxs["H2S"]],
            }

            # Oxygen derivatives
            dO2_gas = (
                (headspace_concentrations["O2"] - state_vars["gas"]["O2"])
                / residence_time
                - (
                    gas_transfer_coefficient["O2"]
                    * distribution_coefficient["O2"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["O2"]
                + (gas_transfer_coefficient["O2"] / air_flow_ratio)
                * state_vars["liquid"]["O2"]
            )

            dO2_head = (
                molar_concentrations["gas"]["O2"] * total_gas_flow
                - (
                    state_vars["liquid"]["O2"][-1]
                    - molar_concentrations["liquid"]["O2"]
                )
                * water_flow_m3s
                - headspace_concentrations["O2"] * total_gas_flow
            ) / headspace_volume

            # Methane derivatives
            dCH4_gas = (
                (headspace_concentrations["CH4"] - state_vars["gas"]["CH4"])
                / residence_time
                - (
                    methane_transfer_coeff
                    * distribution_coefficient["CH4"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["CH4"]
                + (methane_transfer_coeff / air_flow_ratio)
                * state_vars["liquid"]["CH4"]
            )

            dCH4_head = (
                molar_concentrations["gas"]["CH4"] * total_gas_flow
                - (
                    state_vars["liquid"]["CH4"][-1]
                    - molar_concentrations["liquid"]["CH4"]
                )
                * water_flow_m3s
                - headspace_concentrations["CH4"] * total_gas_flow
            ) / headspace_volume

            # CO2 derivatives
            dCO2_gas = (
                (headspace_concentrations["CO2"] - state_vars["gas"]["CO2"])
                / residence_time
                - (
                    gas_transfer_coefficient["CO2"]
                    * distribution_coefficient["CO2"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["CO2"]
                + (gas_transfer_coefficient["CO2"] / air_flow_ratio)
                * state_vars["liquid"]["CO2"]
            )

            dCO2_head = (
                molar_concentrations["gas"]["CO2"] * total_gas_flow
                - (
                    state_vars["liquid"]["CO2"][-1]
                    - molar_concentrations["liquid"]["CO2"]
                )
                * water_flow_m3s
                - headspace_concentrations["CO2"] * total_gas_flow
            ) / headspace_volume

            # Nitrogen derivatives
            dN2_gas = (
                (headspace_concentrations["N2"] - state_vars["gas"]["N2"])
                / residence_time
                - (
                    gas_transfer_coefficient["N2"]
                    * distribution_coefficient["N2"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["N2"]
                + (gas_transfer_coefficient["N2"] / air_flow_ratio)
                * state_vars["liquid"]["N2"]
            )

            dN2_head = (
                molar_concentrations["gas"]["N2"] * total_gas_flow
                - (
                    state_vars["liquid"]["N2"][-1]
                    - molar_concentrations["liquid"]["N2"]
                )
                * water_flow_m3s
                - headspace_concentrations["N2"] * total_gas_flow
            ) / headspace_volume

            # Hydrogen sulfide derivatives
            dH2S_gas = (
                (headspace_concentrations["H2S"] - state_vars["gas"]["H2S"])
                / residence_time
                - (
                    gas_transfer_coefficient["H2S"]
                    * distribution_coefficient["H2S"]
                    / air_flow_ratio
                )
                * state_vars["gas"]["H2S"]
                + (gas_transfer_coefficient["H2S"] / air_flow_ratio)
                * state_vars["liquid"]["H2S"]
            )

            dH2S_head = (
                molar_concentrations["gas"]["H2S"] * total_gas_flow
                - (
                    state_vars["liquid"]["H2S"][-1]
                    - molar_concentrations["liquid"]["H2S"]
                )
                * water_flow_m3s
                - headspace_concentrations["H2S"] * total_gas_flow
            ) / headspace_volume

            derivatives = [
                dO2_liquid,
                dO2_gas,
                dCH4_liquid,
                dCH4_gas,
                dCO2_liquid,
                dCO2_gas,
                dMn_liquid,
                dN2_liquid,
                dN2_gas,
                dH2S_liquid,
                dH2S_gas,
            ] + [dO2_head, dCH4_head, dCO2_head, dN2_head, dH2S_head]

        return np.concatenate(derivatives)

    def solve_ode(
        self, t_eval: List[float], initial_state, in_wp: ListWaterQualityParams
    ):
        """Solves the ode."""
        t_span = (t_eval[0], t_eval[-1])
        # t_eval = np.linspace(t_span[0], 100, 100)
        solution = solve_ivp(
            lambda t, y: self.model(t, y, in_wp),
            t_span,
            initial_state,
            method="LSODA",
            t_eval=t_eval,
            rtol=1e-6,
            atol=1e-9,
        )
        return solution

    def simulate(self, t_eval, init_state, wq_params: ListWaterQualityParams) -> dict:
        """
        Simulates a cascaded aeration system over time

        Args:
            time_steps: Array of time points for simulation
            initial_states: Initial state vector for the system
            process_parameters: Dictionary of process parameters
            input_water_quality_matrix: Matrix of input water quality measurements

        Returns:
            Dictionary containing simulation results and additional outputs
        """
        # Prepare output water quality empty list
        out_wqps = []
        timesteps = wq_params.timestamps

        # Solve the ODE system
        solution = self.solve_ode(t_eval, init_state.to_numpy(), wq_params)

        # Extract initial water quality parameters
        initial_water_temp = wq_params[0].temperature  # [°C]
        initial_conductivity = wq_params[0].conductivity  # [mS/m]
        initial_mnumber = wq_params[0].mnumber / 1000  # Mnumber in [mol/l]
        initial_ph = wq_params[0].ph

        # Ionic strength and activity coefficient calculation
        ionic_strength = 0.183 * initial_conductivity
        activity_coefficient = cbe.calc_activity(ionic_strength=ionic_strength)

        # Equilibrium constants adjusted for activity
        equilibrium_constants = cbe.calc_k_values(temp=initial_water_temp)
        initial_co2 = cbe.ce_phm_co2(
            ph=initial_ph,
            mn=initial_mnumber,
            kv=equilibrium_constants,
            activity=activity_coefficient,
        )

        # Temperature and flow calculations
        air_temp = initial_water_temp  # Assume air temperature equals water temperature

        # Molecular weights [mg/mol]
        molecular_weight = cl.MOLECULAR_WEIGHTS_mg_mol

        # Gas concentrations in air [mol/m³]
        gas_concentration_in_air = af.calc_gas_concentration_in_air(air_temp=air_temp)

        # Temperature-dependent distribution coefficients
        distribution_coefficient = af.calc_distribution_coefficients(
            water_temp=initial_water_temp
        )

        # Prepare additional results (concentrations per cell)
        liquid_concentrations_per_cell: Dict[str, List] = {el: [] for el in self.gases}
        gas_concentrations_per_cell: Dict[str, List] = {el: [] for el in self.gases}
        equilibrium_per_cell: Dict[str, List] = {el: [] for el in self.gases}

        for i, in_wp in enumerate(wq_params.wqparams):
            out_wqp = deepcopy(in_wp)
            # take values from the last cell and convert units to mg/L
            out_wqp.oxygen = (
                solution.y[self.s_idxs["liquid"]["O2"]["end"] - 1, i]
                * molecular_weight["O2"]
            )
            out_wqp.methane = (
                solution.y[self.s_idxs["liquid"]["CH4"]["end"] - 1, i]
                * molecular_weight["CH4"]
            )
            out_wqp.carbon_dioxide = (
                solution.y[self.s_idxs["liquid"]["CO2"]["end"] - 1, i]
                * molecular_weight["CO2"]
            )
            out_wqp.mnumber = (
                solution.y[self.s_idxs["liquid"]["Mn"]["end"] - 1, i] * 1000
            )  # Convert back to mmol/l
            out_wqp.nitrogen = (
                solution.y[self.s_idxs["liquid"]["N2"]["end"] - 1, i]
                * molecular_weight["N2"]
            )
            out_wqp.hydrogen_sulfide = (
                solution.y[self.s_idxs["liquid"]["H2S"]["end"] - 1, i]
                * molecular_weight["H2S"]
            )
            # Update pH values based on simulation results
            current_co2 = solution.y[self.s_idxs["liquid"]["CO2"]["end"] - 1, i]
            current_mnumber = solution.y[self.s_idxs["liquid"]["Mn"]["end"] - 1, i]
            initial_ph_guess = out_wqp.ph
            new_ph = cbe.ce_co2m_ph(
                current_co2,
                current_mnumber,
                kv=equilibrium_constants,
                activity=activity_coefficient,
                ph0=initial_ph_guess,
            )
            out_wqp.ph = new_ph
            out_wqps.append(out_wqp)

            # Extract current water quality parameters
            #  and Convert all concentrations to molar units [mol/m³]
            current = {
                "O2": in_wp.oxygen / molecular_weight["O2"],
                "CH4": in_wp.methane / molecular_weight["CH4"],
                "CO2": initial_co2,
                "N2": in_wp.nitrogen / molecular_weight["N2"],
                "H2S": in_wp.hydrogen_sulfide / molecular_weight["H2S"],
            }
            # Calc Concentrations per cell
            liquid_conc_i = {
                el: molecular_weight[el]
                * np.concatenate(
                    [
                        [current[el]],
                        solution.y[
                            self.s_idxs["liquid"][el]["start"] : self.s_idxs["liquid"][
                                el
                            ]["end"],
                            i,
                        ],
                    ]
                )
                for el in current.keys()
            }
            gas_conc_i = {
                el: molecular_weight[el]
                * np.concatenate(
                    [
                        [gas_concentration_in_air[el] / molecular_weight[el]],
                        solution.y[
                            self.s_idxs["gas"][el]["start"] : self.s_idxs["gas"][el][
                                "end"
                            ],
                            i,
                        ],
                    ]
                )
                for el in self.gases
            }
            equilbrium_i = {
                el: distribution_coefficient[el] * gas_conc_i[el] for el in self.gases
            }

            # store the values of the i time index
            for el in self.gases:
                liquid_concentrations_per_cell[el].append(liquid_conc_i[el])
                gas_concentrations_per_cell[el].append(gas_conc_i[el])
                equilibrium_per_cell[el].append(equilbrium_i[el])
        # Prepare final output structure
        cell_concentrations = AerationCascadeCellConcentrations(
            numcel=self.params.numcel,
            timestamps=timesteps,
            o2_liquid=np.concatenate([liquid_concentrations_per_cell["O2"]]),
            ch4_liquid=np.concatenate([liquid_concentrations_per_cell["CH4"]]),
            co2_liquid=np.concatenate([liquid_concentrations_per_cell["CO2"]]),
            n2_liquid=np.concatenate([liquid_concentrations_per_cell["N2"]]),
            h2s_liquid=np.concatenate([liquid_concentrations_per_cell["H2S"]]),
            o2_gas=np.concatenate([gas_concentrations_per_cell["O2"]]),
            ch4_gas=np.concatenate([gas_concentrations_per_cell["CH4"]]),
            co2_gas=np.concatenate([gas_concentrations_per_cell["CO2"]]),
            n2_gas=np.concatenate([gas_concentrations_per_cell["N2"]]),
            h2s_gas=np.concatenate([gas_concentrations_per_cell["H2S"]]),
            o2_equilibrium=np.concatenate([equilibrium_per_cell["O2"]]),
            ch4_equilibrium=np.concatenate([equilibrium_per_cell["CH4"]]),
            co2_equilibrium=np.concatenate([equilibrium_per_cell["CO2"]]),
            n2_equilibrium=np.concatenate([equilibrium_per_cell["N2"]]),
            h2s_equilibrium=np.concatenate([equilibrium_per_cell["H2S"]]),
        )

        output_wq_parmas = ListWaterQualityParams(
            timestamps=timesteps, wqparams=out_wqps
        )

        return {
            "out_wqparams": output_wq_parmas,
            "ode_solution": solution,
            "add_results": cell_concentrations,
            # "input_water_quality": input_water_quality_matrix,
            # "process_parameters": process_parameters,
            # "initial_states": initial_states,
        }
