"""Collection of functions for loading data from matlab files."""

from typing import List
from dataclasses import fields
import scipy.io
import pandas as pd


from pystimela.datatypes import (
    WaterQualityParams,
    ListWaterQualityParams,
    CoagulationDosage,
    CoagulationParams,
    BackWashData,
)


def load_mat_waterqparameters(filename: str) -> ListWaterQualityParams:
    "Function for loading water quality parameters from a Matlab file."
    mat_file = scipy.io.loadmat(filename)
    # assuming there is only one dict key, coagulin or coagulout
    data_dict_key = list(mat_file.keys())[0]
    structured_array = mat_file[data_dict_key]
    data = []
    fnames = [f.name for f in fields(WaterQualityParams)]
    total_rows = structured_array.shape[1]
    timestamps = []
    for i in range(total_rows):
        kwargs = {}
        for col, name in enumerate(fnames):
            try:
                kwargs[str(name)] = structured_array[col][i]
                if str(name) == "timestamp":
                    timestamps.append(structured_array[col][i])
            except IndexError:  # water param field name is not in the file
                continue
        data.append(WaterQualityParams(**kwargs))

    return ListWaterQualityParams(timestamps=timestamps, wqparams=data)


def load_mat_coagulation_parameters(filename: str) -> CoagulationParams:
    "Function for loading coagulation parameters from a matlab file."
    mat_file = scipy.io.loadmat(filename)
    kwargs = {}
    structured_array = mat_file["P"][0, 0]
    for name in mat_file["P"][0].dtype.names:
        kwargs[name.lower()] = structured_array[name][0].astype(float)
    return CoagulationParams(**kwargs)


def load_mat_coagulation_dosage(filename: str) -> CoagulationDosage:
    "Function for loading coagulation dosage from matlab file"
    mat_file = scipy.io.loadmat(filename)
    # get the field names of the CoagulationDosage datatype
    fnames = [f.name for f in fields(CoagulationDosage)]
    # filter out the names of dosages that are not for coagulation
    rnames = [name for name in mat_file["P"][0].dtype.names if name.lower() in fnames]
    structured_array = mat_file["P"][0, 0]
    kwargs = {}
    for name in rnames:
        kwargs[name.lower()] = structured_array[name][0].astype(float)

    return CoagulationDosage(**kwargs)


def load_backwash(filename: str) -> BackWashData:
    "Loads Backwash events for filtration process."
    mat_file = scipy.io.loadmat(filename)
    # assuming there is only one dict key, coagulin or coagulout
    data_dict_key = list(mat_file.keys())[0]
    structured_array = mat_file[data_dict_key]
    kwargs = {}
    kwargs["timestamps"] = structured_array[0]
    kwargs["events"] = structured_array[1]
    return BackWashData(**kwargs)


def load_f_estimations(filename: str):
    """Loads filtration estimations"""
    mat_file = scipy.io.loadmat(filename)
    # assuming there is only one dict key, coagulin or coagulout
    data_dict_key = list(mat_file.keys())[0]
    structured_array = mat_file[data_dict_key]

    return {"timestamp": structured_array[0], "estimations": structured_array[1]}
