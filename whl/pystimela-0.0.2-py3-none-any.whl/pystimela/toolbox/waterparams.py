"""Functions for calculating various water quality parameters"""


def calc_kinimatic_viscosity(temp: float) -> float:
    """Returns the kinimatic viscosity in m2/s of water given
    the temperature in Celsious."""
    return 497e-6 / ((temp + 42.5) ** 1.5)


def calc_shear_rate(
    temp: float,
    g10: float,
) -> float:
    """Returns the shear rate of water.
    :param nu: current kinimatic viscosity
    :param g10: shear rate at 10 Celsius
    :param nu10: kinimatic viscosity at 10 Celsius
    """
    nu = calc_kinimatic_viscosity(temp)
    nu10 = calc_kinimatic_viscosity(10)

    return g10 * (nu10 / nu) ** 0.5


def calc_ionic_strenght(conductivity: float) -> float:
    """Returns the water's Ionic Strenght.
    :param conductivity: in mS/m
    """
    return 0.183 * conductivity


def calc_conductivity(ionic_strenght: float) -> float:
    """Returns the water's conductivity.
    :param ionic_strenght: ionic strenght in mS/m
    """
    return ionic_strenght / 0.183
