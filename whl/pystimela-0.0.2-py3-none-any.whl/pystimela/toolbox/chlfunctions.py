"""Functions that is mainly used in chlorination model"""

import logging
import math

from pystimela.datatypes import WaterQualityParams, ChlorinationState

logger = logging.getLogger(__name__)


def calc_acalc(s: ChlorinationState, wq: WaterQualityParams) -> float:
    """Returns Acalc parameter in chlorination model."""
    safe_reschl = max(s.reschl, 1e-12)
    safe_doc = max(wq.doc, 1e-12)
    safe_uv254 = max(wq.uv254_1_cm, 1e-12)
    safe_ammonia = max(wq.ammonia, 1e-12)
    safe_bromide = max(wq.bromide_in_microgrm, 1e-12)
    safe_temperature = max(wq.temperature, 1e-12)
    a_ln = (
        0.168
        - 0.148 * (math.log(safe_reschl) - math.log(safe_doc))
        + 0.29 * math.log(safe_uv254)
        - 0.41 * math.log(safe_reschl)
        + 0.038 * math.log(safe_bromide)
        + 0.0554 * math.log(safe_ammonia)
        + 0.185 * math.log(safe_temperature)
    )
    return math.exp(a_ln)


def calc_a(s: ChlorinationState, wq: WaterQualityParams) -> float:
    """Returns A parameter in chlorination model."""
    return min(calc_acalc(s, wq), 0.999)


def calc_k1(s: ChlorinationState, wq: WaterQualityParams) -> float:
    """Returns K1 parameter in chlorination model."""
    safe_reschl = max(s.reschl, 1e-12)
    safe_ammonia = max(wq.ammonia, 1e-12)
    safe_doc = max(wq.doc, 1e-12)
    safe_temperature = max(wq.temperature, 1e-12)
    safe_bromide = max(wq.bromide_in_microgrm, 1e-12)
    safe_ph = max(wq.ph, 1e-12)
    k1_ln = (
        5.41
        - 0.38 * (math.log(safe_reschl) - math.log(safe_doc))
        + 0.27 * math.log(safe_ammonia)
        - 1.12 * math.log(safe_temperature)
        + 0.05 * math.log(safe_bromide)
        - 0.854 * math.log(safe_ph)
    )
    return math.exp(k1_ln) / 3600


def calc_k2(s: ChlorinationState, wq: WaterQualityParams) -> float:
    """Returns K2 parameter in chlorination model."""
    safe_reschl = max(s.reschl, 1e-12)
    safe_doc = max(wq.doc, 1e-12)
    safe_suv254 = max(wq.suv254, 1e-12)
    safe_bromide = max(wq.bromide_in_microgrm, 1e-12)
    safe_ammonia = max(wq.ammonia, 1e-12)
    safe_temperature = max(wq.temperature, 1e-12)

    k2_ln = (
        -7.13
        + 0.86 * (math.log(safe_reschl) - math.log(safe_doc))
        + 2.63 * math.log(safe_doc)
        - 2.55 * math.log(safe_reschl)
        + 0.62 * math.log(safe_suv254)
        + 0.16 * math.log(safe_bromide)
        + 0.48 * math.log(safe_ammonia)
        + 1.03 * math.log(safe_temperature)
    )
    return math.exp(k2_ln) / 3600


def calc_a_tthm(s: ChlorinationState, wq: WaterQualityParams) -> float:
    """Returns Atthm parameter in chlorination model."""
    safe_reschl = max(s.reschl, 1e-12)
    safe_doc = max(wq.doc, 1e-12)
    safe_ammonia = max(wq.ammonia, 1e-12)
    safe_ph = max(wq.ph, 1e-12)
    atthmln = (
        -2.11
        - 0.87 * (math.log(safe_reschl) - math.log(safe_doc))
        - 0.41 * math.log(safe_ammonia)
        + 0.21 * math.log(safe_reschl)
        + 1.98 * math.log(safe_ph)
    )
    return math.exp(atthmln)


def calc_b_tthm(s: ChlorinationState, wq: WaterQualityParams) -> float:
    """Returns Btthm parameter in chlorination model."""
    safe_reschl = max(s.reschl, 1e-12)
    safe_doc = max(wq.doc, 1e-12)
    safe_suv254 = max(wq.suv254, 1e-12)
    safe_uv254_1_cm = max(wq.uv254_1_cm, 1e-12)
    safe_bromide = max(wq.bromide_in_microgrm, 1e-12)
    safe_ammonia = max(wq.ammonia, 1e-12)
    safe_ph = max(wq.ph, 1e-12)
    btthmln = (
        1.48
        - 1.11 * math.log(safe_suv254)
        - 0.67 * (math.log(safe_reschl) - math.log(safe_doc))
        + 0.27 * math.log(safe_uv254_1_cm)
        + 0.093 * math.log(safe_bromide)
        + 1.41 * math.log(safe_ph)
        + 0.13 * math.log(safe_ammonia)
    )

    return math.exp(btthmln)


def calc_ahaa6(s: ChlorinationState, wq: WaterQualityParams) -> float:
    """Returns Ahaa6 parameter in chlorination model for HAAs."""
    safe_reschl = max(s.reschl, 1e-12)
    safe_doc = max(wq.doc, 1e-12)
    safe_uv254_1_cm = max(wq.uv254_1_cm, 1e-12)
    safe_bromide = max(wq.bromide_in_microgrm, 1e-12)
    safe_ammonia = max(wq.ammonia, 1e-12)
    safe_suv254 = max(wq.suv254, 1e-12)
    ahaa6ln = (
        3.25
        + 0.86 * (math.log(safe_reschl) - math.log(safe_doc))
        + 0.066 * math.log(safe_uv254_1_cm)
        - 0.14 * math.log(safe_bromide)
        - 0.17 * math.log(safe_ammonia)
        + 0.25 * math.log(safe_suv254)
    )
    return math.exp(ahaa6ln)


def calc_bhaa6(s: ChlorinationState, wq: WaterQualityParams) -> float:
    """Returns Bhaa6 parameter in chlorination model for HAAs."""
    safe_reschl = max(s.reschl, 1e-12)
    safe_uv254_1_cm = max(wq.uv254_1_cm, 1e-12)
    safe_ph = max(wq.ph, 1e-12)
    bhaa6ln = (
        4.37
        + 1.11 * math.log(safe_reschl)
        - 0.30 * math.log(safe_uv254_1_cm)
        - 2.47 * math.log(safe_ph)
    )
    return math.exp(bhaa6ln)
