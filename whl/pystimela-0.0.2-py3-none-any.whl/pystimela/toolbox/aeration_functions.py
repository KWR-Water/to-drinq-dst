# Contains scientific functions that are common in aeration processes

import math
from typing import Literal
import numpy as np
from scipy.interpolate import interp1d

from pystimela.toolbox import constants_library as cl
from pystimela.helpers.common import celsious_to_kelvins


def calc_equalibrium_constants_pk1(water_temp: float):
    """Returns the equalibrium constant pk1.
    Args:
        water_temp: Water temperature in Celsius
    """
    temp_kelvin = celsious_to_kelvins(water_temp)
    return (
        356.3094
        + 0.06091964 * temp_kelvin
        - 21834.37 / temp_kelvin
        - 126.8339 * math.log10(temp_kelvin)
        + 1684915 / (temp_kelvin**2)
    )


def calc_equalibrium_constants_pk2(water_temp: float):
    """Returns the equalibrium constant pk2.
    Args:
        water_temp: Water temperature in Celsius
    """
    temp_kelvin = celsious_to_kelvins(water_temp)

    return (
        107.8871
        + 0.03252849 * temp_kelvin
        - 5151.79 / temp_kelvin
        - 38.92561 * math.log10(temp_kelvin)
        + 563713.9 / (temp_kelvin**2)
    )


def calc_water_vapor_pressure(air_temp: float) -> float:
    "Returns the water vapor pressure in Pa"
    return 1070 * math.exp(0.04986 * air_temp) - 525.1


def calc_gas_concentration_in_air(air_temp: float, water_vapor_lookup=False) -> dict:
    """Calculates gas concentrations in the air in [mol/m³]??.

    Args:
        air_temp is the air temperature in Celcius
        water_vapor_lookup: If True the water vapor pressure taken
                            by a fixed lookp table. Air temperature(air_temp)
                            must be with 0-50 Celsious

    Returns:dict= {
    O2, CH4, CO2,NS2, N2
    }
    """
    gas_constant = cl.UNIVERSAL_GAS_CONSTANT
    standard_pressure = cl.STANDARD_SEA_LEVEL_PRESURE_Pa
    molecular_weight = cl.MOLECULAR_WEIGHTS_mg_mol
    air_temp_rounded = round(air_temp)
    if water_vapor_lookup:
        try:
            water_vapor_pressure = cl.WATER_VAPOUR_PRESSURE_LOOKUP_Pa[air_temp_rounded]
        except KeyError as exc:
            raise ValueError("Air temperature must be between 0-50 Celsious.") from exc
    else:
        water_vapor_pressure = calc_water_vapor_pressure(air_temp=air_temp)
    temp_kelvin = celsious_to_kelvins(air_temp)
    gas_concentration_in_air = {
        "O2": (
            0.20948
            * (standard_pressure - water_vapor_pressure)
            * (molecular_weight["O2"] / 1000)
        )
        / (gas_constant * temp_kelvin),
        "CH4": 0,
        "CO2": (
            0.00032
            * (standard_pressure - water_vapor_pressure)
            * (molecular_weight["CO2"] / 1000)
        )
        / (gas_constant * temp_kelvin),
        "H2S": 0,
        "N2": (
            0.78084
            * (standard_pressure - water_vapor_pressure)
            * (molecular_weight["N2"] / 1000)
        )
        / (gas_constant * temp_kelvin),
    }

    return gas_concentration_in_air


def calc_distribution_coefficients(water_temp: float) -> dict:
    """Calculates the distribution coefficients for
    O2, CH4, CO2,NS2, N2 given the water temperature in Celcious.

    Temperature-dependent distribution coefficients
    by intermediate temperatures by linear interpolation
    """
    distribution_coefficient = {
        "O2": 0.02727 * math.exp(-0.0426 * water_temp) + 0.02202,
        "CH4": 0.03227 * math.exp(-0.05315 * water_temp) + 0.02352,
        "CO2": 1.307 * math.exp(-0.04489 * water_temp) + 0.4015,
        "N2": 5.75e-6 * water_temp**2 - 0.0004355 * water_temp + 0.023,
        "H2S": 0.001175 * water_temp**2 - 0.1148 * water_temp + 4.688,
    }
    return distribution_coefficient


def calc_distribution_coefficients_hendrys_law(water_temp: float) -> dict:
    """Calculates the distribution coefficients based on Henry's law for
    O2, CH4, CO2,NS2, N2 given the water temperature in Celcious.

    Temperature-dependent distribution coefficients
    by intermediate temperatures by linear interpolation
    """
    temp_for_interp = np.array([0, 10, 20, 30])  # [°C]
    kd_values = {
        "O2": np.array([0.0493, 0.0398, 0.0337, 0.0296]),
        "CH4": np.array([0.0556, 0.0433, 0.0335, 0.0306]),
        "CO2": np.array([1.7100, 1.2300, 0.9420, 0.7380]),
        "N2": np.array([0.0230, 0.0192, 0.0166, 0.0151]),
        "H2S": np.array([4.6900, 3.6500, 2.8700, 2.3000]),
    }

    # Interpolate distribution coefficients
    distribution_coefficient = {}
    for gas, kd_val in kd_values.items():
        interp_func = interp1d(temp_for_interp, kd_val, kind="linear")
        distribution_coefficient[gas] = float(interp_func(water_temp))
    return distribution_coefficient


def calc_diffusion_coefficients(water_temp: float) -> dict:
    """Calculates the diffusion coefficents [m²/s] for
    O2, CH4, CO2,NS2, N2 given the water temperature in Celcious.

    best fit at 10, 20 and 30 degrees Celsius, usable from 0-40 Celsius
    """
    diffusion_coefficient = {
        "O2": 1
        / (0.9048299 - 0.01961736 * water_temp + 1.076824e-4 * water_temp**2)
        * 1e-9,
        "CH4": 1
        / (1.081256 - 0.023108 * water_temp + 1.189257e-4 * water_temp**2)
        * 1e-9,
        "CO2": 1
        / (0.9644559 - 0.02058414 * water_temp + 1.061623e-4 * water_temp**2)
        * 1e-9,
        "H2S": 1
        / (1.15095 - 0.02461722 * water_temp + 1.265363e-4 * water_temp**2)
        * 1e-9,
        "N2": 1
        / (0.9874819 - 0.02112977 * water_temp + 1.121742e-4 * water_temp**2)
        * 1e-9,
    }
    return diffusion_coefficient


def calc_gas_transfer_coefficient(
    water_temp: float,
    methane_transfer_coeff: float,
) -> dict:
    """Returns the gas transfer coefficient for
    O2, CO2, H2S, N2.
    :param water temp: water temperature in Celsious
    :param methane_transfer_coeff: methane transfer coefficient k2
    """
    gases = ["O2", "CO2", "H2S", "N2"]
    # Diffusion coefficients [m²/s]
    # best fit at 10, 20 and 30 degrees Celsius, usable from 0-40 Celsius
    diffusion_coefficient = calc_diffusion_coefficients(water_temp=water_temp)

    # Gas transfer coefficients based on methane coefficient
    diffusion_power = 1
    gas_transfer_coefficient = {
        gas: methane_transfer_coeff
        * (diffusion_coefficient[gas] / diffusion_coefficient["CH4"]) ** diffusion_power
        for gas in gases
    }
    return gas_transfer_coefficient


def create_iron_oxidation_profile(
    num_cells: int,
    iron_concentration: float,
    iron3_concentration: float,
    oxidation_rate: int,
):
    """
    Creates iron oxidation profiles for cascaded reactor cells

    Args:
        iron_concentration: Initial Fe⁺ concentration [mol/m³]
        iron3_concentration: Initial Fe³⁺ concentration [mol/m³]
        num_cells: Number of reactor cells
        oxidation_rate: Rate parameter for iron oxidation (default: 3)

    Returns:
        dict: {
            'total_oxidation_steps': cumulative oxidation steps,
            'Fe': Fe⁺ oxidation profile vector,
            'Fe_oxidized': Fe³⁺ oxidation profile vector
        }
    """
    # Calculate cumulative oxidation steps
    oxidation_steps = np.cumsum(
        np.arange(1, oxidation_rate * num_cells + 1, oxidation_rate)
    )

    # Normalize iron concentrations by total oxidation steps
    iron_per_step = iron_concentration / oxidation_steps[-1]
    iron3_per_step = iron3_concentration / oxidation_steps[-1]

    # Create oxidation profiles
    iron_oxidation_profile = iron_per_step * np.arange(
        1, oxidation_rate * num_cells + 1, oxidation_rate
    )
    iron3_formation_profile = iron3_per_step * np.arange(
        1, oxidation_rate * num_cells + 1, oxidation_rate
    )

    # Reshape to column vectors
    iron_oxidation_profile = iron_oxidation_profile.reshape(-1)
    iron3_formation_profile = iron3_formation_profile.reshape(-1)

    # Note: Original code had commented-out reversal operations
    # These can be uncommented if reverse flow is needed:
    # iron_oxidation_profile = np.flip(iron_oxidation_profile, axis=0)
    # iron3_formation_profile = np.flip(iron3_formation_profile, axis=0)

    return {
        "total_oxidation_steps": oxidation_steps,
        "Fe": iron_oxidation_profile,
        "Fe_oxidized": iron3_formation_profile,
    }


def create_calcium_percipitation_profile(
    num_cells: int,
    ca_concentration: float,
    caco3_concentration: float,
    softening_rate: int,
):
    """
    Creates Ca and CaCO3 percipitation profiles for cascaded reactor cells

    Args:
        ca_concentration: Initial Ca concentration [mol/m³]
        caco3_concentration: Initial CaCO3 concentration [mol/m³]
        num_cells: Number of reactor cells
        softening_rate: Rate parameter forCa percipitation (default: 3)

    Returns:
        dict: {
            'total_softening_steps': cumulative softening steps,
            'Ca': Ca percipitation profile vector,
            'Ca_precipitated': CaCO3 percipitation profile vector
        }
    """
    # Calculate cumulative percipitation steps
    softenening_steps = np.cumsum(
        np.arange(1, softening_rate * num_cells + 1, softening_rate)
    )

    # Normalize ca concentrations by total oxidation steps
    ca_per_step = ca_concentration / softenening_steps[-1]
    caco3_per_step = caco3_concentration / softenening_steps[-1]

    # Create oxidation profiles
    ca_profile = ca_per_step * np.arange(
        1, softening_rate * num_cells + 1, softening_rate
    )
    caco3_profile = caco3_per_step * np.arange(
        1, softening_rate * num_cells + 1, softening_rate
    )

    # Reshape to column vectors
    ca_profile = ca_profile.reshape(-1)
    caco3_profile = caco3_profile.reshape(-1)

    # Note: Original code had commented-out reversal operations
    # These can be uncommented if reverse flow is needed:
    # iron_oxidation_profile = np.flip(iron_oxidation_profile, axis=0)
    # iron3_formation_profile = np.flip(iron3_formation_profile, axis=0)

    return {
        "total_softening_steps": softenening_steps,
        "Ca": ca_profile,
        "Ca_precipitated": caco3_profile,
    }
