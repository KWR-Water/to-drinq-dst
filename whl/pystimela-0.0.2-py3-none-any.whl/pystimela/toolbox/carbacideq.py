"""Functions for Carbonic Acid Equilibrium"""

import math
import numpy as np
from pystimela.datatypes import KValues
from pystimela.helpers.common import celsious_to_kelvins


def calc_activity(ionic_strength: float) -> float:
    """Returns the activity
    :param ionic_strength: ionic strength in mS/m"""
    sqrt_is = math.sqrt(ionic_strength)
    sqrt_1e3 = 31.622776601683793  # precomputed sqrt(1000)
    r_exponent = -(0.5 * sqrt_is / (sqrt_1e3 + sqrt_is) - 0.00015 * ionic_strength)
    return math.pow(10.0, r_exponent)


def calculate_activity_coefficient(charge, ion_size, conductivity):
    """
    Calculates ion activity coefficient using Davies approximation (equivalent to fi)

    Args:
        charge: Ion charge (z)
        ion_size: Effective ion size parameter (a) in angstroms
        conductivity: Electrical conductivity (EGV) in mS/m

    Returns:
        Activity coefficient (fif)

    Raises:
        ValueError: If ionic strength is out of valid range
    """
    # Convert conductivity from mS/m to S/m
    conductivity_sm = conductivity / 1000

    # Calculate ionic strength (mol/l)
    ionic_strength = 0.183 * conductivity_sm

    if ionic_strength < 0:
        raise ValueError("Ionic strength cannot be negative")
    elif ionic_strength < 0.1:
        # Debye-Hückel approximation for low ionic strength
        term = np.sqrt(ionic_strength) / (1 + 0.33 * ion_size * np.sqrt(ionic_strength))
        activity_coeff = 10 ** (-0.5 * (charge**2) * term)
    elif ionic_strength <= 0.5:
        # Davies equation extension for moderate ionic strength
        term = (
            np.sqrt(ionic_strength) / (1 + 0.33 * ion_size * np.sqrt(ionic_strength))
        ) - 0.2 * ionic_strength
        activity_coeff = 10 ** (-0.5 * (charge**2) * term)
    else:
        raise ValueError("Ionic strength exceeds maximum valid value of 0.5 mol/l")

    return activity_coeff


def calc_k_values(temp: float) -> KValues:
    """Returns the chemical equalibrium constants K
        ks constant is not calculated.
    :param temp: water temperature in Celsius.
    """
    tempk = celsious_to_kelvins(temp)

    # precomputed constants for performance
    log_tempk = math.log10(tempk)
    inv_tempk = 1.0 / tempk
    inv_tempk2 = inv_tempk * inv_tempk

    # k1
    k_1_exp = (
        3
        - 356.3094
        - 0.06091964 * tempk
        + 21834.37 * inv_tempk
        + 126.8339 * log_tempk
        - 1684915 * inv_tempk2
    )
    k1 = 10**k_1_exp

    # k2
    k_2_exp = (
        3
        - 107.8871
        - 0.03252849 * tempk
        + 5151.79 * inv_tempk
        + 38.92561 * log_tempk
        - 563713.9 * inv_tempk2
    )
    k2 = 10**k_2_exp

    k_w_exp = 6 - 4787.3 * inv_tempk - 7.1321 * log_tempk - 0.010365 * tempk + 22.801
    kw = 10.0**k_w_exp

    return KValues(k1, k2, kw)


def ce_h3o(ph: float, activity: float) -> float:
    "Returns H3O given activity."

    return 10.0 ** (3 - ph) / activity


def ce_phm_co2(ph: float, mn: float, kv: KValues, activity: float) -> float:
    """Returns CO2.
    :param ph: pH
    :param mn: M alkalinity
    :param kv: K1, K2, Kw  KValues
    :param activity: Activity

    """
    h3o = ce_h3o(ph, activity)
    n_kv = KValues.from_activity(kv.k1, kv.k2, kv.kw, activity)
    co2 = (-n_kv.kw + h3o * mn + h3o**2) / (2 * n_kv.k2 + h3o) * h3o / n_kv.k1
    return co2


def ce_phm_co3(ph: float, mn: float, kv: KValues, activity: float) -> float:
    """Returns CO3.
    :param ph: pH
    :param mn: M alkalinity
    :param kv: K1, K2, Kw  KValues
    :param activity: Activity

    """
    h3o = ce_h3o(ph, activity)
    n_kv = KValues.from_activity(kv.k1, kv.k2, kv.kw, activity)
    return n_kv.k2 * (-n_kv.kw + h3o * mn + h3o**2) / (2 * n_kv.k2 + h3o) / h3o


def ce_ph_co2_m(ph: float, co2: float, kv: KValues, activity: float) -> float:
    """calculation of M using pH and CO2"""
    h3o = ce_h3o(ph, activity)
    n_kv = KValues.from_activity(kv.k1, kv.k2, kv.kw, activity)
    m = (
        -(-2 * n_kv.k1 * co2 * n_kv.k2 - n_kv.k1 * co2 * h3o - n_kv.kw * h3o + h3o**3)
        / h3o**2
    )
    return m


def ce_co2m_ph(co2: float, m: float, kv: KValues, activity: float, ph0=7) -> float:
    """
    Calculation of pH using CO2 and M using Newton-Raphson iteration

    Parameters:
    co2 : float - CO2 concentration
    m : float - M value
    k1, k2, kw : float - Equilibrium constants
    f : float - Ionic strength correction factor
    ph0 : float - Initial pH guess (default=7)

    Returns:
    float - Calculated pH value
    """
    tol = 1e-3
    iter_count = 0
    iter_max = 200
    ph = ph0

    # Check if M > 0
    if np.any(co2 > 0):
        fnk = ce_ph_co2_m(ph=ph0, co2=co2, kv=kv, activity=activity) - m

        ph = ph0
        ph0 = ph + 1

        # Main iteration loop
        while np.any(np.abs(ph - ph0) > tol) and (iter_count <= iter_max):
            iter_count += 1
            ph0 = ph

            # Set dx for differentiation
            dph = ph * tol if ph != 0 else tol

            # Differentiation
            pha = ph - dph
            fnka = ce_ph_co2_m(ph=pha, co2=co2, kv=kv, activity=activity) - m

            df = (fnk - fnka) / (ph - pha)

            # Next approximation of the root
            if df == 0:
                ph = ph0 + 1.1 * tol
                print("Warning: Differentiation failed")
            else:
                ph = ph0 - fnk / df

            # Keep pH within valid range
            ph = np.clip(ph, 0, 14)

            fnk = ce_ph_co2_m(ph=ph, co2=co2, kv=kv, activity=activity) - m

    else:
        fnk = ce_phm_co2(ph=ph0, mn=m, kv=kv, activity=activity) - co2

        ph = ph0
        ph0 = ph + 1

        # Main iteration loop
        while np.any(np.abs(ph - ph0) > tol) and (iter_count <= iter_max):
            iter_count += 1
            ph0 = ph

            # Set dx for differentiation
            dph = ph * tol if ph != 0 else tol

            # Differentiation
            pha = ph - dph
            fnka = ce_phm_co2(ph=pha, mn=m, kv=kv, activity=activity) - co2

            df = (fnk - fnka) / (ph - pha)

            # Next approximation of the root
            if df == 0:
                ph = ph0 + 1.1 * tol
                print("Warning: Differentiation failed")
            else:
                ph = ph0 - fnk / df

            # Keep pH within valid range
            ph = np.clip(ph, 0, 14)

            fnk = ce_phm_co2(ph=ph, mn=m, kv=kv, activity=activity) - co2

    if iter_count >= iter_max:
        raise ValueError(f"Maximum iterations reached. ph = {ph}")

    return ph


def calculate_ph_from_co2(
    co2_liquid: float, hco3: float, water_temp: float, conductivity: float
) -> float:
    """Calculates ph.
    Args:
        co2_liquid: CO2 liquid concentration in mg/lt
        hco3: HCO3  concentration in mg/lt
        water_temp: water temperature in Celsious
        conductivity: conductivity in mS/m
    """
    # calculate equilibrium constatns
    kv = calc_k_values(temp=water_temp)
    ph = (
        kv.k1
        - math.log10(co2_liquid)
        + math.log10(hco3)
        * calculate_activity_coefficient(
            charge=1, ion_size=4, conductivity=conductivity
        )
    )
    return ph


def ce_phm_hco3(ph: float, mn: float, kv: KValues, activity: float) -> float:
    """Returns HCO3.
    :param ph: pH
    :param mn: M alkalinity
    :param kv: K1, K2, Kw  KValues
    :param activity: Activity

    """
    h3o = ce_h3o(ph, activity)
    n_kv = KValues.from_activity(kv.k1, kv.k2, kv.kw, activity)
    return (-n_kv.kw + h3o * mn + h3o**2) / (2 * n_kv.k2 + h3o)


def ce_phm_p(ph: float, mn: float, kv: KValues, activity: float) -> float:
    """Returns P.
    :param ph: pH
    :param mn: M alkalinity
    :param kv: K1, K2, Kw  KValues
    :param activity: Activity

    """
    h3o = ce_h3o(ph, activity)
    n_kv = KValues.from_activity(kv.k1, kv.k2, kv.kw, activity)
    return (
        -(
            -n_kv.kw * n_kv.k2 * n_kv.k1
            - n_kv.k1 * n_kv.k2 * h3o * mn
            + n_kv.k2 * n_kv.k1 * (h3o**2)
            - (h3o**2) * n_kv.kw
            + (h3o**3) * mn
            + h3o**4
            - n_kv.kw * n_kv.k1 * h3o
            + (h3o**3) * n_kv.k1
        )
        / (2 * n_kv.k2 + h3o)
        / h3o
        / n_kv.k1
    )


def ce_php_m(ph: float, pn: float, kv: KValues, activity: float) -> float:
    """Returns M Alkalinity.
    :param ph: pH
    :param pn: P proton concentration?
    :param kv: K1, K2, Kw  KValues
    :param activity: Activity

    """
    h3o = ce_h3o(ph, activity)
    n_kv = KValues.from_activity(kv.k1, kv.k2, kv.kw, activity)
    return (
        -(
            2 * pn * h3o * n_kv.k2 * n_kv.k1
            - n_kv.kw * n_kv.k2 * n_kv.k1
            + n_kv.k2 * n_kv.k1 * (h3o**2)
            + n_kv.k1 * (h3o**2) * pn
            - n_kv.kw * n_kv.k1 * h3o
            + (h3o**3) * n_kv.k1
            - (h3o**2) * n_kv.kw
            + (h3o**4)
        )
        / (-n_kv.k2 * n_kv.k1 + (h3o**2))
        / h3o
    )


def ce_mp_ph(m: float, p: float, kv: KValues, activity: float, ph0=7) -> float:
    """Returns pH.
    :param m: M Alkalinity
    param p: P proton concentration?
    :param kv: K1, K2, Kw  KValues
    :param activity: Activity
    :ph0: pH
    """
    tol = 1e-3
    itermax = 200
    ph_prev = ph0
    ph_new = ph_prev

    if m > 0:
        func = lambda ph: ce_phm_p(ph, m, kv, activity) - p
    else:
        func = lambda ph: ce_php_m(ph, p, kv, activity) - m

    # Iterative calculation
    for _ in range(itermax):
        # Differentiation step size
        dph = max(ph_prev * tol, tol)

        fnk = func(ph_prev)
        fnka = func(ph_prev - dph)
        # Numerical differentiation
        df = (fnk - fnka) / dph

        if df == 0:
            df = ph_prev + 1.1 * tol

        # Update pH values
        ph_new = ph_prev - fnk / df

        # Keep pH in valid range
        ph_new = min(max(ph_new, 0), 14)
        # Check for convergence
        if abs(ph_new - ph_prev) < tol:
            return ph_new

        ph_prev = ph_new
    # Raise error if not converged
    raise RuntimeError(f"Maximum iterations ({itermax}) reached without convergence.")

    """ if np.any(m > 0):
        fnk = ce_phm_p(ph=ph0, mn=m, kv=kv, activity=activity) - p

        ph = ph0
        ph0 = ph + 1

        while np.any(np.abs(ph - ph0) > tol) and (iter_count <= itermax):
            iter_count += 1
            ph0 = ph

            dph = ph * tol if ph != 0 else tol
            pha = ph - dph

            fnka = ce_phm_p(ph=pha, mn=m, kv=kv, activity=activity) - p
            df = (fnk - fnka) / (ph - pha)

            if df == 0:
                ph = ph0 + 1.1 * tol
                print("Warning: Differentiation failed")
            else:
                ph = ph0 - fnk / df

            ph = np.clip(ph, 0, 14)
            fnk = ce_phm_p(ph=ph, mn=m, kv=kv, activity=activity) - p

        if iter_count >= itermax:
            raise RuntimeError(f"Maximum iterations reached. pH = {ph}")

    else:
        fnk = ce_php_m(ph=ph0, pn=p, kv=kv, activity=activity) - m

        ph = ph0
        ph0 = ph + 1

        while np.any(np.abs(ph - ph0) > tol) and (iter_count <= itermax):
            iter_count += 1
            ph0 = ph

            dph = ph * tol if np.any(ph != 0) else tol
            pha = ph - dph

            fnka = ce_php_m(ph=pha, pn=p, kv=kv, activity=activity) - m
            df = (fnk - fnka) / (ph - pha)

            if (df == 0).any():
                ph = ph0 + 1.1 * tol
                print("Warning: Differentiation failed")
            else:
                ph = ph0 - fnk / df

            ph = np.clip(ph, 0, 14)
            fnk = ce_php_m(ph=ph, pn=p, kv=kv, activity=activity) - m

        if iter_count >= itermax:
            raise RuntimeError(f"Maximum iterations reached. pH = {ph}")

    return ph
 """
