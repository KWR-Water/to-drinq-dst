# file related functions


def convert_name_r(rname: str) -> str:
    """Convert a camel case variable name"""
    lowername = rname.lower()
    return lowername.replace(".", "_")
