"""Library of commonly used functions"""

import bisect
import numpy as np
from numpy.typing import NDArray
from typing import List


def celsious_to_kelvins(temp: float) -> float:
    """Covnerts temperature from Celsious to Kelvins."""
    return temp + 273.16


def create_matrix(N: int) -> NDArray:
    """Helper function to construct a sparse matrix to represent flow between layers"""
    matrix = np.zeros((N, N + 1))
    for i in range(N):
        matrix[i, i] = 1
        matrix[i, i + 1] = -1
    return matrix


def find_interval(time, timesteps: list) -> int:
    """Finds the appropriate time interval index"""
    # pos = np.searchsorted(timesteps, time, side="right") - 1
    pos = bisect.bisect_right(timesteps, time) - 1
    if pos < 0:
        return 0
    elif pos >= len(timesteps):
        return len(timesteps) - 1
    return pos


def create_matrix2(dy: float, n: int):
    """
    Build the finite-difference coefficient matrix for film discretization.

    Parameters
    ----------
    dy : float
        Grid spacing.
    N : int
        Number of discretization points.

    Returns
    -------
    q1 : ndarray, shape (N, N+1)
        The coefficient matrix.
    """
    # Calculate coefficients
    a1 = 1.0 / dy
    a2 = -1.0 / dy
    alpha = -1.0 / dy
    beta = 1.0 / dy

    # Initialize zero matrix
    q1 = np.zeros((n, n + 1))

    # Fill main diagonal (columns 0..N-1)
    #   entries [0,0] through [N-2,N-2] = a1, and [N-1,N-1] = beta
    main_diag = np.hstack([np.full(n - 1, a1), [beta]])
    q1[np.arange(n), np.arange(n)] = main_diag

    # Fill superdiagonal (offset +1)
    #   entries [i, i+1] for i=0..N-2 = a2
    q1[np.arange(n - 1), np.arange(1, n)] = a2

    # Last superdiagonal element at bottom-right corner [N-1, N] = alpha
    q1[n - 1, n] = alpha

    return q1


def create_banded_matrix(t: float, n: int):
    """Return  a banded matrix.
    t must have lenth n ??
    In R code t is a single number
    """
    # if len(t) != n:
    #     raise ValueError(f"t must have lenght of n: {n}.")

    m = np.zeros((n, n + 1))
    # fill the main diagonal
    m[np.arange(n), np.arange(n)] = 1 / t

    # fill the upper diagonal
    m[np.arange(n), np.arange(1, n + 1)] = -(1 / t)

    return m


def create_spdiag_matrix(t: float, n: int):
    """Return  a spdiag matrix.
    t must have lenth n ??
    """
    # if len(t) != n:
    #     raise ValueError(f"t must have lenght of n: {n}.")

    m = np.zeros((n, n + 1))

    # fill the upper diagonal
    m[np.arange(n), np.arange(1, n + 1)] = -(1 / t)

    # fill the first column
    m[:, 0] = 1 / t

    return m


def create_flow_mixing_matrix(residence_time, num_cells):
    """
    Creates a banded flow mixing matrix for cascaded reactors (equivalent to Matrix1)

    Args:
        residence_time: Time step/residence time (scalar or array)
        num_cells: Number of reactor cells

    Returns:
        A num_cells x (num_cells+1) flow mixing matrix
    """
    # Initialize matrix
    mixing_matrix = np.zeros((num_cells, num_cells + 1))

    # Fill main diagonal (i,i) with 1/T
    np.fill_diagonal(mixing_matrix[:, :-1], 1 / residence_time)

    # Fill upper diagonal (i,i+1) with -1/T
    np.fill_diagonal(mixing_matrix[:, 1:], -1 / residence_time)

    return mixing_matrix


def create_percipitation_oxidation_matrix(residence_time, num_cells):
    """
    Creates a matrix for iron oxidation reactions (equivalent to Matrix3)

    Args:
        residence_time: Time step/residence time
        num_cells: Number of reactor cells

    Returns:
        A num_cells x (2*num_cells) iron oxidation matrix
    """
    rate = 1 / residence_time
    matrix = np.zeros((num_cells, 2 * num_cells))

    # Fill main diagonal with rate
    np.fill_diagonal(matrix[:, :num_cells], rate)

    # Fill Nth diagonal with -rate
    np.fill_diagonal(matrix[:, num_cells:], -rate)

    return matrix


def create_calcium_precip_matrix(residence_time, num_cells):
    """
    Creates a matrix for calcium precipitation (equivalent to Matrix4)

    Args:
        residence_time: Time step/residence time
        num_cells: Number of reactor cells

    Returns:
        A num_cells x (num_cells+1) calcium precipitation matrix
    """
    rate = 1 / residence_time
    matrix = np.zeros((num_cells, num_cells + 1))

    # Fill superdiagonal with -rate
    np.fill_diagonal(matrix[:, 1:], -rate)

    # Set last element of first column to rate
    matrix[-1, 0] = rate

    return matrix
