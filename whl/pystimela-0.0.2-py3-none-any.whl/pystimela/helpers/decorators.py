# decorator functions

from dataclasses import fields
from typing import Any, Type


def auto_doc(cls: Type[Any]) -> Type[Any]:
    doc_lines = [f"{cls.__name__}("]
    for f in fields(cls):
        desc = f.metadata.get("desc", "")
        units = f.metadata.get("units", "-")
        doc_lines.append(f"  {f.name}: (units: {units}) {desc}")
    doc_lines.append(")")
    cls.__doc__ = "\n".join(doc_lines)
    return cls
