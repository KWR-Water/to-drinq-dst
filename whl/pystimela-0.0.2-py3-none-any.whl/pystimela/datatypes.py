# datatypes.py
from abc import ABC, abstractmethod
from typing import List, Literal, get_origin, Dict
from dataclasses import dataclass, field, fields

import numpy as np
import pandas as pd
import scipy.io
from numpy.typing import NDArray

from pystimela.helpers.decorators import auto_doc
from pystimela.helpers.fileops import convert_name_r


@auto_doc
@dataclass
class WaterQualityParams:
    """Data Class for water quality parameters."""

    timestamp: float = field(
        default=0,
        metadata={"units": "seconds", "code": "Timestamp", "desc": "Timestamp"},
    )

    # TODO: update default values per field
    flow: float = field(
        default=200, metadata={"units": "m^3/h", "code": "F", "desc": "Flow"}
    )
    temperature: float = field(
        default=15, metadata={"units": "^oC", "code": "T", "desc": "Temperature"}
    )
    suspended_solids: float = field(
        default=0, metadata={"units": "mg/lt", "code": "SS", "desc": "Suspended solids"}
    )
    # TODO: check turbidity unit relation between FTE and NTU
    turbidity: float = field(
        default=0, metadata={"units": "FTE", "code": "TB", "desc": "Turbidity"}
    )
    doc: float = field(
        default=0,
        metadata={"units": "mg/lt", "code": "DOC", "desc": "Dissolved organic carbon"},
    )
    ozone: float = field(
        default=0, metadata={"units": "mg/lt", "code": "O3", "desc": "Ozone"}
    )
    oxygen: float = field(
        default=0, metadata={"units": "mg/lt", "code": "O2", "desc": "Oxygen"}
    )
    methane: float = field(
        default=0, metadata={"units": "mg/lt", "code": "CH4", "desc": "Methane"}
    )
    carbon_dioxide: float = field(default=0, metadata={"units": "mg/lt", "code": "CO2"})
    conductivity: float = field(
        default=0, metadata={"units": "mS/m", "code": "EGV", "desc": "Conductivity"}
    )
    iron2: float = field(
        default=0, metadata={"units": "mg/lt", "code": "Fe2", "desc": "Iron2"}
    )
    iron3: float = field(
        default=0, metadata={"units": "mg/lt", "code": "Fe3", "desc": "Iron3"}
    )
    calcium: float = field(
        default=0, metadata={"units": "mg/lt", "code": "Ca", "desc": "Calcium"}
    )
    magnesium: float = field(
        default=0, metadata={"units": "mg/lt", "code": "Mg", "desc": "Magnesium"}
    )
    calcium_carbonate: float = field(
        default=0,
        metadata={"units": "mg/lt", "code": "CaCO3", "desc": "Calcium carbonate"},
    )
    nitrogen: float = field(
        default=0, metadata={"units": "mg/lt", "code": "N2", "desc": "Nitrogen"}
    )
    hydrogen_sulfide: float = field(
        default=0,
        metadata={"units": "mg/lt", "code": "H2S", "desc": "Hydrogen sulfide"},
    )
    atrazine: float = field(
        default=0, metadata={"units": "mg/lt", "code": "Atr", "desc": "Atrazine"}
    )
    ammonia: float = field(
        default=0, metadata={"units": "mg/lt", "code": "NH4", "desc": "Ammonia"}
    )
    nitrite: float = field(
        default=0, metadata={"units": "mg/lt", "code": "NO2", "desc": "Nitrite"}
    )
    nitrate: float = field(
        default=0, metadata={"units": "mg/lt", "code": "NO3", "desc": "Nitrate"}
    )
    phosphate: float = field(
        default=0, metadata={"units": "mg/lt", "code": "PO4", "desc": "Phosphate"}
    )
    bicarbonate: float = field(
        default=0, metadata={"units": "mg/lt", "code": "HCO3", "desc": "Bicarbonate"}
    )
    ph: float = field(default=7, metadata={"units": "pH", "code": "PH", "desc": "pH"})
    mnumber: float = field(
        default=0,
        metadata={
            "units": "mmol/lt",
            "code": "M",
            "desc": "M alkalinity",
        },
    )
    pnumber: float = field(
        default=0, metadata={"units": "mmol/lt", "code": "P", "desc": "Pnumber"}
    )
    ionstrength: float = field(
        default=0, metadata={"units": "mmol/lt", "code": "IS", "desc": "Ionstrength"}
    )
    uv254: float = field(
        default=0, metadata={"units": "1/m", "code": "UV254", "desc": "UV254"}
    )
    bromide: float = field(
        default=0, metadata={"units": "mg/lt", "code": "Br", "desc": "Bromide"}
    )
    sulphate: float = field(
        default=0, metadata={"units": "mg/lt", "code": "SO4", "desc": "Sulphate"}
    )
    viruses: float = field(
        default=0, metadata={"units": "-", "code": "Vr", "desc": "Viruses"}
    )
    giardia: float = field(
        default=0, metadata={"units": "-", "code": "Gi", "desc": "Giardia"}
    )
    cryptosporidium: float = field(
        default=0, metadata={"units": "-", "code": "Cr", "desc": "Cryptosporidium"}
    )
    trichlooretheen: float = field(
        default=0,
        metadata={"units": "mg/lt", "code": "Cl3CH4", "desc": "Trichlooretheen"},
    )
    dichloorpropaan: float = field(
        default=0,
        metadata={"units": "mg/lt", "code": "Cl2CH4", "desc": "Dichloorpropaan"},
    )
    volatile_compound: float = field(
        default=0,
        metadata={"units": "mmol/lt", "code": "VC", "desc": "Volatile compound"},
    )
    acetic_acid: float = field(
        default=0, metadata={"units": "mg/lt", "code": "AA", "desc": "Acetic Acid"}
    )
    initiele_uva254: float = field(
        default=0,
        metadata={"units": "1/m", "code": "iniUVA254", "desc": "Initiele UVA254"},
    )
    bromate: float = field(
        default=0, metadata={"units": "ug/L", "code": "BrO3", "desc": "Bromate"}
    )
    ozone_dosed: float = field(
        default=0, metadata={"units": "mg/L?", "code": "O3Dos", "desc": "Ozone dosed"}
    )
    ozone_dos_kuv: float = field(
        default=0,
        metadata={"units": "mg/L?", "code": "O3Dos_kUV", "desc": "Ozone dos kUV"},
    )
    ecoli: float = field(
        default=0, metadata={"units": "-", "code": "Ec", "desc": "Ecoli"}
    )
    aoc: float = field(
        default=0,
        metadata={"units": "ug/L", "code": "AOC", "desc": "Assimilable Organic Carbon"},
    )
    gas_flow: float = field(
        default=0, metadata={"units": "m3/h", "code": "Qg", "desc": "gas flow"}
    )
    cgo_o3: float = field(
        default=0,
        metadata={
            "units": "g/Nm3",
            "code": "cgoO3",
            "desc": " ozone concentration in gas",
        },
    )

    @property
    def uv254_1_cm(self) -> float:
        "returns the uv254 in 1/cm"
        return self.uv254 / 100

    @property
    def suv254(self) -> float:
        "units L/mg/m"
        try:
            return self.uv254 / self.doc
        except ZeroDivisionError:
            return 0

    @property
    def bromide_in_microgrm(self) -> float:
        """Return the bromide in μg/L"""
        return self.bromide * 1000

    @property
    def flow_per_sec(self):
        "Return the flow in m3/sec"
        return self.flow / 3600

    def __eq__(self, other):
        if not isinstance(other, WaterQualityParams):
            return False
        for f in fields(self):
            value_self = getattr(self, f.name)
            value_other = getattr(other, f.name)
            # Handle other cases with standard equality
            if value_self != value_other:
                return False

        return True

    def to_numpy(self):
        """Returns the water quality data in a 1D numpy array"""
        values = [getattr(self, f.name) for f in fields(self)]
        return np.array(values)


@auto_doc
@dataclass
class ListWaterQualityParams:
    """Class for holding multiple Water Quality parameters for a descrete time period."""

    timestamps: List[float] = field(
        metadata={"desc": "list holding the timestamps in secs?"}
    )
    wqparams: List[WaterQualityParams] = field(
        metadata={"desc": "list holding water qualtity params objects per timestamp"}
    )

    def to_dataframe(self) -> pd.DataFrame:
        """Returns the data in pandas dataframe with timestamps as index"""
        param_names = [f.name for f in fields(WaterQualityParams)]
        data_dict: Dict = {param_name: [] for param_name in param_names}
        for wq_param in self.wqparams:
            for param_name in param_names:
                data_dict[param_name].append(getattr(wq_param, param_name))
        return pd.DataFrame.from_dict(data_dict)

    @classmethod
    def from_csv(cls, filepath: str, correct_names=True):
        """Loads a csv file with wqparams from R script"""
        df = pd.read_csv(filepath)
        if correct_names:
            new_columns = [convert_name_r(col) for col in df.columns]
            # replace column name timestep
            new_columns[0] = "timestamp"
            df.columns = pd.Index(new_columns)
            # replace some column names
            map_columns = {"virusses": "viruses", "qg": "gas_flow", "cgoo3": "cgo_o3"}
            df.rename(columns=map_columns, inplace=True)

        data_dict = df.to_dict(orient="records")
        wq_params = []
        timestamps = []

        for d in data_dict:
            timestamps.append(d["timestamp"])
            wq_params.append(WaterQualityParams(**d))

        return cls(timestamps=timestamps, wqparams=wq_params)

    @classmethod
    def from_matlab_file(cls, filepath: str):
        """Loads water quality parameters from a matlab file."""

        mat_file = scipy.io.loadmat(filepath)
        # assuming there is only one dict key, coagulin or coagulout
        data_dict_key = list(mat_file.keys())[0]
        structured_array = mat_file[data_dict_key]
        data = []
        fnames = [f.name for f in fields(WaterQualityParams)]
        total_rows = structured_array.shape[1]
        timestamps = []
        for i in range(total_rows):
            kwargs = {}
            for col, name in enumerate(fnames):
                try:
                    kwargs[str(name)] = structured_array[col][i]
                    if str(name) == "timestamp":
                        timestamps.append(structured_array[col][i])
                except IndexError:  # water param field name is not in the file
                    continue
            data.append(WaterQualityParams(**kwargs))

        return cls(timestamps=timestamps, wqparams=data)

    def __post_init__(self):
        """Check if the list have the same length."""
        list_fields = [
            getattr(self, f.name)
            for f in fields(self)
            if get_origin(f.type) == list or get_origin(f.type) == List
        ]
        lengths = list(map(len, list_fields))
        if len(set(lengths)) > 1:
            raise ValueError(
                f"All list fields must have the same length. Got lengths: {lengths}"
            )

    def __getitem__(self, index) -> WaterQualityParams:
        return self.wqparams[index]

    def __iter__(self):
        return iter(self.wqparams)


@auto_doc
@dataclass
class FlocculationParams:
    """Flocculation process parameters"""

    length: float = field(
        default=20,
        metadata={"units": "m", "code": "Length", "desc": "Length of the reactor"},
    )
    ka: float = field(
        default=1e-4,
        metadata={"units": "-", "code": "Ka", "desc": "Floc aggregation constant"},
    )
    kb: float = field(
        default=8e-7,
        metadata={"units": "-", "code": "Kb", "desc": "Floc breakup constant"},
    )
    g10: float = field(
        default=100,
        metadata={
            "units": "1/s",
            "code": "G10",
            "desc": (
                "Shear Rate G(Velocity dradient,"
                " measure of turbulence or mixure intensity) at 10 ^oC"
            ),
        },
    )
    surf: float = field(
        default=10,
        metadata={
            "units": "m²",
            "code": "Surf",
            "desc": "Cross section of the reactor",
        },
    )
    numcel: int = field(
        default=10,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "Number of completely mixed reactors, Number of discretization cells",
        },
    )

    @property
    def dy(self) -> float:
        """Cell thickness"""
        return self.length / self.numcel


@auto_doc
@dataclass
class CoagulationParams:
    """Cuagulation process parameters"""

    g10: float = field(
        default=100,
        metadata={
            "units": "1/s",
            "code": "G10",
            "desc": (
                "Shear Rate G(Velocity dradient,"
                " measure of turbulence or mixure intensity) at 10 ^oC"
            ),
        },
    )
    a1: float = field(
        default=284,
        metadata={
            "units": "-",
            "code": "a1",
            "desc": "Max specific DOC adsorption constant",
        },
    )
    a2: float = field(
        default=74.2,  # check stimela documentation, x2 has negative sign there
        metadata={
            "units": "-",
            "code": "a2",
            "desc": "Max specific DOC adsorption constant",
        },
    )
    a3: float = field(
        default=4.91,
        metadata={
            "units": "-",
            "code": "a3",
            "desc": "Max specific DOC adsorption constant",
        },
    )
    ka: float = field(
        default=1e-4,
        metadata={"units": "-", "code": "Ka", "desc": "Floc aggregation constant"},
    )
    kb: float = field(
        default=8e-7,
        metadata={"units": "-", "code": "Kb", "desc": "Floc breakup constant"},
    )
    b: float = field(
        default=0.147,
        metadata={
            "units": "-",
            "code": "b",
            "desc": "DOC adsorption constant constant",
        },
    )
    k1: float = field(
        default=-0.075,
        metadata={
            "units": "-",
            "code": "k1",
            "desc": "Non-adsorbable DOC fraction constant",
        },
    )
    k2: float = field(
        default=0.56,
        metadata={
            "units": "-",
            "code": "k2",
            "desc": "Non-adsorbable DOC fraction constant",
        },
    )
    volume: float = field(
        default=5,
        metadata={"units": "-", "code": "Volume", "desc": "Volume of the reactor"},
    )

    def calc_a(self, ph=float) -> float:
        "Returns the a constant for maximum specific DOC adsorption"
        return self.a1 * ph + self.a2 * np.power(ph, 2) + self.a3 * np.power(ph, 3)


@auto_doc
@dataclass
class CoagulationDosage:
    """Class for holding data about Coagulation dosages"""

    fecl3: float = field(
        default=0,
        metadata={"units": "mmol/lt", "code": "FeCl3", "desc": "Iron chloride dosing"},
    )
    fe2so43: float = field(
        default=0,
        metadata={"units": "mmol/lt", "code": "Fe2SO43", "desc": "Iron sulfate dosing"},
    )
    al2so43: float = field(
        default=0,
        metadata={
            "units": "mmol/lt",
            "code": "Al2SO34",
            "desc": "aluminium sulfate dosing",
        },
    )

    @property
    def total_dosage(self) -> float:
        "Returns the sum of all dosage of all 3 kinds of coagulants."
        return self.fecl3 + self.fe2so43 + self.al2so43

    def __eq__(self, other):
        if not isinstance(other, CoagulationDosage):
            return False
        for f in fields(self):
            value_self = getattr(self, f.name)
            value_other = getattr(other, f.name)
            # Handle other cases with standard equality
            if value_self != value_other:
                return False

        return True


@auto_doc
@dataclass
class KValues:
    """A classs for equilibrium constants K.
    ks constant hasn't been included at the time being.
    """

    k1: float
    k2: float
    kw: float

    @classmethod
    def from_activity(
        cls,
        k1: float,
        k2: float,
        kw: float,
        activity: float,
    ):
        """Creates a Kvalues object taken consideration the Activity."""
        k1 /= activity**2
        k2 /= activity**4
        kw /= activity**2
        return cls(k1=k1, k2=k2, kw=kw)

    def __eq__(self, other):
        if not isinstance(other, KValues):
            return False
        for f in fields(self):
            value_self = getattr(self, f.name)
            value_other = getattr(other, f.name)
            if value_self != value_other:
                return False

        return True


@auto_doc
@dataclass
class ChlorinationParams:
    volume: float = field(
        default=100,
        metadata={"units": "m3", "code": "Vol", "desc": "Volume of contact tank"},
    )
    baffling_factor: float = field(
        default=0, metadata={"units": "m3", "code": "BF", "desc": "Baffling factor"}
    )


@auto_doc
@dataclass
class FiltrationParams:
    surf: float = field(
        default=20,
        metadata={"units": "m2", "code": "Surf", "desc": "Filter surface area"},
    )
    lwater: float = field(
        default=1,
        metadata={
            "units": "m",
            "code": "Lwater",
            "desc": "Water level above the filter bed",
        },
    )
    lbed: float = field(
        default=1.5,
        metadata={
            "units": "m",
            "code": "Lbed",
            "desc": "Total depth of the filter bed",
        },
    )
    diam: float = field(
        default=1, metadata={"units": "mm", "code": "Diam", "desc": "Grain size"}
    )
    filporo: float = field(
        default=39,
        metadata={
            "units": "%",
            "code": "FilPorO",
            "desc": "Filter porosity",
        },
    )
    nmax: float = field(
        default=75,
        metadata={"units": "%", "code": "nmax", "desc": "Maximum porefilling"},
    )
    rhod: float = field(
        default=30,
        metadata={
            "units": "kg/m3",
            "code": "rhoD",
            "desc": "Density of deposited solids",
        },
    )
    lambda0: float = field(
        default=0.15,
        metadata={
            "units": "1/m",
            "code": "Lambda0",
            "desc": "Filtration resistance parameter",
        },
    )
    n1: float = field(
        default=290,
        metadata={"units": "-", "code": "n1", "desc": "clogging constant 1"},
    )
    n2: float = field(
        default=310,
        metadata={"units": "-", "code": "n2", "desc": "clogging constant 1"},
    )
    numcel: int = field(
        default=6,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "'Number of control volumes/Number of discretization cells.",
        },
    )

    @property
    def dy(self):
        """Thickness of each cell/control volume"""
        return self.lbed / self.numcel


@auto_doc
@dataclass
class DualFiltrationParams:
    surf: float = field(
        default=20,
        metadata={"units": "m2", "code": "Surf", "desc": "Filter surface area"},
    )
    lwater: float = field(
        default=1,
        metadata={
            "units": "m",
            "code": "Lwater",
            "desc": "Water level above the filter bed",
        },
    )
    lbed1: float = field(
        default=1,
        metadata={
            "units": "m",
            "code": "Lb1",
            "desc": "Total depth of the filter bed (upper)",
        },
    )
    lbed2: float = field(
        default=1,
        metadata={
            "units": "m",
            "code": "Lb2",
            "desc": "Total depth of the filter bed(lower)",
        },
    )
    diam1: float = field(
        default=1.45,
        metadata={"units": "mm", "code": "Diam1", "desc": "Grain size (upper)"},
    )
    diam2: float = field(
        default=1.45,
        metadata={"units": "mm", "code": "Diam2", "desc": "Grain size (lower)"},
    )
    filporo1: float = field(
        default=40,
        metadata={
            "units": "%",
            "code": "FilPorO2",
            "desc": "Filter porosity (upper)",
        },
    )
    filporo2: float = field(
        default=40,
        metadata={
            "units": "%",
            "code": "FilPorO2",
            "desc": "Filter porosity (lower)",
        },
    )
    rhod: float = field(
        default=15,
        metadata={
            "units": "kg/m3",
            "code": "rhoD",
            "desc": "Density of deposited solids",
        },
    )
    lambda01: float = field(
        default=0.003,
        metadata={
            "units": "1/m",
            "code": "Lambda01",
            "desc": "Filtration resistance parameter (upper)",
        },
    )
    lambda02: float = field(
        default=0.03,
        metadata={
            "units": "1/m",
            "code": "Lambda01",
            "desc": "Filtration resistance parameter (lower)",
        },
    )
    n1: float = field(
        default=20,
        metadata={"units": "-", "code": "n1", "desc": "clogging constant 1 (upper)"},
    )
    n2: float = field(
        default=3,
        metadata={"units": "-", "code": "n2", "desc": "clogging constant 2 (lower)"},
    )
    numcel1: int = field(
        default=6,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "'Number of control volumes/Number of discretization cells. (upper)",
        },
    )
    numcel2: int = field(
        default=6,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "Number of control volumes/Number of discretization cells. (lower)",
        },
    )

    @property
    def dy1(self):
        """Thickness of each cell/control volume (upper)"""
        return self.lbed1 / self.numcel1

    @property
    def dy2(self):
        """Thickness of each cell/control volume (lower)"""
        return self.lbed2 / self.numcel2


@auto_doc
@dataclass
class BackWashData:
    """Dataclass for holding filtration Back Wash events"""

    timestamps: List[float]
    events: List[bool]

    def __post_init__(self):
        if len(self.timestamps) != len(self.events):
            raise ValueError("timestamps and events don't have the same length!")

    @property
    def length(self):
        """Returns the number of the backwash events"""
        return len(self.timestamps)


@dataclass
class GACFiltrationParams:
    f_area: float = field(
        default=50,
        metadata={
            "units": "m2",
            "code": "Area",
            "desc": "Filter surface area-Cross-sectional area of the filter",
        },
    )
    lbed: float = field(
        default=2,
        metadata={"units": "m", "code": "Lb", "desc": "Total depth of the filter bed"},
    )
    diam: float = field(
        default=2,
        metadata={"units": "m", "code": "Diam", "desc": "Diameter of GAC particles"},
    )
    filporo: float = field(
        default=50, metadata={"units": "%", "code": "FilPor", "desc": "Filter porosity"}
    )
    freund_n: float = field(
        default=0.5,
        metadata={
            "units": "-",
            "code": "n",
            "desc": "Freundlich exponent (nonlinear adsorption) constant n",
        },
    )
    rho_k: float = field(
        default=500,
        metadata={
            "units": "kg/m3",
            "code": "rhoK",
            "desc": "Mass density of the GAC",
        },
    )
    freund_k: float = field(
        default=20,
        metadata={
            "units": "g/kg)*(m³/g)^n",
            "code": "K",
            "desc": "Freundlich adsorption coefficient K",
        },
    )
    mass_tr_coef_k2: float = field(
        default=10,
        metadata={"units": "1/h", "code": "M", "desc": "Mass transfer coefficent k2"},
    )
    numcel: int = field(
        default=5,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "Number of completely mixed reactors",
        },
    )


@auto_doc
@dataclass
class NOMFiltrationParams(GACFiltrationParams):
    """DataClass for holding NOM removal process parameters."""

    docna: float = field(
        default=0.9,
        metadata={"units": "-", "code": "DOCna", "desc": "Non exchanged DOC"},
    )


@auto_doc
@dataclass
class OzonationParams:
    """Dataclass for holding Ozonation process parameterss."""

    numcel: int = field(default=10, metadata={"units": "-", "code": "NumCel"})
    hreact: float = field(
        default=5,
        metadata={"units": "m", "code": "Hreact", "desc": "Height of the reactor"},
    )
    areact: float = field(
        default=6,
        metadata={
            "units": "m2",
            "code": "Areact",
            "desc": "Surface area ozone reactor",
        },
    )
    meetee: bool = field(
        default=False,
        metadata={
            "units": "-",
            "code": "MeeTee",
            "desc": "True co-current, False counter current",
        },
    )
    db0: float = field(
        default=3,
        metadata={"units": "m", "code": "db0", "desc": "initial bubble diameter"},
    )
    kuv_sel: bool = field(
        default=True,
        metadata={
            "units": "-",
            "code": "kUV_Sel",
            "desc": "True if kUV is given manual, False if kUV determined by the model",
        },
    )
    kuv: float = field(
        default=0.5,
        metadata={"units": "1/s", "code": "kUV", "desc": "UVA254 decay rate"},
    )
    y_factor: float = field(
        default=0.01,
        metadata={
            "units": "(mg/lt)/(1/m)",
            "code": "Y",
            "desc": "Yield factor for ozone use per UVA decrease",
        },
    )
    kafbo3_sel: bool = field(
        default=True,
        metadata={
            "units": "-",
            "code": "Kafb03_Sel",
            "desc": "True if KO3 is given manual, False if determined by the model.",
        },
    )
    kafbo3: float = field(
        default=0.27,
        metadata={"units": "1/s", "code": "KafO3", "desc": "slow decay rate 03"},
    )
    ceuva254_sel: bool = field(
        default=True,
        metadata={
            "units": "-",
            "code": "ceUVA254_Sel",
            "desc": "True if UVAo is given manual, False if determined by the model.",
        },
    )
    ceuva254: float = field(
        default=3,
        metadata={
            "units": "",
            "code": "ceUVA254",
            "desc": "stable UVA254 value after ozonation",
        },
    )
    factor_klo3: float = field(
        default=0.04,
        metadata={
            "units": "",
            "code": "FactorKLO3",
            "desc": "variable in Hughmark equation that varies for single gas bubble",
        },
    )
    f_bro3init: float = field(
        default=2.5,
        metadata={
            "units": "",
            "code": "F_BrO3init",
            "desc": "FBrO3,ini constant for initial bromate formation (F*ozone dosage)",
        },
    )
    kct_bro3_sel: bool = field(
        default=True,
        metadata={
            "units": "",
            "code": "kCt_BrO3_Sel",
            "desc": "True kBrO3 is given manual, False kBrO3 is determined by the model",
        },
    )
    ktc_bro3: float = field(
        default=3,
        metadata={
            "units": "",
            "code": "kCt_BrO3",
            "desc": "kBrO3 bromate formation rate constant",
        },
    )
    f_aoc_sel: bool = field(
        default=True,
        metadata={
            "units": "",
            "code": "F_AOC_Sel",
            "desc": "True FACO is given manual, False FAOC is determined by the model",
        },
    )
    f_aoc: float = field(
        default=50,
        metadata={
            "units": "(ug-C/l)/(mg-O3/l)",
            "code": " F_AOC",
            "desc": "FAOC constant for AOC formation (F*ozone dosage) ",
        },
    )
    kec_sel: bool = field(
        default=True,
        metadata={
            "units": "",
            "code": "kEc_Sel",
            "desc": " True kEc is given manual, False kEc is determined by the model",
        },
    )
    kec: float = field(
        default=300,
        metadata={
            "units": "",
            "code": " kEc",
            "desc": " k inactivation rate for E.coli",
        },
    )
    ct_lagec: float = field(
        default=0.01,
        metadata={"units": "", "code": "Ct_lagEc", "desc": "Ctlag for E.coli"},
    )


@auto_doc
@dataclass
class AerationCascadeParams:
    """DataClass that holding Aeraction Cascade process parameters."""

    numcel: int = field(
        default=5,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "Number of completely mixed reactors",
        },
    )
    v_bak: float = field(
        default=0.5,
        metadata={
            "units": "m3",
            "code": "VBak",
            "desc": "Volume of one cascade chamber",
        },
    )
    rq_eff: float = field(
        default=0.4,
        metadata={
            "units": "-",
            "code": "RQeff",
            "desc": "Effective air to water ratio",
        },
    )
    k2_ch4: float = field(
        default=0.04,
        metadata={
            "units": "1/s",
            "code": "k2CH4",
            "desc": "Gas transfer coëfficient (k_2) for methane",
        },
    )
    v_air: float = field(
        default=0,
        metadata={
            "units": "m3",
            "code": "Vair",
            "desc": "Air volume above cascade. if 0 then is open system",
        },
    )


@auto_doc
@dataclass
class AerationPlateParams:
    """DataClass that holding Aeraction Plate process parameters."""

    numcel: int = field(
        default=5,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "Number of completely mixed reactors",
        },
    )
    pl_length: float = field(
        default=4,
        metadata={"units": "m", "code": "Lengte", "desc": "Length of perforated plate"},
    )
    pl_width: float = field(
        default=2,
        metadata={"units": "m", "code": "Breedte", "desc": "Width of perforated plate"},
    )
    height_foam: float = field(
        default=0.35,
        metadata={"units": "m", "code": "Htop", "desc": "Height of foam layer"},
    )
    water_perc_foam: float = field(
        default=50,
        metadata={
            "units": "%",
            "code": "PercWat",
            "desc": "Water percentage in foam layer",
        },
    )
    qg_tot: float = field(
        default=4000,
        metadata={
            "units": "m^3/h",
            "code": "QgTot",
            "desc": "Total airflow",
        },
    )
    qg_rec: float = field(
        default=3600,
        metadata={"units": "m^3/h", "code": "QgRec", "desc": "Recirculation air flow"},
    )
    k2_ch4: float = field(
        default=0.04,
        metadata={
            "units": "1/s",
            "code": "k2CH4",
            "desc": "Gas transfer coëfficient (k_2) for methane",
        },
    )


@auto_doc
@dataclass
class AerationTowerParams:
    """DataClass that holding Aeraction Tower process parameters."""

    numcel: int = field(
        default=5,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "Number of completely mixed reactors",
        },
    )
    hoogte: float = field(
        default=2.6,
        metadata={
            "units": "m",
            "code": "Hoogte",
            "desc": "Height of the packed bed",
        },
    )
    diam: float = field(
        default=1,
        metadata={
            "units": "m",
            "code": "Diam",
            "desc": "Diameter of the packed bed",
        },
    )
    meetee: Literal["cocurrent", "countercurrent", "mixed_air"] = field(
        default="cocurrent",
        metadata={
            "units": "-",
            "code": "MeeTee",
            "desc": "Flow direction: Cocurrent,Countercurrent,Completely mixed air(1, 0, 2)",
        },
    )
    qg_tot: float = field(
        default=2000,
        metadata={
            "units": "m^3/h",
            "code": "QgTot",
            "desc": "Total airflow",
        },
    )
    qg_rec: float = field(
        default=0.4,
        metadata={"units": "m^3/h", "code": "QgRec", "desc": "Recirculation air flow"},
    )
    k2_ch4: float = field(
        default=0.05,
        metadata={
            "units": "1/s",
            "code": "k2",
            "desc": "Gas transfer coëfficient (k_2) for methane",
        },
    )
    perc_fe: float = field(
        default=4,
        metadata={
            "units": "%",
            "code": "PercFe",
            "desc": "During aeration oxidated iron",
        },
    )
    perc_ca: float = field(
        default=2,
        metadata={
            "units": "%",
            "code": "PercCa",
            "desc": "During aeration converted calcium",
        },
    )

    @property
    def qg_vers(self) -> float:
        """Returns the vented air flow in m^3/h."""
        return self.qg_tot - self.qg_rec


@auto_doc
@dataclass
class AerationTowerVCParams:
    """DataClass that holding Aeraction Tower VC process parameters."""

    numcel: int = field(
        default=5,
        metadata={
            "units": "-",
            "code": "NumCel",
            "desc": "Number of completely mixed reactors",
        },
    )
    hoogte: float = field(
        default=2.6,
        metadata={
            "units": "m",
            "code": "Hoogte",
            "desc": "Height of the packed bed",
        },
    )
    diam: float = field(
        default=1,
        metadata={
            "units": "m",
            "code": "Diam",
            "desc": "Diameter of the packed bed",
        },
    )
    meetee: Literal["cocurrent", "countercurrent"] = field(
        default="cocurrent",
        metadata={
            "units": "-",
            "code": "MeeTee",
            "desc": "Flow direction: Cocurrent,Countercurrent,Completely mixed air(1, 0)",
        },
    )
    qg_tot: float = field(
        default=2000,
        metadata={
            "units": "m^3/h",
            "code": "QgTot",
            "desc": "Total airflow",
        },
    )
    qg_rec: float = field(
        default=0.4,
        metadata={"units": "m^3/h", "code": "QgRec", "desc": "Recirculation air flow"},
    )
    k2: float = field(
        default=0.05,
        metadata={
            "units": "1/s",
            "code": "k2",
            "desc": "Gas transfer coëfficient (k_2)",
        },
    )
    kd: float = field(
        default=0.05,
        metadata={
            "units": "-",
            "code": "kD",
            "desc": "Distribution coëfficiënt (kD)",
        },
    )

    @property
    def qg_vers(self) -> float:
        """Returns the vented air flow in m^3/h."""
        return self.qg_tot - self.qg_rec


@auto_doc
@dataclass
class BaseState(ABC):
    """An abstract class for handling initial states of the water treatment simulations."""

    def __post_init__(self):
        """Check if the list have the same length.
        This stands for the case where there are initial states based only on single cell number.
        """
        list_fields = [
            getattr(self, f.name)
            for f in fields(self)
            if get_origin(f.type) == list or get_origin(f.type) == List
        ]
        lengths = list(map(len, list_fields))
        if len(set(lengths)) > 1:
            raise ValueError(
                f"All list fields must have the same length. Got lengths: {lengths}"
            )

    @abstractmethod
    def to_numpy(self): ...


@auto_doc
@dataclass
class AerationTowerState(BaseState):
    """A helper dataclass for handling Aeration Tower initial state."""

    flow_direction: Literal["cocurrent", "countercurrent", "mixed_air"]
    o2_liquid: List[float]
    o2_gas: List[float]
    ch4_liquid: List[float]
    ch4_gas: List[float]
    co2_liquid: List[float]
    co2_gas: List[float]
    n2_liquid: List[float]
    n2_gas: List[float]
    h2s_liquid: List[float]
    h2s_gas: List[float]
    hco3: List[float]
    fe3: List[float]
    caco3: List[float]
    cstap_1: List[float]
    fdt: List[float]
    fdt1: List[float]

    def to_numpy(self) -> NDArray:
        """Flattens the initial state to a numpy 1D array"""
        if self.flow_direction in ["cocurrent", "countercurrent"]:
            return np.array(
                self.o2_liquid
                + self.o2_gas
                + self.ch4_liquid
                + self.ch4_gas
                + self.co2_liquid
                + self.co2_gas
                + self.cstap_1
                + self.hco3
                + self.fdt
                + self.fe3
                + self.fdt1
                + self.caco3
                + self.n2_liquid
                + self.n2_gas
                + self.h2s_liquid
                + self.h2s_gas
            )
        else:  # mixed air case
            return np.array(
                self.o2_liquid
                + self.ch4_liquid
                + self.co2_liquid
                + self.n2_liquid
                + self.h2s_liquid
                + self.o2_gas
                + self.ch4_gas
                + self.co2_gas
                + self.n2_gas
                + self.h2s_gas
                + self.cstap_1
                + self.hco3
                + self.fdt
                + self.fe3
                + self.fdt1
                + self.caco3
            )

    def __post_init__(self):
        if self.flow_direction == "mixed_air":
            gas_names = {"o2_gas", "ch4_gas", "co2_gas", "h2s_gas", "n2_gas"}
            gas_fields = [
                getattr(self, f.name) for f in fields(self) if f.name in gas_names
            ]

            lengths_gases = list(map(len, gas_fields))
            if max(lengths_gases) > 1:
                raise ValueError(
                    "Gases state must have length of 1 for the mixed air case."
                )
            list_fields = [
                getattr(self, f.name)
                for f in fields(self)
                if (get_origin(f.type) == list or get_origin(f.type) == List)
                and f.name not in gas_names
            ]
            lengths = list(map(len, list_fields))
            if len(set(lengths)) > 1:
                raise ValueError(
                    f"All list fields must have the same length. Got lengths: {lengths}"
                )
        else:
            return super().__post_init__()


@auto_doc
@dataclass
class AerationTowerVCState(BaseState):
    """A helper dataclass for handling Aeration Tower VC initial state."""

    liquid: List[float]
    gas: List[float]

    def to_numpy(self) -> NDArray:
        """Flattens the initial state to a numpy 1D array"""
        return np.array(self.liquid + self.gas)


@auto_doc
@dataclass
class AerationCascadeOpenSystemState(BaseState):
    """Helper data class for handling Aeration Cascade Open initial system state.
    Open system -- no headroom gas concentrations"""

    o2_liquid: List[float]
    o2_gas: List[float]
    ch4_liquid: List[float]
    ch4_gas: List[float]
    co2_liquid: List[float]
    co2_gas: List[float]
    n2_liquid: List[float]
    n2_gas: List[float]
    h2s_liquid: List[float]
    h2s_gas: List[float]
    mn: List[float]

    def to_numpy(self) -> NDArray:
        """Flattens the initial state to a numpy 1D array"""
        return np.array(
            self.o2_liquid
            + self.o2_gas
            + self.ch4_liquid
            + self.ch4_gas
            + self.co2_liquid
            + self.co2_gas
            + self.mn
            + self.n2_liquid
            + self.n2_gas
            + self.h2s_liquid
            + self.h2s_gas
        )


@auto_doc
@dataclass
class AerationCascadeClosedSystemState(AerationCascadeOpenSystemState):
    """Helper data class for handling Aeration Cascade Closed system initial state.
    Closed system -- headroom gas concentrations"""

    o2_hroom: float
    ch4_hroom: float
    co2_hroom: float
    n2_hroom: float
    h2s_hroom: float

    def to_numpy(self) -> NDArray:
        """Flattens the initial state to a numpy 1D array"""
        return np.array(
            self.o2_liquid
            + self.o2_gas
            + self.ch4_liquid
            + self.ch4_gas
            + self.co2_liquid
            + self.co2_gas
            + self.mn
            + self.n2_liquid
            + self.n2_gas
            + self.h2s_liquid
            + self.h2s_gas
            + [
                self.o2_hroom,
                self.ch4_hroom,
                self.co2_hroom,
                self.n2_hroom,
                self.h2s_hroom,
            ]
        )


@auto_doc
@dataclass
class AerationPlateState(AerationCascadeOpenSystemState):
    """Helper data class for handling Aeration Plate system initial state."""


@auto_doc
@dataclass
class OzonationState(BaseState):
    """Helper data class for handling Ozonation initial state."""

    o3_liquid: List[float]
    o3_gas: List[float]
    uv254: List[float]
    bromate: List[float]
    ecoli: List[float]
    ct_ecoli: List[float]

    def to_numpy(self):
        return np.array(
            self.o3_liquid
            + self.o3_gas
            + self.uv254
            + self.bromate
            + self.ecoli
            + self.ct_ecoli
        )


@auto_doc
@dataclass
class NOMFiltrationState(BaseState):
    """Helper data class for handling NOM Filtration initial state."""

    doc: List[float] = field(
        metadata={
            "units": "mg/lt",
            "code": "DOC",
            "desc": "Dissolved organic carbon concentration per cell",
        },
    )
    init_accumulation: List[float] = field(
        metadata={
            "units": "mg/lt ??",
            "desc": "initial accumulation of DOC mass in the filters per cell",
        }
    )

    def to_numpy(self):
        return np.array(self.doc + self.init_accumulation)


@auto_doc
@dataclass
class ChlorinationState(BaseState):
    """Helper data class for handling Chlorination initial state."""

    reschl: float = field(
        metadata={
            "units": "mg/lt",
            "desc": "Residual (free?) chlorine concentration per cell",
        }
    )
    tthms: float = field(
        metadata={
            "units": "ug/lt",
            "code": "TTHMs",
            "desc": "trihalomethanes concentration per cell",
        }
    )
    haas: float = field(
        metadata={
            "units": "ug/lt",
            "code": "HAAs",
            "desc": "haloacetic acids concentration per cell",
        }
    )
    ecoli: float = field(
        default=0.0,
        metadata={
            "units": "-",
            "code": "Ec",
            "desc": "E.coli concentration per cell",
        },
    )

    def to_numpy(self):
        return np.array([self.reschl, self.tthms, self.haas, self.ecoli])


@auto_doc
@dataclass
class FiltrationState(BaseState):
    """Helper data class for handling Filtration initial state."""

    suspended_solids: List[float] = field(
        metadata={"units": "mg/m3", "desc": "Suspended solid concentration per cell"}
    )
    init_accumulation: List[float] = field(
        metadata={
            "units": "mg/m3",
            "desc": "initial accumulation of solids in the filters per cell",
        }
    )

    def to_numpy(self):
        return np.array(self.suspended_solids + self.init_accumulation)


@auto_doc
@dataclass
class DualFiltrationState(BaseState):
    """Helper data class for handling Filtration initial state."""

    suspended_solids_upper: List[float] = field(
        metadata={
            "units": "mg/m3",
            "desc": "Suspended solid concentration per cell (upper filter)",
        }
    )
    init_accumulation_upper: List[float] = field(
        metadata={
            "units": "mg/m3",
            "desc": "initial accumulation of solids in the filters per cell (upper filter)",
        }
    )
    suspended_solids_lower: List[float] = field(
        metadata={
            "units": "mg/m3",
            "desc": "Suspended solid concentration per cell (lower filter)",
        }
    )
    init_accumulation_lower: List[float] = field(
        metadata={
            "units": "mg/m3",
            "desc": "initial accumulation of solids in the filters per cell (lower filter)",
        }
    )

    def to_numpy(self):
        return np.array(
            self.suspended_solids_upper
            + self.init_accumulation_upper
            + self.suspended_solids_lower
            + self.init_accumulation_lower
        )

    def __post_init__(self):
        """Check if the lists for have the same length per filter type paramters (upper/lower)."""
        upper_list = [self.suspended_solids_upper, self.init_accumulation_upper]
        lower_list = [self.suspended_solids_lower, self.init_accumulation_lower]
        for filter_type in zip(["upper", "lower"], [upper_list, lower_list]):
            lengths = list(map(len, filter_type[1]))
            if len(set(lengths)) > 1:
                raise ValueError(
                    f"All list fields must have the same length."
                    f"For {filter_type[0]} filter type got lengths: {lengths}"
                )


@auto_doc
@dataclass
class GACFiltrationState(BaseState):
    """Helper data class for handling GAC Filtration initial state."""

    doc: List[float] = field(
        metadata={
            "units": "mg/lt ??",
            "desc": "DOC concentration in liquid phase per cell",
        }
    )
    init_accumulation: List[float] = field(
        metadata={
            "units": "mg/lt ??",
            "desc": "absorbed DOC mass on GAC per cell",
        }
    )

    def to_numpy(self):
        return np.array(self.doc + self.init_accumulation)


@auto_doc
@dataclass
class FlocculationState(BaseState):
    """Data class for handling Flocculation initial state."""

    suspended_solids: List[float] = field(
        metadata={"units": "kg/m3", "desc": "Suspended solids concentration per cell"}
    )

    def to_numpy(self):
        return np.array(self.suspended_solids)


@auto_doc
@dataclass
class AerationCascadeCellConcentrations:
    """Data class for holding additional results
    data from aeraton cascade process."""

    numcel: int = field(metadata={"desc": "The number of cells in the aerator"})

    timestamps: List[float] = field(
        metadata={"desc": "list holding the timestamps in secs?"}
    )

    o2_liquid: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": "liquid O2 concentration per cell including influent",
        }
    )
    o2_gas: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": "gas O2 concentration per cell inclunting influent",
        }
    )
    o2_equilibrium: NDArray[np.float64] = field(
        metadata={
            "units": "?",
            "desc": "O₂ saturation concentrations (equilibrium) for each cell inclunting influent",
        }
    )
    ch4_liquid: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": "liquid CH4 concentration per cell including influent",
        }
    )
    ch4_gas: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("gas CH4 concentration  per cell" " inclunting influent"),
        }
    )
    ch4_equilibrium: NDArray[np.float64] = field(
        metadata={
            "units": "?",
            "desc": "CH4 saturation concentrations (equilibrium) for each cell inclunting influent",
        }
    )
    co2_liquid: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": "liquid CO2 concentration per cell including influent",
        }
    )
    co2_gas: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("gas CO2 concentration " "per cell inclunting influent"),
        }
    )
    co2_equilibrium: NDArray[np.float64] = field(
        metadata={
            "units": "?",
            "desc": "CO₂ saturation concentrations (equilibrium) for each cell inclunting influent",
        }
    )
    n2_liquid: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": "liquid N2 concentration per cell including influent",
        }
    )
    n2_gas: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("gas N2 concentration per cell " "inclunting influent"),
        }
    )
    n2_equilibrium: NDArray[np.float64] = field(
        metadata={
            "units": "?",
            "desc": "N₂ saturation concentrations (equilibrium) for each cell inclunting influent",
        }
    )
    h2s_liquid: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": "liquid H2S concentration per cell including influent",
        }
    )
    h2s_gas: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("gas H2S concentration per cell " "inclunting influent"),
        }
    )
    h2s_equilibrium: NDArray[np.float64] = field(
        metadata={
            "units": "?",
            "desc": "H2S saturation concentrations (equilibrium) for each cell inclunting influent",
        }
    )

    _gas_order = ("o2", "ch4", "co2", "n2", "h2s")

    def to_dataframe(self):
        """Returns all the data in a pandas dataframe."""
        field_names = []
        for gas in self._gas_order:
            field_names.append(f"{gas}_liquid")
            field_names.append(f"{gas}_gas")
            field_names.append(f"{gas}_equilibrium")
        data_array = np.concatenate(
            [getattr(self, column) for column in field_names], axis=1
        )
        all_array = np.concatenate(
            [np.array(self.timestamps).reshape(-1, 1), data_array], axis=1
        )
        return pd.DataFrame(all_array, columns=self.__create_column_names(self.numcel))

    def to_numpy(self):
        """Returns all the data in a numpy array"""
        return self.to_dataframe().to_numpy()

    @staticmethod
    def __create_column_names(numcel: int) -> List[str]:
        column_order = []
        gas_order = ("o2", "ch4", "co2", "n2", "h2s")
        for gas in gas_order:
            for state in ["liquid", "gas", "equilibrium"]:
                for cell in range(numcel + 1):
                    column_order.append(f"{gas}_{state}_{cell}")
        return ["timestamps"] + column_order

    @classmethod
    def from_csv(cls, filepath: str, numcel: int):
        """Constructor from a csv file."""
        df = pd.read_csv(filepath)
        df.columns = pd.Index(cls.__create_column_names(numcel))
        gas_order = ("o2", "ch4", "co2", "n2", "h2s")
        states = ["liquid", "gas", "equilibrium"]
        kwargs = {}
        kwargs["timestamps"] = df["timestamps"].to_numpy().tolist()
        kwargs["numcel"] = numcel
        for gas in gas_order:
            for state in states:
                gas_columns = []
                for cell in range(numcel + 1):
                    gas_columns.append(f"{gas}_{state}_{cell}")
                kwargs[f"{gas}_{state}"] = df[gas_columns].to_numpy()
        return cls(**kwargs)


@auto_doc
@dataclass
class AerationPlateCellConcentrations(AerationCascadeCellConcentrations):
    """Data class for holding additional results
    data from aeraton plate process."""


@auto_doc
@dataclass
class AerationTowerCellConcentrations(AerationCascadeCellConcentrations):
    """Data class for holding additional results
    data from aeraton tower process."""

    ph: NDArray[np.float64] = field(
        metadata={
            "units": "-",
            "desc": ("pH per cell "),
        }
    )
    hco3: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt?",
            "desc": ("hco3  the concentration per cell " "inclunting influent"),
        }
    )
    fe2: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt?",
            "desc": ("Fe2 concentration per cell " "inclunting influent"),
        }
    )
    fe3: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt?",
            "desc": ("Fe3  concentration per cell " "inclunting influent"),
        }
    )
    ca2: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt?",
            "desc": ("Ca2 concentration per cell " "inclunting influent"),
        }
    )
    caco3: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("CaCO3 concentration per cell " "inclunting influent"),
        }
    )
    cstap1: NDArray[np.float64] = field(
        metadata={
            "units": "?",
            "desc": ("cstap1 per cell " "inclunting influent"),
        }
    )

    def to_dataframe(self):
        """Returns all the data in a pandas dataframe."""
        field_names = []
        add_field_names = [
            "cstap1",
            "ph",
            "co2_liquid",
            "hco3",
            "fe2",
            "fe3",
            "ca2",
            "caco3",
        ]
        for gas in self._gas_order:
            field_names.append(f"{gas}_liquid")
            field_names.append(f"{gas}_gas")
            field_names.append(f"{gas}_equilibrium")
        field_names = field_names + add_field_names
        data_array = np.concatenate(
            [getattr(self, column) for column in field_names], axis=1
        )
        all_array = np.concatenate(
            [np.array(self.timestamps).reshape(-1, 1), data_array], axis=1
        )
        return pd.DataFrame(all_array, columns=self.__create_column_names(self.numcel))

    def to_numpy(self):
        """Returns all the data in a numpy array"""
        return self.to_dataframe().to_numpy()

    @staticmethod
    def __create_column_names(numcel: int) -> List[str]:
        column_order = []
        gas_order = ("o2", "ch4", "co2", "n2", "h2s")
        add_col_names = ["cstap1", "ph", "co2", "hco3", "fe2", "fe3", "ca2", "caco3"]
        for gas in gas_order:
            for state in ["liquid", "gas", "equilibrium"]:
                for cell in range(numcel + 1):
                    column_order.append(f"{gas}_{state}_{cell}")
        for add_col in add_col_names:
            for cell in range(numcel + 1):
                column_order.append(f"{add_col}_{cell}")

        return ["timestamps"] + column_order

    @classmethod
    def from_csv(cls, filepath: str, numcel: int):
        """Constructor from a csv file."""
        df = pd.read_csv(filepath)
        df.columns = pd.Index(cls.__create_column_names(numcel))
        add_col_names = ["cstap1", "ph", "hco3", "fe2", "fe3", "ca2", "caco3"]
        gas_order = ("o2", "ch4", "co2", "n2", "h2s")
        states = ["liquid", "gas", "equilibrium"]
        kwargs = {}
        kwargs["timestamps"] = df["timestamps"].to_numpy().tolist()
        kwargs["numcel"] = numcel
        for gas in gas_order:
            for state in states:
                gas_columns = []
                for cell in range(numcel + 1):
                    gas_columns.append(f"{gas}_{state}_{cell}")
                kwargs[f"{gas}_{state}"] = df[gas_columns].to_numpy()
        for add_col in add_col_names:
            additional_columns = []
            for cell in range(numcel + 1):
                additional_columns.append(f"{add_col}_{cell}")
            kwargs[add_col] = df[additional_columns].to_numpy()

        return cls(**kwargs)


@auto_doc
@dataclass
class OzonationCellConcentrations:
    """Data class for holding additional results
    data from ozonation process."""

    numcel: int = field(metadata={"desc": "The number of cells in the aerator"})

    timestamps: List[float] = field(
        metadata={"desc": "list holding the timestamps in secs?"}
    )

    o3_liquid: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("liquid O3 concentration per cell including influent"),
        }
    )
    o3_gas: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("gas O3 concentration per cell including influent"),
        }
    )
    uv254: NDArray[np.float64] = field(
        metadata={
            "units": "1/m",
            "desc": ("uv254 per cell including influent"),
        }
    )
    bro3: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("BrO3 concentration per cell including influent"),
        }
    )
    ecoli: NDArray[np.float64] = field(
        metadata={
            "units": "-",
            "desc": ("Ecoli concentration per cell including influent"),
        }
    )
    ct: NDArray[np.float64] = field(
        metadata={
            "units": "-",
            "desc": ("Ct per cell including influent"),
        }
    )

    @staticmethod
    def __create_column_names(numcel: int) -> List[str]:
        column_order = [
            "o3_liquid",
            "o3_gas",
            "uv254",
            "bro3",
            "ecoli",
            "ct",
        ]
        columns = []
        for el in column_order:
            for cell in range(numcel + 1):
                columns.append(f"{el}_{cell}")

        return ["timestamps"] + columns

    def to_dataframe(self):
        """Returns all the data in a pandas dataframe."""
        columns_order = [
            "o3_liquid",
            "o3_gas",
            "uv254",
            "bro3",
            "ecoli",
            "ct",
        ]
        data_array = np.concatenate(
            [getattr(self, column) for column in columns_order], axis=1
        )
        all_array = np.concatenate(
            [np.array(self.timestamps).reshape(-1, 1), data_array], axis=1
        )
        return pd.DataFrame(all_array, columns=self.__create_column_names(self.numcel))

    def to_numpy(self):
        """Returns all the data in a numpy array"""
        return self.to_dataframe().to_numpy()

    @classmethod
    def from_csv(cls, filepath: str, numcel: int):
        """Constructor from a csv file."""
        df = pd.read_csv(filepath)
        df.columns = pd.Index(cls.__create_column_names(numcel))
        columns_order = [
            "o3_liquid",
            "o3_gas",
            "uv254",
            "bro3",
            "ecoli",
            "ct",
        ]
        kwargs = {}
        kwargs["timestamps"] = df["timestamps"].to_numpy().tolist()
        kwargs["numcel"] = numcel
        for el in columns_order:
            el_columns = []
            for cell in range(numcel + 1):
                el_columns.append(f"{el}_{cell}")
            kwargs[el] = df[el_columns].to_numpy()
        return cls(**kwargs)


@dataclass
class AerationTowerVCCellConcentrations:
    """Data class for holding additional results
    data from aeraton tower VC process."""

    numcel: int = field(metadata={"desc": "The number of cells in the aerator"})

    timestamps: List[float] = field(
        metadata={"desc": "list holding the timestamps in secs?"}
    )

    liquid: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("liquid concentration per cell including influent"),
        }
    )
    gas: NDArray[np.float64] = field(
        metadata={
            "units": "mg/lt",
            "desc": ("gas concentration per cell including influent"),
        }
    )
    equilibrium: NDArray[np.float64] = field(
        metadata={
            "units": "?",
            "desc": (
                "saturation concentrations (equilibrium) for each cell inclunting influent"
            ),
        }
    )

    @staticmethod
    def __create_column_names(numcel: int) -> List[str]:
        column_order = [
            "liquid",
            "gas",
            "equilibrium",
        ]
        columns = []
        for state in column_order:
            for cell in range(numcel + 1):
                columns.append(f"{state}_{cell}")

        return ["timestamps"] + columns

    def to_dataframe(self):
        """Returns all the data in a pandas dataframe."""
        column_order = [
            "liquid",
            "gas",
            "equilibrium",
        ]
        data_array = np.concatenate(
            [getattr(self, column) for column in column_order], axis=1
        )
        all_array = np.concatenate(
            [np.array(self.timestamps).reshape(-1, 1), data_array], axis=1
        )
        return pd.DataFrame(all_array, columns=self.__create_column_names(self.numcel))

    def to_numpy(self):
        """Returns all the data in a numpy array"""
        return self.to_dataframe().to_numpy()

    @classmethod
    def from_csv(cls, filepath: str, numcel: int):
        """Constructor from a csv file."""
        df = pd.read_csv(filepath)
        df.columns = pd.Index(cls.__create_column_names(numcel))
        column_order = [
            "liquid",
            "gas",
            "equilibrium",
        ]
        kwargs = {}
        kwargs["timestamps"] = df["timestamps"].to_numpy().tolist()
        kwargs["numcel"] = numcel
        for state in column_order:
            state_columns = []
            for cell in range(numcel + 1):
                state_columns.append(f"{state}_{cell}")
            kwargs[state] = df[state_columns].to_numpy()
        return cls(**kwargs)
